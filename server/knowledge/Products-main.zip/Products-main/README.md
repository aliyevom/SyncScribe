# Products

## High Level Achitecture
<img src="./images/HighLevel_Design.png" alt="High level Architecture" title="High Level Architecture" align="center" height="100%"/>
<br>
<br>
<br>

## General User workflow
<img src="./images/User_flow.png" alt="user_flow" title="User Work Flow" align="center" height="100%" width="100%">
<p>
Below are the list of Products that can be deployed using GitHub Actions. clicking on each Product will direct you to respective documentation
</p>

## GitHub Initial setup
<img src="./images/Github_setup.png" alt="GitHub Setup" title="GithubSetup" align="center" height="100%" width="100%">

<p>

[1. Resource Group Creation](Azure/resource-group/Readme.md)

[2. Static Website Creation](Azure/static-web-app/staticwebapp.md)

[3. Azure Kubernetes Services Creation](Azure/AKS/aks.md)

[4. Azure log Analytics Workspace](Azure/Azure-log-analytics/loganalytics.md)

[5. Azure MSSQL server](Azure/mssql/mssql.md)

[6. App Service Environment V3](Azure/ASEv3/asev3.md)

[7. App Service Plan in V3](Azure/app-service-plan/appserviceplan.md)

[8. Storage Account](Azure/storage-account/README.md)

[9. Web App](Azure/web-app/README.md)

[10. Function App](Azure/function-app/README.md)

[11. RedHat Linux VM](Azure/Linux-VM/linuxvm.md)

[12. Postgresql Flex server ](Azure/postgresql-flexible-server/postgres.md)

</p>