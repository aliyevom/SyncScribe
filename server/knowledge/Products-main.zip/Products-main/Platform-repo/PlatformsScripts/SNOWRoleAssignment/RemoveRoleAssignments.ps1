<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$adtSubscriptionID,
    [string]$adtEmailAddress,
    [string]$resourceGroupName,
    [string]$resourceName,
    [string]$azureRole
)


$ErrorActionPreference = 'Stop'


Write-Verbose "Checking for Azure Entra module..." -Verbose

$AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

if ($AzModule -eq $null) {
    Write-Verbose "Azure Entra PowerShell module not found" -Verbose
    #Logging into Azure Entra
    Install-Module -Name "Microsoft.Entra" -Force
    Import-Module -Name "Microsoft.Entra" -Force
}
else {
    Import-Module -Name "Microsoft.Entra" -Force
}
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
$secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
Connect-Entra -AccessToken $secureString
Write-Verbose "Print resource Group name" -Verbose
$resourceGroupName
Write-Verbose "Print resource name" -Verbose
$resourceName
Write-Verbose "Print sub name" -Verbose
$adtSubscriptionID

$resourceGroupName = $resourceGroupName.Trim()
$resourceName = $resourceName.Trim()
$adtSubscriptionID = $adtSubscriptionID.Trim()


if(($resourceGroupName.Equals('999')) -and ($resourceName.Equals('555')))
{
    Write-Verbose "This is for Sub role assignment" -Verbose
    $scope = "/subscriptions/" + $adtSubscriptionID

    
    $subscriptionName =(Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "N/A")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
}
if((!$resourceGroupName.Equals('999')) -and ($resourceName.Equals('555')))
{
    Write-Verbose "This is for RG role assignment" -Verbose
    # "subscriptions/a9dd1f4c-02ec-4488-b59f-fa1c7c6a1caf/resourceGroups/alert-dev-uks-process-rg"
    $scope = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName

    
    $subscriptionName =(Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
}
if((!$resourceGroupName.Equals('999')) -and (!$resourceName.Equals('555')))
{
    Write-Verbose "This is for resource level role assignment" -Verbose
        Set-AzContext -Subscription $adtSubscriptionID
        Get-AzResource -Name $resourceName
        $scope = (Get-AzResource -Name $resourceName).ResourceId
         # "/subscriptions/a9dd1f4c-02ec-4488-b59f-fa1c7c6a1caf/resourceGroups/alert-dev-uks-process-rg/providers/Microsoft.KeyVault/vaults/alert-dev-uks-kv-01"
         # $scope = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName + "/providers/" + $providerName + "/" + $resourceName

         
         $subscriptionName =(Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "$resourceName")
}

$users_value = $adtEmailAddress
$users = $users_value.split(",")
foreach ($user in $users) {
    $user = $user.Trim()
    $user
    #NESO Bug FIX for email format
    $emailAddress =$user
    $emailAddressDomainPart = $emailAddress.SubString($emailAddress.IndexOf("@") + 1)
    $emailAddressUserPart = $emailAddress -split '@' | select-object -index 0
    $domainName = "nationalenergyso.com"

    # Verify domain part
        if ($emailAddressDomainPart -eq $domainName)
        {
        $emailAddress = $emailAddressUserPart  + "@uk.nationalenergyso.com"
        Write-Verbose "NESO Email address is corrected as $emailAddress " -Verbose
        $user = $emailAddress
        }



    Write-Verbose "Print Scope" -Verbose
    $scope
    try {

        if (Get-EntraUser -Filter "mail eq '$user'") {
            $adUser = Get-EntraUser -Filter "mail eq '$user'"
            $SPNAppId = $adUser.ObjectId
            Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope" -Verbose
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT USER" -Verbose
                Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
            Continue;
        } 
        elseif (Get-EntraUser -Filter "userprincipalname eq '$user'") {
            $adUser = Get-EntraUser -Filter "userprincipalname eq '$user'"
            $SPNAppId = $adUser.ObjectId
            Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope" -Verbose
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT USER" -Verbose
                Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
            Continue;
        }
    }
    catch {
        if ( $_.exception | Select-String "The provided information does not map to a role assignment.") {
            Write-Warning  "Assignment does not exist. <$SPNAppId> does not exist as a <$azureRole> at scope $scope"
            Continue;
        }
        else {
            throw  $_
        } 
    }

    try {
        
        if (Get-EntraGroup -Filter "DisplayName eq '$user'") {
            $adGroup = Get-EntraGroup -Filter "DisplayName eq '$user'";
            $SPNAppId = $adGroup.ObjectId
            Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope"
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT GROUP" -Verbose
                Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
            Continue;
        }
    }
    catch {
        if ( $_.exception | Select-String "The provided information does not map to a role assignment.") {
            Write-Warning  "Assignment does not exist. <$SPNAppId> does not exist as a <$azureRole> at scope $scope"
            Continue;
        }
        else {
            throw  $_
        } 
    }

    try {

        if (Get-AzADServicePrincipal -Filter "DisplayName eq '$user'") {
            $adSPN = Get-AzADServicePrincipal -Filter "DisplayName eq '$user'";
            $SPNAppId = $adSPN.Id
            Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope"
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT SPN" -Verbose
                Remove-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
        }
        else { 
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "No users, Entra Groups, or SPNs could be found with this name: $user")
            throw "No users, Entra Groups, or SPNs could be found with this name: $user" }
    }
    
    catch {
        if ( $_.exception | Select-String "The provided information does not map to a role assignment.") {
            Write-Warning  "Assignment does not exist. <$SPNAppId> does not exist as a <$azureRole> at scope $scope"
        }
        else {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
            throw  $_
        } 
    }
}
