<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$subscriptionName,
    [string]$resourceGroupName,
    [string]$resourceName,
    [string]$ownerEmailAddress,
    [string]$region,
    [string]$startDate,
    [int]$days
)


$ErrorActionPreference = 'Stop'

$UpperSubscriptionName = $subscriptionName.ToUpper()

Write-Verbose "Starting PIM Role Assignment" -Verbose

try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose

    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable
    
    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString

    ## Azure Resource PIM Example

    Set-AzContext -Subscription $UpperSubscriptionName
    

    $resourceGroupName = $resourceGroupName.Trim()
    $resourceName = $resourceName.Trim()
    $adtSubscriptionID = (Get-AzSubscription -SubscriptionName $subscriptionName.Trim()).Id

    # Determine Scope - Subscription, Resource Group, or Resource

    if (($resourceGroupName.Equals('999')) -and ($resourceName.Equals('555'))) {
        Write-Verbose "This is for Sub role assignment" -Verbose
        $scopes = "/subscriptions/" + $adtSubscriptionID
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "N/A")
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
    }
    if ((!$resourceGroupName.Equals('999')) -and ($resourceName.Equals('555'))) {
        Write-Verbose "This is for RG role assignment" -Verbose
        $scopes = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
    }
    if ((!$resourceGroupName.Equals('999')) -and (!$resourceName.Equals('555'))) {
        Write-Verbose "This is for resource level role assignment" -Verbose
        Set-AzContext -Subscription $adtSubscriptionID
        Get-AzResource -Name $resourceName
        $scopes = (Get-AzResource -Name $resourceName).ResourceId

        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "$resourceName")
    }


    Write-Verbose "Print ownersEmailAddres variable" -Verbose
    $ownerEmailAddress

    $owners_value = $ownerEmailAddress
    $owners = $owners_value.split(",")

    # Assign Permission for List of Users, Groups, and/or Service Principals
    
    foreach ($owner in $owners) {
        $owner = $owner.Trim()
        $owner

        #NESO Bug FIX for email format
        $emailAddress = $owner
        $emailAddressDomainPart = $emailAddress.SubString($emailAddress.IndexOf("@") + 1)
        $emailAddressUserPart = $emailAddress -split '@' | select-object -index 0
        $domainName = "nationalenergyso.com"

        # Verify domain part
        if ($emailAddressDomainPart -eq $domainName) {
            $emailAddress = $emailAddressUserPart + "@uk.nationalenergyso.com"
            Write-Verbose "NESO Email address is corrected as $emailAddress " -Verbose
            $owner = $emailAddress
        }

        <#
     #Not needed for now
        if ($owner -like "*uk.nationalenergyso.com") {
            $userPrincipal = $emailAddressUserPart +"@uk.nationalgrid.com"
        }
        #>
        if ($owner -like "*us.nationalgrid.com") {
            $userPrincipal = $owner
        }
        elseif ($owner -like "*uk.nationalgrid.com") {
            $userPrincipal = $owner
        }
        elseif (Get-EntraUser -Filter "mail eq '$owner'") {
            $upn = Get-EntraUser -Filter "mail eq '$owner'"
            $userPrincipal = $upn.UserPrincipalName
            $principalID = $upn.ObjectId
            $principalType = "Entra User"
        }
        elseif (Get-EntraUser -Filter "userprincipalname eq '$owner'") {
            $upn = Get-EntraUser -Filter "userprincipalname eq '$owner'"
            $userPrincipal = $upn.UserPrincipalName
            $principalID = $upn.ObjectId
            $principalType = "Entra User"
        }
        elseif (Get-EntraGroup -Filter "DisplayName eq '$owner'") {
            $upn = Get-EntraGroup -Filter "DisplayName eq '$owner'"
            $principalID = $upn.ObjectId
            $principalType = "Entra Group"
        }
        elseif (Get-AzADServicePrincipal -DisplayName $owner) {
            $upn = Get-AzADServicePrincipal -DisplayName $owner
            $principalID = $upn.Id
            $principalType = "Entra Service Principal Name"
        }
        else {
            Write-Warning "Invalid User Principal"
        }
        
        Write-Verbose "User Princial  is $userPrincipal $principalID"  -Verbose
        Write-Verbose "Princial type is $principalType" -Verbose
   
        $subscriptionID = (get-azsubscription -SubscriptionName $UpperSubscriptionName).SubscriptionId

        Write-Verbose "Subscription is $subscriptionID" -Verbose

        $roleDefinitionID = "b24988ac-6180-42a0-ab88-20f7382dd24c" #Built-in Contributor Role Definition ID example
 
        Write-Verbose "Starting PIM PowerShell Process" -Verbose
        #Write-Verbose "Target ID is $principalID" -Verbose

        $reason = "Utilizing PIM Pipeline for Time-Gated Access"

        

        Write-Verbose "Privileged Role Assignment Request initiated" -Verbose
    
        # Create temporary active role assignment
        foreach ($scope in $scopes) {
        
            if ($days -eq 900) {
                $endDate = ((Get-Date).AddHours(4)).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
            }
            else {
                if ($days -gt 90) {
                    
                    Write-Warning "Days can only be set to 30 days at the maximum. Setting to 90 days instead of $days"
                    $days = 90
        
                }
                $endDate = ((Get-Date).AddDays($days)).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
            }
            
            
            foreach ($id in $principalId) {
                #Guid is needed for ID of the PIM request
                $guid = (New-Guid).Guid
                $guid
                $startTime = Get-Date -Date $startDate -Format o

           

                try {
                    Write-Verbose "Checking Assignment Status" -Verbose
                    $ActiveRBAC = Get-AzRoleAssignmentScheduleRequest -Scope $scope -Filter "principalId eq {$id}"
                    $ActiveRBAC
                    $ExistingRole = $ActiveRBAC.RoleDefinitionDisplayName
                    $ExistingRole
                    $ExistingRoleStatus = $ActiveRBAC.Status
                    $ExistingRoleStatus
                    If ($null -eq $ActiveRBAC) {
                        Write-Verbose "New Privileged Role Assignment Request" -Verbose
                        New-AzRoleAssignmentScheduleRequest -Name $guid -Scope $scope -ExpirationEndDateTime $endDate -ExpirationType AfterDateTime -PrincipalId $id -RequestType AdminAssign -RoleDefinitionId subscriptions/$subscriptionID/providers/Microsoft.Authorization/roleDefinitions/$roleDefinitionID -ScheduleInfoStartDateTime $startTime -Justification $reason
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'AssignmentType;issecret=false;isOutput=true', "New")
                    }
            
                    elseif (($ExistingRole -eq "Contributor") -and ($ExistingRoleStatus -eq "Provisioned")) {
                        Write-Verbose "Existing Privileged Role Assignment Request, extending the assignment..." -Verbose
                        New-AzRoleAssignmentScheduleRequest -Name $guid -Scope $scope -ExpirationEndDateTime $endDate -ExpirationType AfterDateTime -PrincipalId $id -RequestType 'AdminExtend' -RoleDefinitionId subscriptions/$subscriptionID/providers/Microsoft.Authorization/roleDefinitions/$roleDefinitionID -ScheduleInfoStartDateTime $startTime -Justification $reason
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'AssignmentType;issecret=false;isOutput=true', "Extension")
            
                    }
                    elseif (($ExistingRole -eq "Contributor") -and ($ExistingRoleStatus -eq "Revoked")) {
                        Write-Verbose "Existing invalid Privileged Role Assignment Request, extending the assignment..." -Verbose
                        New-AzRoleAssignmentScheduleRequest -Name $guid -Scope $scope -ExpirationEndDateTime $endDate -ExpirationType AfterDateTime -PrincipalId $id -RequestType 'AdminAssign' -RoleDefinitionId subscriptions/$subscriptionID/providers/Microsoft.Authorization/roleDefinitions/$roleDefinitionID -ScheduleInfoStartDateTime $startTime -Justification $reason
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'AssignmentType;issecret=false;isOutput=true', "New")
            
                    }
                    elseif (($ExistingRole -eq "Contributor") -and ($ExistingRoleStatus -eq "TimedOut")) {
                        Write-Verbose "Existing invalid Privileged Role Assignment Request, adding the assignment..." -Verbose
                        New-AzRoleAssignmentScheduleRequest -Name $guid -Scope $scope -ExpirationEndDateTime $endDate -ExpirationType AfterDateTime -PrincipalId $id -RequestType 'AdminAssign' -RoleDefinitionId subscriptions/$subscriptionID/providers/Microsoft.Authorization/roleDefinitions/$roleDefinitionID -ScheduleInfoStartDateTime $startTime -Justification $reason
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'AssignmentType;issecret=false;isOutput=true', "New")
            
                    }
                    else {

                        Write-Verbose "An assignment exists with an invalid status or role, please try after sometime"
                    }

                }
                catch {
                    if ( $_.exception | Select-String "The Role assignment already exists") {

                        Write-Warning  "Existing role assignment detected. <$id> is already assigned at scope $scope, Assignment will be extended if the Status and Role is correct and expiring date is within 14 days..."
            
                    }
                    else {
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
                        throw  $_
                    } 
                }
            }
        }
    }
}
catch {
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
    throw  $_
}

