[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$adtSubscriptionID,
    [string]$adtEmailAddress,
    [string]$resourceGroupName,
    [string]$resourceName,
    [string]$azureRole
)

Write-Verbose "Checking for Azure Entra module..." -Verbose

$AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

if ($AzModule -eq $null) {
    Write-Verbose "Azure Entra PowerShell module not found" -Verbose
    #Logging into Azure Entra
    Install-Module -Name "Microsoft.Entra" -Force
    Import-Module -Name "Microsoft.Entra" -Force
}
else {
    Import-Module -Name "Microsoft.Entra" -Force
}
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
$secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
Connect-Entra -AccessToken $secureString
Write-Verbose "Print resource Group name" -Verbose
$resourceGroupName
Write-Verbose "Print resource name" -Verbose
$resourceName
Write-Verbose "Print sub name" -Verbose
$adtSubscriptionID

$resourceGroupName = $resourceGroupName.Trim()
$resourceName = $resourceName.Trim()
$adtSubscriptionID = $adtSubscriptionID.Trim()


if (($resourceGroupName.Equals('999')) -and ($resourceName.Equals('555'))) {
    Write-Verbose "This is for Sub role assignment" -Verbose
    $scope = "/subscriptions/" + $adtSubscriptionID

    $subscriptionName = (Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "N/A")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
}
if ((!$resourceGroupName.Equals('999')) -and ($resourceName.Equals('555'))) {
    Write-Verbose "This is for RG role assignment" -Verbose
    # "subscriptions/a9dd1f4c-02ec-4488-b59f-fa1c7c6a1caf/resourceGroups/alert-dev-uks-process-rg"
    $scope = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName

    $subscriptionName = (Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "N/A")
}
if ((!$resourceGroupName.Equals('999')) -and (!$resourceName.Equals('555'))) {
    Write-Verbose "This is for resource level role assignment" -Verbose
    Set-AzContext -Subscription $adtSubscriptionID
    Get-AzResource -Name $resourceName
    $scope = (Get-AzResource -Name $resourceName).ResourceId
    # "/subscriptions/a9dd1f4c-02ec-4488-b59f-fa1c7c6a1caf/resourceGroups/alert-dev-uks-process-rg/providers/Microsoft.KeyVault/vaults/alert-dev-uks-kv-01"
    # $scope = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName + "/providers/" + $providerName + "/" + $resourceName

    $subscriptionName = (Get-AzSubscription -SubscriptionId $adtSubscriptionID).Name

    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionName;issecret=false;isOutput=true', "$subscriptionName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceGroup;issecret=false;isOutput=true', "$resourceGroupName")
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'resourceName;issecret=false;isOutput=true', "$resourceName")
}

        
# "/subscriptions/a9dd1f4c-02ec-4488-b59f-fa1c7c6a1caf/resourceGroups/alert-dev-uks-process-rg/providers/Microsoft.KeyVault/vaults/alert-dev-uks-kv-01"
# $scope = "/subscriptions/" + $adtSubscriptionID + "/resourceGroups/" + $resourceGroupName + "/providers/" + $providerName + "/" + $resourceName

foreach ($s in $scope) {
    try {
        $users_value = $adtEmailAddress
        $users = $users_value.split(",")
        foreach ($user in $users) {
            $user = $user.Trim()
            $user
            #NESO Bug FIX for email format
            $emailAddress = $user
            $emailAddressDomainPart = $emailAddress.SubString($emailAddress.IndexOf("@") + 1)
            $emailAddressUserPart = $emailAddress -split '@' | select-object -index 0
            $domainName = "nationalenergyso.com"
        
            # Verify domain part
            if ($emailAddressDomainPart -eq $domainName) {
                $emailAddress = $emailAddressUserPart + "@uk.nationalenergyso.com"
                Write-Verbose "NESO Email address is corrected as $emailAddress " -Verbose
                $user = $emailAddress
            }

            Write-Verbose "Print Scope" -Verbose
            $s
            try {

                if (Get-EntraUser -Filter "mail eq '$user'") {
                    $adUser = Get-EntraUser -Filter "mail eq '$user'"
                    $SPNAppId = $adUser.ObjectId
                    New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s" -Verbose
                    <#
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT USER" -Verbose
                New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $s
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $s" -Verbose
            }
            #>
                    Continue;
                } 
                elseif (Get-EntraUser -Filter "userprincipalname eq '$user'") {
                    $adUser = Get-EntraUser -Filter "userprincipalname eq '$user'"
                    $SPNAppId = $adUser.ObjectId
                    New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s" -Verbose
                    <#
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT USER" -Verbose
                New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $s
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $s" -Verbose
            }
            #>
                    Continue;
                }
                else { 
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "No users, AD Groups, or SPNs could be found with this name: $user")
                }
            }

            catch {
                if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
                    Write-Warning  "Duplicate role assignment detected. <$SPNAppId> is already a <$azureRole> at scope $s"
                    Continue;
                }
                else {
                    throw  $_
                } 
            }

            try {
        
                if (Get-EntraGroup -Filter "DisplayName eq '$user'") {
                    $adGroup = Get-EntraGroup -Filter "DisplayName eq '$user'";
                    $SPNAppId = $adGroup.ObjectId
                    New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s"
                    <#
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT GROUP" -Verbose
                New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $s
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $s" -Verbose
            }
            #>
                    Continue;
                }
                else { 
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "No users, AD Groups, or SPNs could be found with this name: $user")
                }
        
            }
            catch {
                if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
                    Write-Warning  "Duplicate role assignment to group detected. <$SPNAppId> is already a <$azureRole> at scope $s"
                    Continue;
                }
                else {
                    throw  $_
                } 
            }

            try {
                Write-Verbose "Print SPNAppId" -Verbose
                if (Get-AzADServicePrincipal -Filter "DisplayName eq '$user'") {
                    $adSPN = Get-AzADServicePrincipal -Filter "DisplayName eq '$user'";
                    $SPNAppId = $adSPN.AppId
                    Write-Verbose "Print SPNAppId" -Verbose
                    $SPNAppId
                    New-AzRoleAssignment -ApplicationId $SPNAppId -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s"
                    <#
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT SPN" -Verbose
                New-AzRoleAssignment -ApplicationId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $s
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $s" -Verbose
            }
            #>
                }
                elseif (Get-AzADApplication -ObjectId "$user" -ErrorAction SilentlyContinue) {
                    $adSPN = Get-AzADApplication -ObjectId "$user"
                    $adSPName = $adSPN.AppId
                    Write-Verbose "Role assignement using Object ID of App Registration" -Verbose
                    New-AzRoleAssignment -ApplicationId $adSPName -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s"
                }
                elseif (Get-AzADServicePrincipal -Filter "Id eq '$user'" -ErrorAction SilentlyContinue) {
                    $adSPN = Get-AzADServicePrincipal -Filter "Id eq '$user'";
                    Write-Verbose "Role assignement using Object ID of Enterprise Application" -Verbose
                    New-AzRoleAssignment -ObjectId $user -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s"
                }
                elseif (Get-AzADServicePrincipal -Filter "appId eq '$user'") {
                    $adSPN = Get-AzADServicePrincipal -Filter "appId eq '$user'";
                    Write-Verbose "Print SPNAppId" -Verbose
                    Write-Verbose "Role assignement using Application ID of SPN" -Verbose
                    New-AzRoleAssignment -ApplicationId $user -RoleDefinitionName $azureRole -Scope $s
                    Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $s"
                }
                else { 
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "No users, AD Groups, or SPNs could be found with this name: $user")
                    throw "No users, AD Groups, or SPNs could be found with this name: $user" 
                }
            }
    
            catch {
                if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
                    Write-Warning  "Duplicate role assignment to group detected. <$SPNAppId> is already a <$azureRole> at scope $s"
                }
                else {
                    throw  $_
                } 
            }
        }
    }
    catch {
        if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
            Write-Warning  "Duplicate role assignment to group detected. <$SPNAppId> is already a <$azureRole> at scope $s"
        }
        else {
            throw  $_
        } 
        
    }
}

    

