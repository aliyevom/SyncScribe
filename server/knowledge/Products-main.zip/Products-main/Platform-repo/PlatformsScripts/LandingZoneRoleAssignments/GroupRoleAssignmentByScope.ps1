<#
.SYNOPSIS
Assign designated RBAC role to assigned Security Group.

.DESCRIPTION
Assign designated RBAC role to assigned Security Group.
The Security Group will be assigned a designated Role at the designated scope.

.PARAMETER ObjectId
Mandatory. Application Id of the Security Group.

.PARAMETER scopeId
Mandatory. The scope of the role assignment

.PARAMETER roleDefinitionName
Mandatory. The role definition name.

.EXAMPLE
 GroupRoleAssignmentByScope.ps1' -roleDefinitionName 'Key Vault Deployment Operator' -ObjectId 'f9013f60-1af2-4c7e-9189-8a87a3f52a5d' -scopeId '/subscriptions/74d15849-ba7b-4be6-8ba1-330a178ba88d/resourceGroups/ng-pd-eus2-keyvault-rg/providers/Microsoft.KeyVault/vaults/ng-prd-eus2-kv-01' 
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ObjectId,
    [string]$roleDefinitionName,
    [string]$scopeId
)

$ErrorActionPreference = 'Stop'

try {

    Get-AzRoleDefinition -Name $roleDefinitionName -Verbose 
    New-AzRoleAssignment -ObjectId $ObjectId -RoleDefinitionName $roleDefinitionName -Scope $scopeId
    Write-verbose  "Role assignment <$roleDefinitionName> for <$ObjectId> created at scope $scopeId"

}
catch {
    if ( $_.exception | Select-String "The role assignment already exists") {
        Write-Warning  "Duplicate role assignment detected. <$ObjectId> is already a <$roleDefinitionName> at scope $scopeId"
    }
    else {
        throw  $_
    } 
}
