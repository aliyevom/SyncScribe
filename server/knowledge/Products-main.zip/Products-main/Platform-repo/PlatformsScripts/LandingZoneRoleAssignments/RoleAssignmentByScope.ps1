<#
.SYNOPSIS
Assign designated RBAC role to assigned SPN.

.DESCRIPTION
Assign designated RBAC role to assigned SPN.
The SPN will be assigned a designated Role at the designated scope.

.PARAMETER SPNAppId
Mandatory. Application Id of the Service Principal.

.PARAMETER scopeId
Mandatory. The scope of the role assignment

.PARAMETER roleDefinitionName
Mandatory. The role definition name.

.EXAMPLE
 RoleAssignments.ps1' -roleDefinitionName 'Key Vault Deployment Operator' -SPNAppId '99e684d8-9213-49e2-bc42-c53a3cae8ab0' -scopeId '/subscriptions/77ba8742-b570-41ca-b5b8-5995dca50847/resourceGroups/ng-npd-eus2-keyvault-rg/providers/Microsoft.KeyVault/vaults/ng-npd-eus2-kv-001' 
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$SPNAppId,
    [string]$roleDefinitionName,
    [string]$scopeId
)

$ErrorActionPreference = 'Stop'

try {

    Get-AzRoleDefinition -Name $roleDefinitionName -Verbose 
    New-AzRoleAssignment -ApplicationId $SPNAppId -RoleDefinitionName $roleDefinitionName -Scope $scopeId
    Write-verbose  "Role assignment <$roleDefinitionName> for <$SPNAppId> created at scope $scopeId"

}
catch {
    if ( $_.exception | Select-String "The role assignment already exists") {
        Write-Warning  "Duplicate role assignment detected. <$SPNAppId> is already a <$roleDefinitionName> at scope $scopeId"
    }
    else {
        throw  $_
    } 
}
