<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$subscriptionName,
    [string]$ownerEmailAddress,
    [string]$roleDefinitionName,
    [string]$region,
    [String]$service_owner,
    [String]$project_manager
)


$ErrorActionPreference = 'Stop'

$UpperSubscriptionName = $subscriptionName.ToUpper()

try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose
    
    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable
    
    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString
    
    if ($ownerEmailAddress -like "*us.nationalgrid.com") {
        $userPrincipal = $ownerEmailAddress
    }
    elseif ($ownerEmailAddress -like "*uk.nationalgrid.com") {
        $userPrincipal = $ownerEmailAddress
    }
    else {
        $upn= Get-EntraUser -Filter "mail eq '$ownerEmailAddress'"
        $userPrincipal = $upn.UserPrincipalName
    }

    #For Service Owner Email
    if ($service_owner -like "*us.nationalgrid.com") {
        $so = $service_owner
    }
    elseif ($service_owner -like "*uk.nationalgrid.com") {
        $so = $service_owner
    }
    else {
        $upnOFSO= Get-EntraUser -Filter "mail eq '$service_owner'"
        $so = $upnOFSO.UserPrincipalName
    }

    #For Project Manager Email
    if ($project_manager -like "*us.nationalgrid.com") {
        $pm = $project_manager
    }
    elseif ($project_manager -like "*uk.nationalgrid.com") {
        $pm = $project_manager
    }
    else {
        $upnOFPM= Get-EntraUser -Filter "mail eq '$project_manager'"
        $pm = $upnOFPM.UserPrincipalName
    }

    Write-Verbose "UPN is $userPrincipal" -Verbose
}
catch {
    throw  $_
}

try {
    
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'newOwnerEmailAddress', $userPrincipal)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'newOwnerEmailAddress;issecret=false;isOutput=true', $userPrincipal)

    Set-AzContext -SubscriptionName $subscriptionName -Verbose

    $ScopeSubscriptionId = (get-azsubscription -SubscriptionName $UpperSubscriptionName).SubscriptionId
    $scope = "/subscriptions/$ScopeSubscriptionId"

    New-AzRoleAssignment -SignInName $userPrincipal -RoleDefinitionName $roleDefinitionName -Scope $scope
    Write-verbose  "Role assignment <$roleDefinitionName> for <$userPrincipal> created at scope $scope"

    New-AzRoleAssignment -SignInName $userPrincipal -RoleDefinitionName "Support Request Contributor" -Scope $scope
    Write-verbose  "Role assignment <Suppport Request Contributor> for <$userPrincipal> created at scope $scope"

    New-AzRoleAssignment -SignInName $userPrincipal -RoleDefinitionName "Monitoring Reader" -Scope $scope
    Write-verbose  "Role assignment <Monitoring Reader> for <$userPrincipal> created at scope $scope"

    New-AzRoleAssignment -SignInName $userPrincipal -RoleDefinitionName "RoleAssignment-Approver" -Scope $scope
    Write-verbose  "Role assignment <RoleAssignment-Approver> for <$userPrincipal> created at scope $scope"

    New-AzRoleAssignment -SignInName $so -RoleDefinitionName "RoleAssignment-Approver" -Scope $scope
    Write-verbose  "RoleAssignment-Approver Role added to Service Owner <$so> created at scope $scope"

    New-AzRoleAssignment -SignInName $pm -RoleDefinitionName "RoleAssignment-Approver" -Scope $scope
    Write-verbose  "RoleAssignment-Approver Role added to Project Manager <$pm> created at scope $scope"

    if($roleDefinitionName -eq 'Reader') {
        New-AzRoleAssignment -SignInName $userPrincipal -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
    }
}
catch {
    if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
        Write-Warning  "Duplicate role assignment detected. <$userPrincipal> is already a <$roleDefinitionName> at scope $scope"
    }
    else {
        throw  $_
    } 
}
