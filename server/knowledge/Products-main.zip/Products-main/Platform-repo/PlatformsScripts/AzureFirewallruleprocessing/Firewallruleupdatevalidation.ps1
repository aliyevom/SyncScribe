<#
.SYNOPSIS
    Firewall Rules Validation

.DESCRIPTION
    The PowerShell script below validates the requested Firewall Rules against the Values provided as Paramters

.PARAMETER Validation
    The Validation is needed or not 

.PARAMETER subscriptionName
    ADT Subscription Name 

.PARAMETER sourceIpAddress
    Source IP address requesting Firewall Rule

.PARAMETER destinationAddresses
    Destination list of FQDNs or Network IPs (Comma separated)

.PARAMETER protocol
    Protocol a requirement for outbound Access TCP/UDP/ICMP/HTTPS

.PARAMETER outboundPorts
   Comma Separated Destination Ports required by Application.

.PARAMETER VNETName
   Virtual Network Name
   .PARAMETER Region
   Resource Region Name

.EXAMPLE

.NOTES
	Version      : 1.1.0
	Last Updated : 4/8/2025
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$Validation,
    [string]$subscriptionName,
    [string]$RuleType,
    [string]$SourceIPAddresses,
    [string]$destinationAddresses,
    [string]$protocol,
    [string]$outboundPorts,
    [string]$VNetName,
    [string]$region
)

function Get-VNET {


    <#
    .SYNOPSIS
    Fetch allocated Prefixes from The Nautobot for the VNET under Firewall whitelsiting request

    .DESCRIPTION
    This function takes Virtual Network Name as input and return the allocated Prefixes of the Virtual Network from the Nautobot
    The Function usage Nautobot API to get the allocated prefixes

    .PARAMETER VNETName
    The Virtual Network Name of the Source IP Addresses

    .EXAMPLE
    Get-VNET -VNETName "03771u-qa-ukw-vnet-02"
    This will return the api output from the nautobot which includes the allocated prefixes

    .NOTES
	Version      : 1.1.0
    Author: CPET Team
    #>

    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETName
    )
    $ErrorActionPreference = "Stop";
    $VNETName =$VNETName.ToLower()
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?tags=" + $VNETName + "&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}


function ConvertFrom-IPToInt64 {
    <#
    .SYNOPSIS
    Converts an IPv4 address from dotted-decimal format to a 64-bit integer.

    .DESCRIPTION
    This function takes an IPv4 address as input and converts it into a 64-bit integer.
    The conversion is done by splitting the IP address into its four octets and calculating
    the integer value based on the position of each octet.

    .PARAMETER ip
    The IPv4 address in dotted-decimal format (e.g., "192.168.1.1").
    This parameter is mandatory.

    .EXAMPLE
    ConvertFrom-IPToInt64 -ip "192.168.1.1"
    This will return the integer representation of the IP address "192.168.1.1".

    .NOTES
	Version      : 1.1.0
    Author: CPET Team
    
    #>

    param (
        [Parameter(Mandatory = $True)]
        [string]$ip
    )
    # Split the IP address into its four octets
    $octets = $ip.Split(".")
    # Calculate the integer value by summing the contributions of each octet
    return [int64]([int64]$octets[0] * 16777216 + [int64]$octets[1] * 65536 + [int64]$octets[2] * 256 + [int64]$octets[3])
}

function Compare-IPInRange {
    <#
        .SYNOPSIS
        Compares an IP address to see if it falls within a specified CIDR range.

        .DESCRIPTION
        This function checks if a given IP address is within a specified range defined in CIDR notation.
        It validates the input IP address and the CIDR range, then performs the comparison.

        .PARAMETER IPAddress
        The IP address to check. This must be a valid IPv4 address.

        .PARAMETER Range
        The range in which to search, specified in CIDR notation (e.g., "192.168.1.0/24").
        This parameter is mandatory and must be a valid CIDR format.

        .EXAMPLE
        Compare-IPInRange -IPAddress "192.168.1.10" -Range "192.168.1.0/24"
        This will return true, indicating that the IP address "192.168.1.10" is within the range "192.168.1.0/24".

        .NOTES
	Version      : 1.1.0
        Author: CPET Team
        
        #>
    [cmdletbinding()]
    [outputtype([System.Boolean])]
    param(
        # IP Address to find.
        [parameter(Mandatory,
            Position = 0)]
        [validatescript({
            ([System.Net.IPAddress]$_).AddressFamily -eq 'InterNetwork'
            })]
        [string]
        $IPAddress,

        # Range in which to search using CIDR notation. (ippaddr/bits)
        [parameter(Mandatory,
            Position = 1)]
        [validatescript({
                $IP = ($_ -split '/')[0]
                $Bits = ($_ -split '/')[1]

            (([System.Net.IPAddress]($IP)).AddressFamily -eq 'InterNetwork')

                if (-not($Bits)) {
                    throw 'Missing CIDR notation.'
                }
                elseif (-not(0..32 -contains [int]$Bits)) {
                    throw 'Invalid CIDR notation. The valid bit range is 0 to 32.'
                }
            })]
        [alias('CIDR')]
        [string]
        $Range
    )

    # Split range into the address and the CIDR notation
    [String]$CIDRAddress = $Range.Split('/')[0]
    [int]$CIDRBits = $Range.Split('/')[1]

    # Address from range and the search address are converted to Int32 and the full mask is calculated from the CIDR notation.
    [int]$BaseAddress = [System.BitConverter]::ToInt32((([System.Net.IPAddress]::Parse($CIDRAddress)).GetAddressBytes()), 0)
    [int]$Address = [System.BitConverter]::ToInt32(([System.Net.IPAddress]::Parse($IPAddress).GetAddressBytes()), 0)
    [int]$Mask = [System.Net.IPAddress]::HostToNetworkOrder(-1 -shl ( 32 - $CIDRBits))

    # Determine whether the address is in the range.
    if (($BaseAddress -band $Mask) -eq ($Address -band $Mask)) {
        return "$true,  $IPAddress is a part of $Range."
    } 
    else {
        return "$false,  $IPAddress is not part of $Range"
    }
}
#Example:
#Compare-IPInRange -IPAddress 10.92.2.10 -Range 10.92.2.0/28
function ConvertTo-IPAddressInt {
    <#
    .SYNOPSIS
    Converts an IPv4 address from dotted-decimal format to a UInt32 integer.

    .DESCRIPTION
    This function takes an IPv4 address as input and converts it into a UInt32 integer.
    The conversion is done by parsing the IP address, reversing the byte order to little-endian,
    and then converting the byte array to an unsigned integer.

    .PARAMETER ip
    The IPv4 address in dotted-decimal format (e.g., "192.168.1.1").
    This parameter is mandatory.

    .EXAMPLE
    ConvertTo-IPAddressInt -ip "192.168.1.1"
    This will return the integer representation of the IP address "192.168.1.1".

    .NOTES
	Version      : 1.1.0
    Author: CPET Team
    
    #>
    param ($ip)
    $bytes = [IPAddress]::Parse($ip).GetAddressBytes()
    [Array]::Reverse($bytes)  # Little-endian order for UInt32
    return [BitConverter]::ToUInt32($bytes, 0)
}
function Get-NetworkRange {

    <#
    .SYNOPSIS
    Calculates the start and end IP addresses of a network range based on CIDR notation.

    .DESCRIPTION
    This function takes a CIDR notation (e.g., "192.168.1.0/24") as input and calculates
    the starting and ending IP addresses of the network range. It converts the base IP address
    to an integer, computes the subnet mask, and determines the range of host addresses.

    .PARAMETER cidr
    The CIDR notation representing the network (e.g., "192.168.1.0/24").
    This parameter is mandatory.

    .EXAMPLE
    Get-NetworkRange -cidr "192.168.1.0/24"
    This will return a hashtable containing the start and end IP addresses of the network range.

    .NOTES
	Version      : 1.1.0
    Author: CPET Team
    
    #>
    param ($cidr)
    $parts = $cidr -split '/'
    $baseIp = $parts[0]
    $prefix = [int]$parts[1]
    $ipInt = ConvertTo-IPAddressInt $baseIp
    $hostBits = 32 - $prefix
    $mask = [uint32]([math]::Pow(2, 32) - [math]::Pow(2, $hostBits))
    $networkStart = $ipInt -band $mask
    $hostCount = [uint32][math]::Pow(2, $hostBits)
    $networkEnd = $networkStart + $hostCount - 1
    return @{
        Start = $networkStart
        End   = $networkEnd
    }
}


function Test-SubnetInclusion {
    <#
    .SYNOPSIS
    Tests if a given subnet is included within a specified virtual network range.

    .DESCRIPTION
    This function checks if a subnet defined in CIDR notation is fully contained within
    a specified virtual network range, also defined in CIDR notation. If the input is
    an IP address, it checks if that IP address is included in the virtual network range.

    .PARAMETER SubnetCIDR
    The CIDR notation of the subnet to check (e.g., "192.168.1.0/24" or an individual IP address).

    .PARAMETER VnetCIDR
    The CIDR notation of the virtual network range (e.g., "192.168.0.0/16").

    .EXAMPLE
    Test-SubnetInclusion -SubnetCIDR "192.168.1.0/24" -VnetCIDR "192.168.0.0/16"
    This will return true, indicating that the subnet "192.168.1.0/24" is within the virtual network "192.168.0.0/16".

    .NOTES
	Version      : 1.1.0
    Author: CPET Team
    
    #>
    param (
        [string]$SubnetCIDR,
        [string[]]$VnetCIDR
    )

    # Check if SubnetCIDRS is an IP address
    if ($SubnetCIDR -match "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$") {
        write-output "SourceAddress Is an IP Address" -Verbose
        return Check-IPInCIDR -IPAddress $SubnetCIDR -CIDR $VnetCIDR
    }

    $VNetRange = Get-NetworkRange $VnetCIDR
    $SubnetRange = Get-NetworkRange $SubnetCIDR
    if ($SubnetRange.Start -ge $VNetRange.Start -and $SubnetRange.End -le $VNetRange.End) {
        return "$true,$SubnetCIDR is within $VnetCIDR"
    }
    else {
        return "$false,$SubnetCIDR is NOT within $VnetCIDR"
    }
    
    return "$false, The prefixes do not match or overlap."
}

function Test-AzFqdnTag {
    <#
    .SYNOPSIS
    Validates if a specified tag is a valid Azure Fully Qualified Domain Name (FQDN) tag.

    .DESCRIPTION
    The Test-AzFqdnTag function checks if the provided tag exists in the list of available Azure FQDN tags.
    It retrieves all FQDN tags from Azure and performs a case-insensitive comparison to determine if the 
    specified tag is valid. If the tag is valid, it outputs a confirmation message; otherwise, it provides 
    a message indicating the tag is not valid and lists some valid tags.

    .PARAMETER TagToValidate
    The tag that you want to validate against the available Azure FQDN tags. This parameter is mandatory.

    .EXAMPLE
    Test-AzFqdnTag -TagToValidate "azurebackup"
    This command checks if "azurebackup" is a valid Azure FQDN tag.
    #>

    param (
        [Parameter(Mandatory = $true)]
        [string]$TagToValidate
    )

    try {
        # Retrieve all available FQDN tags
        $fqdnTags = Get-AzFirewallFqdnTag
        
        if (-not $fqdnTags) {
            Write-Host "No FQDN tags found." 
            return "$false, The prefixes are equal."
        }

        # Normalize names for case-insensitive comparison
        $validTags = $fqdnTags.Name

        # Check for case-insensitive match
        if ($validTags -contains $TagToValidate -or ($validTags | Where-Object { $_ -ieq $TagToValidate })) {
            Write-Host "'$TagToValidate' is a valid Azure FQDN Tag."
            return "$true, a valid Azure FQDN Tag.." 
        }
        else {
            Write-Host "'$TagToValidate' is NOT a valid Azure FQDN Tag." 
            return "$false, NOT a valid Azure FQDN Tag."
        }
    }
    catch {
        Write-Host "Error: $_"
        return $_
    }
}

# Example usage
# Test-AzFqdnTag -TagToValidate "azurebackup"

function Test-AzServiceTag {
    <#
    .SYNOPSIS
    Validates if a specified service tag is valid for a given Azure region.

    .DESCRIPTION
    The Test-AzServiceTag function checks if the provided service tag exists in the list of available 
    Azure service tags for a specified region. It maps the region input to the corresponding Azure 
    location and retrieves the service tags for that location. The function performs a case-insensitive 
    comparison to determine if the specified tag is valid. If the tag is valid, it outputs a confirmation 
    message; otherwise, it provides a message indicating the tag is not valid and lists some valid tags.

    .PARAMETER region
    The Azure region for which you want to validate the service tag. This parameter is mandatory.

    .PARAMETER TagToValidate
    The service tag that you want to validate against the available Azure service tags. This parameter is mandatory.

    .EXAMPLE
    Test-AzServiceTag -region "eus2" -TagToValidate "AzureBackup"
    This command checks if "AzureBackup" is a valid Azure service tag in the East US 2 region.
    #>

    param (
        [Parameter(Mandatory = $true)]
        [string]$region,
        [Parameter(Mandatory = $true)]
        [string]$TagToValidate
    )

    try {
        # Mapping of region codes to Azure locations
        $regionMap = @{
            "eus2" = "Eastus2"
            "cus"  = "centralus"
            "uks"  = "uksouth"
            "ukw"  = "ukwest"
        }

        # Retrieve the corresponding location from the region map
        $location = $regionMap[$region]  # This will return $null if the region is not found

        # Check if the location is valid
        if (-not $location) {
            Write-Output "Invalid Location"
            return "$false, NOT a valid Location"
        }

        # Get service tags for the specified location
        $serviceTags = Get-AzNetworkServiceTag -Location $Location
        if (-not $serviceTags) {
            Write-Host "No service tags found for location: $Location" 
            return "$false, NO service tags found for location"
        }

        # Flatten the list of service tag names
        $validTags = $serviceTags.Values.Name

        # Case-insensitive comparison
        if ($validTags | Where-Object { $_ -ieq $TagToValidate }) {
            Write-Host "'$TagToValidate' is a valid Azure Service Tag in region '$Location'." 
            return "$true, is a valid Azure Service Tag in region"
        }
        else {
            Write-Host "'$TagToValidate' is NOT a valid Azure Service Tag in region '$Location'." 
            return "$false,Not a valid Azure Service Tag in region"
        }
    }
    catch {
        Write-Host "Error: $_"
        return $_
    }
}
# Example usage
# Test-AzServiceTag -region "eus2" -TagToValidate "AzureBackup"


try {
    if ($Validation -eq 'true') {


        $SuccessfullValidations = New-Object System.Collections.Generic.List[System.Object]
        $FailedValidations = New-Object System.Collections.Generic.List[System.Object]
        <#
        ## Define Regular Expression for each input types for validation.
        ## The Regex in $SourceIPPattern, $DestinationIPPattern , $PortsPattern are also getting validated in ServiceNow Catalog
        #
        # $SourceIPPattern: Matches source IP addresses, including private IP ranges (10.x.x.x, 172.16.x.x to 172.31.x.x, 192.168.x.x),
        # optional CIDR notation, and allows for multiple comma-separated entries.
        #
        # $DestinationIPPattern: Matches destination IP addresses similar to $SourceIPPattern but also includes domain names
        # (e.g., *.example.com) and allows for multiple comma-separated entries.
        #
        # $PortsPattern: Matches valid port numbers, including single ports (1-65535), comma-separated lists of ports,
        # and ranges of ports (e.g., 1000-2000).
        #
        # $IPPattern: Matches valid IPv4 addresses in the range of 0.0.0.0 to 255.255.255.255.
        #
        # $CIDRPattern: Matches CIDR notation for IP addresses, ensuring the first three octets are valid (0-255)
        # and the CIDR prefix length is between 1 and 31.
        #
        # $URLPattern: Matches valid URLs, allowing for optional http/https and www, and specific top-level domains (TLDs)
        # such as com, net, cloud, org, ms, and ai.
        #
        # $PrivateIPPattern: Matches private IP addresses defined by the ranges 10.x.x.x, 172.16.x.x to 172.31.x.x,
        # and 192.168.x.x.
        #>
        #$SourceIPPattern - This regex define pattern for valid IP Adrees, CIDR Blocks comma separated and may includes white spaces in between
        $SourceIPPattern = "^((10\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(192\.168\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|((\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?))(,\s*((10\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(192\.168\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|((\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?)))*$"
        #$DestinationIPPattern - This regex define pattern for valid IP Adrees, CIDR Blocks, Base URL without https:// comma separated and may includes white spaces in between
        $DestinationIPPattern = "^((10\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(192\.168\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|((\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?)|((\*\.)?[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+))(,\s*((10\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|(192\.168\.\d{1,3}\.\d{1,3}(\/\d{1,2})?)|((\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?)|((\*\.)?[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+)))*$"
        #$PortsPattern - This regex define pattern for valid comma separated port numbers and may includes white spaces in between
        $PortsPattern = "^((?:[1-9][0-9]{0,4}|[1-5][0-9]{0,3}|[0-9]{1,4})(?:,(?:[1-9][0-9]{0,4}|[1-5][0-9]{0,3}|[0-9]{1,4}))*)$|^([1-9][0-9]{0,4}-[1-9][0-9]{0,4})$"
        #$IPPattern - This Regex checks if the Provided Input is in IP Address Format
        $IPPattern = "^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)\.?\b){4}$"
        #$CIDRPattern - This Regex checks if the provided Input is a CIDR IP Block
        $CIDRPattern = "(([1-9]{0,1}[0-9]{0,2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]{0,1}[0-9]{0,2}|2[0-4][0-9]|25[0-5])\/([1-2][0-9]|3[0-1])"
        #$URLPattern - This Regex define pattern for a valid URL without https://
        $URLPattern = "((^(http[s]?:\/\/)?([w]{3}[.])?(([a-z0-9-\.]+)+(com|net|cloud|org|ms|ai|edu|gov|io|uk|eu)))$)"
        #$WildcardURLPattern - This Regex define pattern for a wild card URL for example *.google.com, *google.com
        $WildcardURLPattern ="^(\*\.)?\*?[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+$"
        #$PrivateIPPattern- This Regex define pattern for a valid Private IP Address
        $PrivateIPPattern = "^(10\.(?:[0-9]{1,3}\.){2}[0-9]{1,3})|^(172\.(?:1[6-9]|2[0-9]|3[01])\.(?:[0-9]{1,3}\.){1}[0-9]{1,3})|^(192\.168\.(?:[0-9]{1,3}\.){1}[0-9]{1,3})$"
        
        #Validate if the Provided region and VNET region are same to avoid the rule update in wrong Firewall
        $VNetRegion = $VNetName -split '-'
        if ($VNetRegion[2] -ne $region) {
            Write-Output "Region Validation Failed. VNET Region is not matching with Region Paramter" -Verbose
            $FailedValidations.Add("Failure: Selected Region - $region  and VNET Region - $($VNetRegion[2]) - Invalid Region ")
        }
        else {
            Write-Output "Region Validation Succeeded" -Verbose
            $SuccessfullValidations.Add("Success: Region - $region and VNETRegion - $($VNetRegion[2]) - Valid Region ")
        }
        #Validate if the source addresses format is correct or not. 
        #Same  Regex validation is also happening in the ServiceNow Catalog
        if ($sourceIpAddresses -match $SourceIPPattern) {
            Write-Output "sourceIpAddresses= $sourceIpAddresses" -Verbose
            $SuccessfullValidations.Add("Success: Source Addresses $sourceIpAddresses - Valid Format ")

        }
        else {
            Write-Output "Invalid sourceIpAddresses= $sourceIpAddresses" -Verbose
            $FailedValidations.Add("Failure: Source Addresses $sourceIpAddresses - Invalid Format ")
        }
        #Validate if the Destination addresses format is correct or not. 
        #Same  Regex validation is also happening in the ServiceNow Catalog
        if ((($RuleType -ieq "NetworkRule") -or ($RuleType -ieq "ApplicationRule")) -and ( $destinationAddresses -match $DestinationIPPattern)) {

            $SuccessfullValidations.Add("Success: destination Addresses $destinationAddresses - Valid Format ")
        }
        #This is intentional skip since the destination Addresses with tags are not included in ServiceNow Catalog.
        #No regex validation needed here since we are doing actual Value Validation later in this script
        elseif (($RuleType -ieq "FQDNTags") -or ($RuleType -ieq "servicetags")) {
            Write-Output "No format validation required, actual validation is happening for fqdn tags and Service Tags" -Verbose

        }
        else {
            Write-Output "Invalid destinationAddresses = $destinationAddresses" -Verbose
            $FailedValidations.Add("Failure: destination Addresses $destinationAddresses - Invalid Format ")
        }

        <#
        ##PORT Validation logic
        # This Validatiocn checks:
        # - Individual port numbers (1-65535)
        # - Comma-separated lists of valid port numbers
        # - Ranges of ports (e.g., 1000-2000)
        #>

        #Validate if the Outbound Ports format is correct or not. 
        if ( $outboundPorts -match $PortsPattern) {

            $SuccessfullValidations.Add("Success: outbound Ports $outboundPorts - Valid Format ")
        }
        else {
            Write-Output "Invalid outboundPorts= $outboundPorts" -Verbose
            $FailedValidations.Add("Failure: Outbound Ports $outboundPorts - Invalid Format ")
        }

        # Split the input string by commas to check each port individually
        $portsArray = $outboundPorts -split ','
        $portsArray
        # Iterate through each port in the array
        foreach ($port in $portsArray) {
            # Trim whitespace from the port string
            $port = $port.Trim()
            $port
            # Validate each port number against the regex pattern
            if ($port -match $PortsPattern) {

                # Check if the port is a range (contains a hyphen)
                if ($port -like "*-*") {
                    # Extract the start and end of the range
                    $rangeParts = $port -split '-'
                    $startPort = [int]$rangeParts[0]  # Convert start port to integer
                    $endPort = [int]$rangeParts[1]      # Convert end port to integer

                    # Validate the range to ensure both ports are within valid limits
                    if ($startPort -ge 1 -and $endPort -le 65535 -and $startPort -le $endPort) {

                        if ($startPort -le 80 -and $endPort -ge 80) {
                            $FailedValidations.Add("Failure: Port 80 is not allowed: Remove port 80 from $port & Resubmit the request ")
                        }
                        else {
                        Write-Output "Valid port range: $port"  # Output valid range
                        $SuccessfullValidations.Add("Success:  $port - Valid port range ")
                    }         # Check if the range includes 80
                       
                    }
                    else {
                        Write-Output "Invalid port range: $port. Port numbers must be between 1 and 65535."
                        $FailedValidations.Add("Failure: Invalid port range: $port ,range must be between 1 and 65535 except 80")
                            
                    }
                }
                else {
                    # Validate individual port number
                    $portNumber = [int]$port  # Convert port to integer
                    if ($portNumber -ge 1 -and $portNumber -le 65535) {
                        if ($portNumber -eq "80") {
                            $FailedValidations.Add("Failure: Port 80 is not allowed: correct $port & Resubmit the request ")
                        }
                        else {
                            
                        
                        Write-Output "Valid port number: $port"  # Output valid port number
                        $SuccessfullValidations.Add("Success:  $port - Valid port Number ")
                    }
                    }
                    else {
                        Write-Output "Invalid port number: $port. Port numbers must be between 1 and 65535 except 80."
                        $FailedValidations.Add("Failure: Invalid port Number: $port ,must be between 1 and 65535 except 80 ")
                        
                    }
                }
            }
            else {
                Write-Output "Invalid port format: $port. Please provide valid port numbers."
                $FailedValidations.Add("Failure: $port - Invalid port format ")
                    
            }
        }


        <#
        ## NAUTOBOT API Calls for GET-VNET Function
        ## Fetching Credential to Connect to API
        #>
        $KeyVaultName = 'ng-prd-eus2-kv-01'
        $PATSecretName = 'GBL-SVC-NAUTOBOT-PAT'

        Set-AzContext -Subscription "US-HUB-Prod-01" | Out-Null
        $PAT = `
            Get-AzKeyVaultSecret `
            -VaultName $KeyVaultName `
            -Name $PATSecretName `
            -ErrorAction Stop;
        Write-Host "getting PAT  from KV " -Verbose
        $PATValue = $PAT.SecretValue
        Write-Host "$PATValue " -Verbose
        if ($PATValue) {
            Write-Host "Retrieved PAT  from KV " -Verbose
            $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
            $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
        }
        else {
            { Write-Host "PAT is not found. please check the PAT Secret Value" }
        }
        #Fetching allocated VNET Prefixes from nautobot
        Write-Output " Getting VNET Prefixes from the NAUTOBOT $($VNetName)"
        $GetAssignedPrefix = Get-VNET -VNETName $VNetName
        $GetAssignedPrefix
        $AssignedPrefixresults = $GetAssignedPrefix.results
        $addressPrefixes = $AssignedPrefixresults.prefix
        Write-Output "The VNET Address Prefixes are '$addressPrefixes'" -Verbose
        # validating If All the provided comma seperated Source IP/Prefixes are part of the VNET in the request
        $sourceIpAddresses1 = $SourceIPAddresses -split ','
        #Fetched comma seperated Individual IPs/CIDR and looping through each one
        foreach ($SourceIPAddress in $sourceIpAddresses1) {
            $sourceIpvalidation = $false
            $SourceIPAddress
            #Validating if it is valid CIDR and check if it is from the VNET address
            if ($sourceIpAddress -match $CIDRPattern) {
                Write-output "The provided Source IP: $SourceIPAddress is a CIDR Address Prefix" -Verbose
                $SuccessfullValidations.Add("Success: $sourceIpAddress - Valid SourceIP CIDR Pattern ")

                foreach ($addressPrefix in $addressPrefixes) {
                    $addressPrefix
                    $SourceIPAddress
                    $SIPPVResponse = Test-SubnetInclusion -VnetCIDR $addressPrefix -SubnetCIDR $SourceIPAddress
                    write-output "Prefixes validation Output is : $SIPPVResponse" -Verbose
                    $SIPPVResponse1 = $SIPPVResponse -split ","

                    if ($SIPPVResponse1[0] -eq "True") {
                        write-output "Range Validation for Source IP : $sourceIpAddress with $addressPrefix is Succeeded" -Verbose
                        $SuccessfullValidations.Add("Success: $sourceIpAddress - Valid SourceIP Range from $addressPrefix ")
                        $sourceIpvalidation = $true
                    }
                }

                if (!$sourceIpvalidation) {
                    write-output "Range Validation for Source IP : $sourceIpAddress with $addressPrefixes failed" -Verbose
                    $FailedValidations.Add("Failure: $sourceIpAddress - SourceIP Invalid Range, not matching with VNET Addresses $addressPrefixes ")
                }
            }
            #Validating if it is valid IP Address and check if it is from the VNET address           
            elseif ($sourceIpAddress -match $IPPattern) {
                Write-output "The provided Source IP: $SourceIPAddress is an IP Address" -Verbose
                $SuccessfullValidations.Add("Success: $sourceIpAddress - SourceIP Valid IP Pattern ")
                foreach ($addressPrefix in $addressPrefixes) {
                    $SIPAVResponse = Compare-IPInRange -IPAddress $sourceIpAddress -Range $addressPrefix
                    write-output "Prefixes validation Output is : $SIPAVResponse" -Verbose
                    $SIPAVResponse1 = $SIPAVResponse -split ","

                    if ($SIPAVResponse1[0] -eq "True") {
                        write-output "Range Validation for Source IP : $sourceIpAddress with $addressPrefix is Succeeded" -Verbose
                        $SuccessfullValidations.Add("Success: $sourceIpAddress - Source IP is a Valid IP from VNET $addressPrefix ")
                        $sourceIpvalidation = $true
                    }
                }

                if (!$sourceIpvalidation) {
                    write-output "Range Validation for Source IP : $sourceIpAddress with $addressPrefixes failed" -Verbose
                    $FailedValidations.Add("Failure: $sourceIpAddress - SourceIP is not matching with VNET Addresses $addressPrefixes ")
                }
            }

            else {

                $FailedValidations.Add("Failure: $sourceIpAddress - InValid SourceIP Pattern")
            }
        }
        #Splitting the comma seprated destination addresses and checking if the Provided output is either a Public IP/CIDR or and URL
        $DestinationIPs =@()
        $DestinationURLs =@()
        $DestinationWildCards = @()
        if (($RuleType -ieq "NetworkRule") -or ($RuleType -ieq "ApplicationRule")) {
            $destinationAddresses1 = $destinationAddresses -split ','
            foreach ($destinationAddress in $destinationAddresses1) {
                $destinationAddress1 = $destinationAddress.Trim()
                $destinationAddress1
                $destinationAddressparts1 = $destinationAddress1 -split "/"
                $destinationAddressBits1 = $destinationAddressparts1[0]
                $destinationAddressBits1
                #check if Destination address matches the required Pattern & store it into respective category variable
                if ($destinationAddress1 -imatch $URLPattern) {
                    write-output "The destination Address: $destinationAddress1 is an URL" -Verbose
                    $DestinationURLs += $destinationAddress1
                    $SuccessfullValidations.Add("Success: $destinationAddress1 - Valid Destination URL Pattern ")
                    
                }
                elseif ($destinationAddress1 -match $IPPattern -and $destinationAddress1 -inotmatch $PrivateIPPattern ) {
                    write-output "The destination Address: $destinationAddress1 is a Public IP Address" -Verbose
                    $DestinationIPs += $destinationAddress1
                    $SuccessfullValidations.Add("Success: $destinationAddress1 - Valid Destination Public IP Pattern ")
                }
                elseif ($destinationAddress1 -match $CIDRPattern -and $destinationAddressBits1 -inotmatch $PrivateIPPattern) {
                    write-output "The destination Address: $destinationAddress1 is a Public CIDR Prefix" -Verbose
                    $SuccessfullValidations.Add("Success: $destinationAddress1 - Valid Destination Public IP CIDR Pattern ")

                }
                elseif ($destinationAddress1 -imatch $WildcardURLPattern)
                {
                    write-output "The destination Address: $destinationAddress1 is a Wild Card URL" -Verbose
                    $DestinationWildCards += $destinationAddress1
                    #Network rule does not allow windcard in Network FQDN Whiltelisting
                    if($RuleType -ieq "NetworkRule")
                    {
                        write-output "The destination Address: $destinationAddress1 has wildcard and is not permitted in Network FQDNs" -Verbose
                        $FailedValidations.Add("Failure: $destinationAddress1 - Wild Card URLs(*) are not permitted in Network FQDNs")
                    }
                    else {
                    
                    Write-output "The destination Address: $destinationAddress1 is a Wild Card URL and Requested Rule is not a network rule" -Verbose
                    $SuccessfullValidations.Add("Success: $destinationAddress1 - Valid Destination Wild Card URL Pattern ")
                    }
                }
                else {
                    $FailedValidations.Add("Failure: $destinationAddress1 - Invalid destination address Pattern")
                }
            }
        }
        #FQDNTag & Service TagValidation Section
        <#
        ##Pull out the Tags from Azure and then validate if input tags are in the tag list, pulled from Azure
        #>

        if (($RuleType -ieq "FQDNTags") -or ($RuleType -ieq "servicetags")) {
            Write-Output " Initiating Tag Validation" -Verbose
            $Tagvalues1 = $destinationAddresses -split ','
            foreach ($tagvalue in $Tagvalues1) {
                if ($RuleType -ieq "FQDNTags") {
                    $fqdnTagVResponse = Test-AzFqdnTag -TagToValidate $tagvalue
                    write-output "fqdnTag validation Output is : $fqdnTagVResponse" -Verbose
                    $fqdnTagVResponse1 = $fqdnTagVResponse -split ","

                    if ($fqdnTagVResponse1[0] -eq "True") {
                        write-output "fqdnTag Validation for fqdn Tag : $tagvalue is Succeeded" -Verbose
                        $SuccessfullValidations.Add("Success: $tagvalue - Valid fqdn Tag ")
                    }
                    else {
                        Write-Output "The FQDN Tag is not valid"
                        $FailedValidations.Add("Failure: $tagvalue - Invalid FQDN Tags")
                    }
                }
                if ($RuleType -ieq "servicetags") {
                    $serviceTagVResponse = Test-AzServiceTag -TagToValidate $tagvalue -region $region
                    write-output "ServiceTag validation Output is : $serviceTagVResponse" -Verbose
                    $serviceTagVResponse1 = $serviceTagVResponse -split ","
    
                    if ($serviceTagVResponse1[0] -eq "True") {
                        write-output "ServiceTag Validation for Tag : $tagvalue is Succeeded" -Verbose
                        $SuccessfullValidations.Add("Success: $tagvalue - Valid Service Tag ")
                        $TagValidation = $true
                    }
                    else {
                        Write-Output "The FQDN Tag is not valid"
                        $FailedValidations.Add("Failure: $tagvalue - Invalid Service Tags")
                    }

                }

            }

        }
        else {
            Write-Output "The Tag Validation is skipped"
        }

        <#
        ##  Validate Port and Protocol requirements for various rule types
        ##
        ## Networkrule, ServiceTags requires Protocol ="TCP", "UDP","ICMP","Any"
        ## Networkfqdn will not work from script, it requires firewall proxy - 
        ##Applicationrule contains Protocol http,https,mssql & port is not needed
        ## FQDNtags Rule requires protocol ="https" 
        #>

        #Check Protocol requirements for fqdnTags
        if ($RuleType -ieq "FQDNTags") {
            if ($protocol -contains "https") {
                write-output "The FQDN Tags request has the correct Protocol https"  -Verbose
                $SuccessfullValidations.Add("Success: Valid Protool for FQDN Tags ")
            }
            else {
                write-output "The FQDN Tags request has the incorrect Protocol, it will be corrected to https"  -Verbose
                $SuccessfullValidations.Add("Success: $destinationAddress1 - Protool for FQDN Tags will be corrected to https")
            }
        }

        #Check Protocol requirements for Application rule
        $Protocol1 = $protocol -split ','
        $Protocol1 = $Protocol1.Trim()
        # Initialize a flag to track if any invalid protocol is found
        $foundValidProtocol = $false
        foreach ($checkprotocol in $Protocol1) {
            if ($RuleType -ieq "ApplicationRule") {
                # Define valid protocols
                $validProtocols = @("https", "mssql")

                # Check if the protocol is in the list of valid protocols
                if ($validProtocols -contains $checkprotocol) {
                    Write-Output "Valid protocol found in ApplicationRule: $checkprotocol"
                    $SuccessfullValidations.Add("Success: Valid Protool $checkprotocol for application rule ")
                    $foundValidProtocol = $true  # Set the flag to true if a valid protocol is found
                }
                else {
                    Write-Output "InValid protocol found for Application rule: $checkprotocol"
                    $foundValidProtocol = $false  # Set the flag to true if a valid protocol is found
                    $FailedValidations.Add("Failure: Invalid Protocol $checkprotocol for Application rule, Valid Values are https, mssql")
                    #break;
                }
            }

            #Check Protocol requirements for Network collection rules
            if (($RuleType -ieq "servicetags") -or ($RuleType -ieq "NetworkRule")) {
                # Define valid protocols
                $validProtocols = @("tcp", "udp", "icmp", "any")
                # Check if the protocol is in the list of valid protocols
                if ($validProtocols -contains $checkprotocol) {
                    Write-Output "Valid protocol found for $RuleType : $checkprotocol"
                    $SuccessfullValidations.Add("Success: Valid Protool $checkprotocol for $RuleType ")
                    $foundValidProtocol = $true  # Set the flag to true if a valid protocol is found
                }
                else {
                    Write-Output "InValid protocol found for $RuleType : $checkprotocol"
                    $foundValidProtocol = $false  # Set the flag to true if a valid protocol is found
                    $FailedValidations.Add("Failure: Invalid Protocol $checkprotocol for $RuleType, Valid Values are tcp, udp, icmp, any")
                    #break;
                }
            }
        }

        # Check if any invalid protocol was found
        if (-not $foundValidProtocol) {
            Write-Output "Invalid protocols for $RuleType is found in the input $Protocol."
        }

        #Check if we encountered any validation failure, break the script and return error
        If ($FailedValidations.Count -gt 0) {
            Write-Output " failure log: '$FailedValidations'"
            $SuccessfullValidations 
            $SuccessfullValidations1 = $SuccessfullValidations  | ForEach { [PSCustomObject]@{'Logs Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Logs Description' | Out-String
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $SuccessfullValidations2 = $SuccessfullValidations1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $htmlSDescription = $SuccessfullValidations2 -replace '\r*\n', ''
            $htmlSDescription

            $FailedValidations
            $FailedValidations1 = $FailedValidations | ForEach { [PSCustomObject]@{'Error Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Error Description' | Out-String
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $FailedValidations2 = $FailedValidations1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $htmlFDescription = $FailedValidations2 -replace '\r*\n', ''
            $htmlFDescription
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
            Write-Error "Validation failed, please check the below details and resubmit the request: '$FailedValidations'"
        }
    }
    else {
        Write-Output " Validation has been skipped as per the selection" -Verbose
    }
}
catch {
    Write-Output "Executing Catch block" -Verbose
    $Errorlog = $_.Exception 
    $Errorlog
    if ($Errorlog | Select-String "Validation failed, please check the below details and resubmit the request:") {
        Write-Output "Validation Failure"
        throw $_
    }
    else {
        Write-Output "Exception Failure"
        # split the text into an array of lines
        # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
        $Errorlog1 = $Errorlog | Out-String
        $Errorlog2 = $Errorlog1 -split "(\r*\n){2,}"
        # remove linefeeds for each section and output the contents
        $exceptionerror = $Errorlog2 -replace '\r*\n', ''
        Write-Host "##vso[task.setvariable variable=exceptionerror;isoutput=true]$exceptionerror"
        throw $_
    }
    
}