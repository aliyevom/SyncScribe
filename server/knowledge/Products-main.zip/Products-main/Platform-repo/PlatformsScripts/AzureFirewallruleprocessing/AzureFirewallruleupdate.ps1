function CreateOrUpdate-AzureFirewallRuleCollection {

    <#
.SYNOPSIS
    create or update a rule collection & rule in Azure Firewall

.DESCRIPTION
    The PowerShell script create or update a rule collection & rule in Azure Firewall with the Values provided as Paramters

.PARAMETER RITMNumber
    The ServiceNow Request Number for the firewall request

.PARAMETER hubSubscriptionId
    Hub Subscription Id to get Key Vault Secrets 

.PARAMETER subscriptionName
    ADT Subscription Name

.PARAMETER sourceIpAddresses
    Internal comma separated Source IP/CIDR addresses of the VNET/Subnet

.PARAMETER destinationAddresses
    Destination list of FQDNs or Network IPs/CIDR (Comma separated)

.PARAMETER protocol
    Protocol a requirement for outbound Access TCP/UDP/ICMP/HTTPS

.PARAMETER outboundPorts
   Comma Separated Destination Ports required by Application.

.PARAMETER VirtualNetworkName
   Virtual Network Name

   .PARAMETER Region
   Resource Region Name

 #Additional Params has comments inline

.EXAMPLE
CreateOrUpdate-AzureFirewallRuleCollection -RITMNumber "RITM1234" -hubSubscriptionId "74d15849-ba7b-4be6-8ba1-330a178ba88d" -location "eastus2" -region "eus2" -SubscriptionName "US-5874-DEV-01" -defaultBasePriority "100" -defaultPriorityIncrement "10" -VirtualNetworkName "5874-dev-eus2-vnet-01" -RuleType "networkrule" -Action "allow" -Protocol "TCP" -sourceIpAddresses "10.15.32.0/24" -destinationAddresses "100.56.34.56" -outboundPorts "22"

.NOTES
	Version      : 1.1.0
    Author: CPET Team
#>

    param (
        [Parameter(Mandatory = $true)]
        [string]$RITMNumber,
        
        [Parameter(Mandatory = $true)]
        [string]$hubSubscriptionId,

        [Parameter(Mandatory = $true)]
        [string]$location,

        [Parameter(Mandatory = $true)]
        [string]$region,
        
        [Parameter(Mandatory = $true)]
        [string]$SubscriptionName,
        
        [Parameter(Mandatory = $true)]
        [string]$defaultBasePriority,

        [Parameter(Mandatory = $true)]
        [string]$defaultPriorityIncrement,
        
        [Parameter(Mandatory = $true)]
        [string]$VirtualNetworkName,
        
        [Parameter(Mandatory = $true)]
        [string]$RuleType, #e.g., "networkrule", "applicationrule"

        [Parameter(Mandatory = $true)]
        [string]$Action, # e.g. , "allow", "deny"

        [Parameter(Mandatory = $true)]
        [string]$Protocol, # e.g., "Https", "tcp","udp","icmp","any"
        
        [Parameter(Mandatory = $true)]
        [string]$sourceIpAddresses, # e.g., "10.82.5.0/24"
        
        [Parameter(Mandatory = $true)]
        [string]$destinationAddresses, # e.g., "100.82.1.0/24","8.8.8.8" , "microsoft.com" ,"AzureBackup"

        [Parameter(Mandatory = $true)]
        [string]$outboundPorts  # e.g., "80", "443"
    )
    # Get the existing firewall details
    try {
    
        $SuccessLogs = New-Object System.Collections.Generic.List[System.Object]
        $FailureLogs = New-Object System.Collections.Generic.List[System.Object]
        $exceptionerror = New-Object System.Collections.Generic.List[System.Object]
        $sourceIpAddresses1 = $sourceIpAddresses -split ','
        $destinationAddresses1 = $destinationAddresses -split ','
        $destinationPorts = $outboundPorts -split ','
        $destinationPorts = $destinationPorts.Trim()
        #Verify and handle Protocol case Sesitivity
        $Protocol11 = $Protocol -split ","

        # Create a mapping for the correct case formats, Intentionally kept http in case we need it exceptionally, Validation will not allow http by default
        $protocolMapping = @{
            "tcp"   = "TCP"
            "udp"   = "UDP"
            "https" = "HTTPS"
            "http" = "HTTP"
            "mssql" = "Mssql"
            "any"   = "Any"
            "icmp"  = "ICMP"
        }

        # Convert protocols to their correct case using the mapping
        $Protocol1 = $Protocol11 | ForEach-Object { 
            if ($protocolMapping.ContainsKey($_)) {
                $protocolMapping[$_]  # Get the correct case from the mapping
            }
            else {
                $_  # If not found in the mapping, keep the original value
            }
        }

        # Output the corrected protocols
        $Protocol1

        $subMetaData = $SubscriptionName -split ('-')
        if (($RuleType -ieq "servicetags") ) {
            $RuleType1 = "NetworkRule"
        }
        elseif ($RuleType -ieq "fqdntags") {
            $RuleType1 = "ApplicationRule"
        }
        else {
            $RuleType1 = $RuleType
        }
        #Spliting destination addresses into IPs and URLs for Network Rule - Network rule does not support mixed destination
        #$URLPattern - This Regex define pattern for a valid URL without https://
        $URLPattern = "((^(http[s]?:\/\/)?([w]{3}[.])?(([a-z0-9-\.]+)+(com|net|cloud|org|ms|ai|edu|gov|io|uk|eu)))$)"
        $DestinationIPs = @()
        $DestinationURLs = @()

        if ($RuleType -ieq "NetworkRule") {
            foreach ($destinationAddress in $destinationAddresses1) {
                $destinationAddress1 = $destinationAddress.Trim()
                #check if Destination address matches the required Pattern & store it into respective category variable
                if ($destinationAddress1 -imatch $URLPattern) {
                    write-output "The destination Address: $destinationAddress1 is an URL" -Verbose
                    $DestinationURLs += $destinationAddress1
                    
                }
                else {
                    $DestinationIPs += $destinationAddress1
                }
            }
            $DestinationIPs
            $DestinationURLs
        }

        #Correcting protocol for fqdn tags if it is not https
        if ($RuleType -ieq "FQDNTags") {
            $Protocol1 = "HTTPS"
            write-output "The FQDN Tags request had the incorrect Protocol, corrected to https"  -Verbose
        }
        #formatting the rulecollectionName from the provided Input
        $ruleCollectionName = [string]::Concat($subMetaData[1], '-', $subMetaData[2], '-collection-', $RuleType1, '-', $Action , '-', $subMetaData[-1]).ToLower()
        $ruleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-rule-', '01').ToLower() 
        $ruleName
        #formatting the Firewall resourceGroup Name from the provided Input
        $ResourceGroupName = "ng-pd-" + $region + "-hubnetwork-rg"
        $ResourceGroupName
        if ($region -eq "eus2") {
            $FirewallName = "azfw-eus2-01"
        }
        else {
            $FirewallName = "azfw-" + $region + "-pd-01"
        }
        $FirewallName
        # Get the existing firewall
        if (($RuleType -ieq "NetworkRule") -or ($RuleType -ieq "servicetags")) {
            $ruleCollectionType = "NetworkRuleCollections"
        }

        if (($RuleType -ieq "ApplicationRule") -or ($RuleType -ieq "fqdntags")) {
            $ruleCollectionType = "ApplicationRuleCollections"
        } 

        $hubSubscriptionId
        Set-AzContext -Subscription $hubSubscriptionId
        $updaterule = $false
        $firewall = Get-AzFirewall -ResourceGroupName $ResourceGroupName -Name $FirewallName
    
        # Check if the rule collection already exists
    
        $existingCollectionCheck = $firewall.$ruleCollectionType | Where-Object { $_.Name -eq $RuleCollectionName -and ($_.Action).Type -eq $Action }
        $existingCollectionName = $firewall.$ruleCollectionType | Where-Object { $_.Name -eq $RuleCollectionName }
    
        if ($existingCollectionCheck) {
            Write-Host "Rule collection '$RuleCollectionName' already exists in '$ruleCollectionType'. Adding a new rule..."

            #check if the rule Name already exists, Define a new name
        
            $Existingrule = $existingCollectionCheck.Rules | Where-Object { $_.Name -eq $ruleName }
        
            if ($Existingrule) {
                # Getting the existing rule Names in the rule collection
                $Existingrulelist = ($existingCollectionCheck.Rules).Name
        
                # Initialize the base rule name
                $baseRuleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-rule-').ToLower() 
        
                # Initialize the numeric part
                $numericPart = 1
        
                # Loop to find the next available unique Name
                while ($true) {
                    # Format the new Rule Name
                    $newRulename = "{0}{1:D2}" -f $baseRuleName, $numericPart
                    # Check if the new rule name is already in the existing rules
                    if (-not ($Existingrulelist -contains $newRulename)) {
                        # If not present, output the unique name and break the loop
                        Write-Output "Rule Name is $newRulename"
                        break
                    }
        
                    # Increment the numeric part
                    $numericPart++
                }
                $ruleName = $newRulename
        
            }

            # ----------- Check Existence of matchig rules in Network Rule Collection -----------
            if ($ruleCollectionType -eq "NetworkRuleCollections") {
           
                $networkIPRuleMatched = $false
                $networkURLRuleMatched = $false
                foreach ($Netrule in $existingCollectionCheck.Rules) {
                    $srcMatch = $sourceIpAddresses1 | ForEach-Object { $_ -in $Netrule.SourceAddresses }
                    $destIPMatch = $DestinationIPs | ForEach-Object { $_ -in $Netrule.DestinationAddresses }
                    $destURLMatch = $DestinationURLs | ForEach-Object { $_ -in $Netrule.DestinationFqdns }
                    $portMatch = $destinationPorts | ForEach-Object { $_ -in $Netrule.DestinationPorts }
                    if (($srcMatch -notcontains $false) -and ($destIPMatch -notcontains $false) -and ($portMatch -notcontains $false)) {
                        Write-Host "Matching **Network IP Rule** found in collection: $($existingCollectionCheck.Name), rule: $($Netrule.Name)"
                        $networkIPRuleMatched = $true
                        $SuccessLogs.Add("Success: Requested Network IP Rule already exists in $($Netrule.Name) - Duplicate rule ")
                        #break
                    }
                    if (($srcMatch -notcontains $false) -and ($destURLMatch -notcontains $false) -and ($portMatch -notcontains $false)) {
                        Write-Host "Matching **Network URL Rule** found in collection: $($existingCollectionCheck.Name), rule: $($Netrule.Name)"
                        $networkURLRuleMatched = $true
                        $SuccessLogs.Add("Success: Requested Network URL Rule already exists in $($Netrule.Name) - Duplicate rule ")
                        #break
                    }
                }
                if (-not $networkIPRuleMatched) {
                    Write-Host "No matching **Network IP Rule** found in collection: $ruleCollectionName"
                }
                if (-not $networkURLRuleMatched) {
                    Write-Host "No matching **Network URL Rule** found in collection: $ruleCollectionName"
                }
            }
            # ----------- Check Existence of matchig rules in Application Rule Collection -----------
            if ($ruleCollectionType -eq "ApplicationRuleCollections") {
                $appRuleMatched = $false
                foreach ($apprule in $existingCollectionCheck.Rules) {
                    $srcMatch = $sourceIpAddresses1 | ForEach-Object { $_ -in $apprule.SourceAddresses }
                    $fqdnMatch = $destinationAddresses1 | ForEach-Object { $_ -in $apprule.TargetFqdns }
                    $protoMatch = $Protocol1 | ForEach-Object { $apprule.Protocols.ProtocolType -contains $_ }
                    if (($srcMatch -notcontains $false) -and ($fqdnMatch -notcontains $false) -and ($protoMatch -notcontains $false)) {
                        Write-Host "Matching **Application Rule** found in collection: $($existingCollectionCheck.Name), rule: $($apprule.Name)"
                        $appRuleMatched = $true
                        $appRuleMatched
                        $SuccessLogs.Add("Success: Requested Application Rule already exists in $($apprule.Name) - Duplicate rule ")
                        break
                    }
                }
                if (-not $appRuleMatched) {
                    Write-Host "No matching **Application Rule** found in collection: $ruleCollectionName"
                }
            } 

            # Create a new rule
            if ($ruleCollectionType -eq "ApplicationRuleCollections" -and $appRuleMatched -eq $false) {
                Write-Host "Initiating Application Rule Creation....." -Verbose
                $newRule = New-AzFirewallApplicationRule -Name $ruleName -Protocol $Protocol1 -SourceAddress $sourceIpAddresses1 -TargetFqdn $destinationAddresses1
                # Add the new rule to the existing collection
                $existingCollectionCheck.Rules.Add($newRule)
                $updaterule = $true
                $SuccessLogs.Add("Success: Requested Application Rule $($ruleName) ")
            }

            #add logic for Network IP rule and Network URL Rule

            if ($ruleCollectionType -eq "NetworkRuleCollections" -and $networkIPRuleMatched -eq $false) {
                Write-Host "Initiating Network IP Rule Creation....." -Verbose
                if ($DestinationIPs.count -gt 0) {
                    #formatting the ruleName from the provided Input
                    $IPruleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-iprule-', '01').ToLower() 
                    $IPruleName
                    $newIPRule = New-AzFirewallNetworkRule -Name $ipruleName -SourceAddress $sourceIpAddresses1 -DestinationAddress $DestinationIPs -DestinationPort $destinationPorts -Protocol $Protocol1
                    # Add the new rule to the existing collection
                    $existingCollectionCheck.Rules.Add($newIPRule)
                    $updaterule = $true
                    $SuccessLogs.Add("Success: Requested Network IP Rule $($ruleName) - New rule ")
                }
            }
            if ($ruleCollectionType -eq "NetworkRuleCollections" -and $networkURLRuleMatched -eq $false) {
                if ($DestinationURLs.count -gt 0) {
                    #formatting the ruleName from the provided Input
                    $URLruleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-urlrule-', '01').ToLower() 
                    $URLruleName
                    Write-Host "Initiating Network FQDN Rule Creation....." -Verbose
                    $newURLRule = New-AzFirewallNetworkRule -Name $URLruleName -SourceAddress $sourceIpAddresses1 -DestinationFqdn $DestinationURLs -DestinationPort $destinationPorts -Protocol $Protocol1
                    # Add the new rule to the existing collection
                    $existingCollectionCheck.Rules.Add($newURLRule)
                    $updaterule = $true
                    $SuccessLogs.Add("Success: Requested Network FQDN Rule $($ruleName) - New rule ")
                }
            }
        
        } 
    
        else {
            Write-Host "Creating new rule collection  '$RuleCollectionName' under $ruleCollectionType ..."

            # Get existing rule collections and their priorities
            $existingPriorities = @()
            foreach ($ruleCollection in $firewall.$ruleCollectionType) {
                $existingPriorities += $ruleCollection.Priority
            }
            
            $nextpriority = 100
        
            while ($existingPriorities -contains $nextpriority) {
                $nextpriority += 10
            }
        
            Write-Output "The first available priority after 100 is: $nextpriority"

            #Creating New Name if the Name already exists
            if ($existingCollectionName) {
                # Getting the existing rulecollection Names from the rule collections
                $Existingrulecollectionlist = ($firewall.$ruleCollectionType).Name
        
                # Initialize the base rule collection name
                $baseRuleCollectionName = [string]::Concat($subMetaData[1], '-', $subMetaData[2], '-collection-', $RuleType1, '-', $Action , '-').ToLower()
   
                # Initialize the numeric part
                $numericPart = 1
        
                # Loop to find the next available unique Name
                while ($true) {
                    # Format the new Rule collection Name
                    $newRulecollectionname = "{0}{1:D2}" -f $baseRuleCollectionName, $numericPart
                    # Check if the new rule name is already in the existing rules
                    if (-not ($Existingrulecollectionlist -contains $newRulecollectionname)) {
                        # If not present, output the unique name and break the loop
                        Write-Output "New Rule Collection Name is $newRulecollectionname"
                        break
                    }
        
                    # Increment the numeric part
                    $numericPart++
                }
                $RuleCollectionName = $newRulecollectionname
        
            }


            # Create a new rule
            If ($ruleCollectionType -eq "ApplicationRuleCollections") {

                Write-Host "Initiating Application Rule Creation....." -Verbose
                $newRule = New-AzFirewallApplicationRule -Name $ruleName -Protocol $Protocol1 -SourceAddress $sourceIpAddresses1 -TargetFqdn $destinationAddresses1

                # Create a new rule collection
                $ruleCollection = New-AzFirewallApplicationRuleCollection -Name $RuleCollectionName -Priority $nextpriority -ActionType $Action -Rule $newRule
            
                # Add the new rule collection to the firewall
                $firewall.ApplicationRuleCollections.Add($ruleCollection)
                $updaterule = $true
                $SuccessLogs.Add("Success: Requested Application Rule $($ruleName) - New rule ")

            }
            If ($ruleCollectionType -eq "NetworkRuleCollections") {
                Write-Host "Initiating Network Rule Creation....." -Verbose
                if ($DestinationIPs.count -gt 0) {
                    $DestinationIPs.count
                    #formatting the ruleName from the provided Input
                    $IPruleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-iprule-', '01').ToLower() 
                    $IPruleName
                    $newIPRule = New-AzFirewallNetworkRule -Name $IPruleName -SourceAddress $sourceIpAddresses1 -DestinationAddress $DestinationIPs -DestinationPort $destinationPorts -Protocol $Protocol1
                    # Create a new rule collection
                    $ruleCollection = New-AzFirewallNetworkRuleCollection -Name $RuleCollectionName -Priority $nextpriority -ActionType $Action -Rule $newIPRule
    
                }
                if ($DestinationURLs.count -gt 0) {
                    $DestinationURLs.count
                    #formatting the ruleName from the provided Input
                    $URLruleName = [string]::Concat($RITMNumber, '-', $subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddresses1[0], '-', $protocol, '-', ($destinationPorts -join ('-')), '-urlrule-', '01').ToLower() 
                    $URLruleName
                    $newURLRule = New-AzFirewallNetworkRule -Name $URLruleName -SourceAddress $sourceIpAddresses1 -DestinationFqdn $DestinationURLs -DestinationPort $destinationPorts -Protocol $Protocol1

                    If ($DestinationIPs.count -gt 0) {
                        #Create a new rule collection with URL Rule & IP Rule
                        $ruleCollection.AddRule($newURLRule)
                    }
                    else {
                        # Create a new rule collection only with URL Rule
                        $ruleCollection = New-AzFirewallNetworkRuleCollection -Name $RuleCollectionName -Priority $nextpriority -ActionType $Action -Rule $newURLRule
    
                    }
                }
            
                # Add the new rule collection to the firewall
                $firewall.NetworkRuleCollections.Add($ruleCollection)
                $updaterule = $true
                $SuccessLogs.Add("Success: Requested Network Rule $($ruleName) ")

            }

        }

        # Update the firewall with the new or modified rule collection
        if ($updaterule -eq $true) {
            $updaterule
            Write-Host "Commiting Firewall Rule update...."
            $firewall | Set-AzFirewall
            Write-Host "Firewall Rule updated successfully."
            $SuccessLogs.Add("Success: Requested Rule has been added")
            $SuccessLogs
            $SuccessLogs1 = $SuccessLogs  | ForEach { [PSCustomObject]@{'Logs Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Logs Description' | Out-String
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $SuccessLogs2 = $SuccessLogs1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $htmlSDescription = $SuccessLogs2 -replace '\r*\n', ''
            $htmlSDescription
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"

        }
        else {
            Write-Host "No Firewall Rule Update needed"
            $SuccessLogs1 = $SuccessLogs  | ForEach { [PSCustomObject]@{'Logs Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Logs Description' | Out-String
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $SuccessLogs2 = $SuccessLogs1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $htmlSDescription = $SuccessLogs2 -replace '\r*\n', ''
            $htmlSDescription
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
        }
    }
    catch {
        Write-Output "Executing Catch block" -Verbose
        $Errorlog = $_.Exception 
        $Errorlog
        if ($Errorlog | Select-String "placeholder") {
            Write-Output "Exception Failure"
            Write-Host "##vso[task.setvariable variable=exceptionerror;isoutput=true]$exceptionerror"
            throw $_
        }
        else {
            Write-Output "Exception Failure"
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $Errorlog1 = $Errorlog.Message | Out-String
            $Errorlog2 = $Errorlog1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $exceptionerror = $Errorlog2 -replace '\r*\n', ''

            $FailureLogs1 = $FailureLogs  | ForEach { [PSCustomObject]@{'Error Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Error Description' | Out-String
            # split the text into an array of lines
            # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
            $FailureLogs2 = $FailureLogs1 -split "(\r*\n){2,}"
            # remove linefeeds for each section and output the contents
            $htmlFDescription = $FailureLogs2 -replace '\r*\n', ''
            $htmlFDescription
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=exceptionerror;isoutput=true]$exceptionerror"
            throw $_
        }
    
    }
}

