param
(
    [parameter(Mandatory = $true)]
    [String] $environment,

    [parameter(Mandatory = $true)]
    [String] $SubscriptionName,

    [Parameter(Mandatory = $true)]
    [string] $storageAccountName,

    [Parameter(Mandatory = $true)]
    [string] $tableName,

    [Parameter(Mandatory = $true)]
    [string] $storageAccountNameResourceGroup,
            
    [Parameter(Mandatory = $true)]
    [string] $storageAccountSubscriptionId,

    [switch] $remove
)

try {
    Install-Module AzTable -Force -Scope CurrentUser

    $subscriptionId = (Get-AzSubscription -SubscriptionName $SubscriptionName).Id
    Set-AzContext -SubscriptionId  $storageAccountSubscriptionId 
    $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountNameResourceGroup
    $ctx = $sta.Context
    $cloudTable = (Get-AzStorageTable -Name $tableName -Context $ctx).CloudTable


    [string]$subscription = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("SubscriptionId", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, $subscriptionId)
    [string]$status = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("OptimizationStatus", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, "Add")
    [string]$update = [Microsoft.Azure.Cosmos.Table.TableQuery]::CombineFilters($subscription, "and", $status)

    if ($remove) {

        $deRegisterSubscription = Get-AzTableRow -table $cloudTable -CustomFilter $update 
        if ( $deRegisterSubscription) {
            
            $deRegisterSubscription.OptimizationStatus = "Remove" 
            $deRegisterSubscription.Status = "Cancelled" 
            $deRegisterSubscription | Update-AzTableRow -table $cloudTable
            Write-Verbose "Subscription '$($subscriptionName)' successfully added to un-register from Turbonomics." -Verbose
        }
        else {
            Write-Verbose "Subscription '$($subscriptionName)' already been added to unregister from Turbonomics." -Verbose
        }
    }
    else {


        $subscriptionRegistration = Get-AzTableRow -table $cloudTable -CustomFilter $subscription 
        if (-not $subscriptionRegistration) {
            Add-AzTableRow `
                -table $cloudTable `
                -partitionKey $environment `
                -rowKey  (Get-date -f MM-dd-yyyy_HH-mm-ss) `
                -property @{
                SubscriptionName   = $SubscriptionName
                SubscriptionId     = $subscriptionId
                OptimizationStatus = "Add"
                Status             = "Enabled"
            }
            Write-Verbose "Subscription '$($subscriptionName)' successfully added to be registered with Turbonomics." -Verbose
        }
        else {
            Write-Verbose "Subscription '$($subscriptionName)' already added to be registered with Turbonomics." -Verbose
        }
    }
}
catch {
    Write-Warning  "Failed to Un/register -> '$($subscriptionName)' `n$_" -Verbose
}