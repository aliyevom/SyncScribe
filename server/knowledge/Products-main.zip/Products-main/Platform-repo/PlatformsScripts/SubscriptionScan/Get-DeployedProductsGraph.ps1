<#
.SYNOPSIS
    Get Deployment Count of Products from Azure and update it in Product Work Item

.DESCRIPTION
    Get Deployment Count of Products from Azure and update it in Product Work Item.
    The Resource Graph Query lists tags on management groups, subscriptions, and resources along with their values. 
    The query first limits to resources where tags isnotempty(), limits the included fields by only including tags in the project, 
    and mvexpand and extend to get the paired data from the property bag. 
    It then uses union to combine the results from ResourceContainers to the same results from Resources, 
    giving broad coverage to which tags are fetched. Finally it checks for ccoe-lineage tag and does a regex to match with tagValue

.PARAMETER OrganizationName
    Specifies the name of the Azure DevOps organization where the project has to be created
    https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/organization-management?view=azure-devops

.PARAMETER ProjectName
    Specifies the name of the Azure DevOps project to create
          
.PARAMETER PATSecret
    PAT Token Secret Name in keyvault

.PARAMETER KeyVaultName
   Key Vault Name to get PAT secrets

.PARAMETER SubscriptionId
   Subscription ID where keyvault exists

.EXAMPLE

.NOTES
	Version      : 1.0.0
	Last Updated : 4/15/2021
#>


[CmdletBinding(SupportsShouldProcess = $false)]
PARAM(
    [Parameter(Mandatory = $true, Position = 0,
        HelpMessage = 'The name of the Azure DevOps organization')]
    [ValidateNotNullOrEmpty()]
    [Alias('Company')]
    [string] $OrganizationName = "NGRID",

    [Parameter(Mandatory = $true, Position = 1,
        HelpMessage = 'The name of the project')]
    [string] $ProjectName = "CCOE",

    [Parameter(Mandatory = $true, Position = 2,
        HelpMessage = 'PAT Token Secret Name in keyvault')]
    [string] $PATSecret,

    [Parameter(Mandatory = $true, Position = 3,
        HelpMessage = 'Key Vault Name to get PAT secrets')]
    [string] $KeyVaultName,
    
    [Parameter(Mandatory = $true, Position = 4,
        HelpMessage = 'Sub ID')]
    [string] $SubscriptionId,

    [Parameter(Mandatory = $true, Position = 5,
        HelpMessage = 'Storage Account where Product Metrics are updated')]
    [string] $StorageAccountName,

    [Parameter(Mandatory = $true, Position = 6,
        HelpMessage = 'Resource Group where Storage Account where Product Metrics exists')]
    [string] $StorageAccountResourceGroup,

    [Parameter(Mandatory = $true, Position = 7,
        HelpMessage = 'Storage Account Table Name for Product Metrics')]
    [string] $TableName

)
# Function to get Work item ID for each Product ($output.workItems.id)
function Get-ProductsWorkItemId {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $TeamName
    )
    try {
        Write-Verbose "Querying to get Product List with WIQL Query" -Verbose
        $body = @"
        {
            "query": "Select [System.Id], [System.Title], [System.State] From WorkItems Where [System.WorkItemType] = 'Product'"
          }          
"@

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/$TeamName/_apis/wit/wiql?api-version=6.0"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params

        $output.workItems.id
    }
    catch {
        throw $_
    }
    
    return $output
}
# Function Prints Work Item details
function Get-WorkItemDetails {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $ProductWorkItemId
    )

    try {
        Write-Verbose "Querying to fetch Work Item details for Work Item number: $ProductWorkItemId" -Verbose
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/wit/workitems/$ProductWorkItemId ?expand=fields&api-version=6.0"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params

        Write-Verbose "$output" -Verbose
        
    }
    catch {
        throw $_
    }
    
    return $output
}

# Function to set Deployment Count in Product Epic
function Set-DeploymentCountMetrics {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $ProductWorkItemId,
        [Parameter(Mandatory = $true)] [string] $DeploymentCount,
        [Parameter(Mandatory = $true)] [string] $PackageName
    )

    try {
      
        $body = @"
        [
            {
                "op": "add",
                "path": "/fields/Custom.DeploymentCount",
                "value": "$DeploymentCount"
            }
            ]
"@
        Write-Verbose "Updating Deployment Count for $PackageName in Product Epic" -Verbose

        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/wit/workitems/$ProductWorkItemId ?api-version=6.0" -ContentType "application/json-patch+json" -Body $body 

        Write-Verbose "Updated Deployment Count for $PackageName in Product Epic" -Verbose

    }
    catch {
        throw $_
    }

}

function Update-StorageTable {
    param (
        [Parameter(Mandatory = $true)] [string] $storageAccountSubscriptionId,
        [Parameter(Mandatory = $true)] [string] $storageAccountName,
        [Parameter(Mandatory = $true)] [string] $storageAccountResourceGroup,
        [Parameter(Mandatory = $true)] [string] $tableName,
        [Parameter(Mandatory = $true)] [string] $productMoniker,
        [Parameter(Mandatory = $true)] [string] $deploymentCount
    )

    # Write to Azure Storage Table

    Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
    $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
    $ctx = $sta.Context
    $cloudTable = (Get-AzStorageTable –Name $tableName –Context $ctx).CloudTable

    $rowExists = Get-AzTableRow -table $cloudTable `
        -columnName "ProductName" `
        -value "$productMoniker" `
        -operator Equal
    
    if ($null -eq $rowExists) {

        Write-Verbose "Adding Product entry for $productMoniker in Storage Account Table and Adding Deployment Count" -Verbose

        Add-AzTableRow `
            -table $cloudTable `
            -partitionKey "$productMoniker" `
            -rowKey ("$productMoniker") -property @{"ProductName" = "$productMoniker"; "DeploymentCount" = $deploymentCount }
            
    }
    else {
        Write-Verbose "Product entry for $productMoniker already exists in Table.Updating Deployment Count" -Verbose
        # Create a filter and get the entity to be updated.
        [string]$filter = `
            [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("ProductName", `
                [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, "$productMoniker")
        $row = Get-AzTableRow `
            -table $cloudTable `
            -customFilter $filter

        # Update DeploymentCount
        $row.DeploymentCount = "$deploymentCount"

        # To commit the change, pipe the updated record into the update cmdlet.
        $row | Update-AzTableRow -table $cloudTable
    }
       
}

try {

    # Get Keyvault Secrets
    
    Set-AzContext -Subscription $SubscriptionId   

    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecret

    $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
    try {
        $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($PATSecret)
    }

    # Create header with PAT
    $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $header = @{authorization = "Basic $token" }

    # Get Work item ID for each Product

    $productWorkItems = Get-ProductsWorkItemId -OrganizationName $OrganizationName -ProjectName $ProjectName -TeamName "Product Team"

    $workItemsIds = $productWorkItems.workItems.id

    Write-Verbose "List of Product Epic WorkItem Ids: $workItemsIds" -Verbose

    foreach ($id in $workItemsIds) {

        # Get Product Epic WI details

        $workItem = Get-WorkItemDetails -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id
        $artifactMoniker = $workItem.fields.PSObject.Properties["Custom.ArtifactMoniker"].value
        $resourceIdentifier = $workItem.fields.PSObject.Properties["Custom.ResourceIdentifier"].value

        if ($artifactMoniker) {

            Write-Verbose "The Product Moniker fetched is:$artifactMoniker" -Verbose
            Write-Verbose "Getting Deployment Count via Resource Graph Query by counting ccoe-lineage tag for $artifactMoniker" -Verbose
            if ($resourceIdentifier -notlike "Microsoft.Resources/resourceGroups" -and $null -ne $resourceIdentifier -and $null -ne $artifactMoniker) {
                Write-Verbose "Getting deployment Count for $artifactMoniker and resource type $resourceIdentifier" -Verbose
                $Query = "Resources | where type =~ '$resourceIdentifier' | project tags | mvexpand tags | extend tagKey = tostring(bag_keys(tags)[0]) | extend tagValue = tostring(tags[tagKey]) | where tagKey == ""ccoe-lineage"" and tagValue matches regex @'^$artifactMoniker' | count"
                $GraphQueryResult = Search-AzGraph -Query $Query
                # Use below statement if API Changes
                $ProductCount = $GraphQueryResult.Data[0].Count
                

            }
            elseif ($resourceIdentifier -like "Microsoft.Resources/resourceGroups" -and $artifactMoniker -like "resource-group") {
                Write-Verbose "Getting deployment Count for $artifactMoniker and resource type $resourceIdentifier" -Verbose
                $Query = "ResourceContainers | where isnotempty(tags) | project tags | mvexpand tags | extend tagKey = tostring(bag_keys(tags)[0]) | extend tagValue = tostring(tags[tagKey]) | where tagKey == ""ccoe-lineage"" and tagValue matches regex @'^resource-group' | count"
                $GraphQueryResult = Search-AzGraph -Query $Query
                # Use below statement if API Changes
                $ProductCount = $GraphQueryResult.Data[0].Count
            }
            else {
                $Query = "Resources | where isnotempty(tags) | project tags | mvexpand tags | extend tagKey = tostring(bag_keys(tags)[0]) | extend tagValue = tostring(tags[tagKey]) |  where tagKey == ""ccoe-lineage"" and tagValue matches regex @'^$artifactMoniker' | count"
                $GraphQueryResult = Search-AzGraph -Query $Query
                # Use below statement if API Changes
                $ProductCount = $GraphQueryResult.Data[0].Count                
            }
            Write-Verbose "Deployment Count for $artifactMoniker Product is $ProductCount" -Verbose
            # Update Storage Account Table
            Write-Verbose "Update Azure Storage Account Table for $artifactMoniker whose Deployment Count is $ProductCount" -Verbose
            Update-StorageTable -storageAccountSubscriptionId $SubscriptionId -storageAccountName $StorageAccountName -storageAccountResourceGroup $StorageAccountResourceGroup -tableName $TableName -productMoniker $artifactMoniker -deploymentCount $ProductCount         
            # Set Deployment Count in Product Epic
            if ($ProductCount -eq 0 -or $null -eq $ProductCount) {

                Write-Warning "There has been no deployment for $artifactMoniker" -Verbose 
                Set-DeploymentCountMetrics -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id -PackageName $artifactMoniker -DeploymentCount $ProductCount
            }
            else {

                Set-DeploymentCountMetrics -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id -PackageName $artifactMoniker -DeploymentCount $ProductCount
            } 

        }
        else {
            
            Write-Warning "Artifact Moniker for Work Item ID $id does not exist" -Verbose
        }
        
    }

}
catch {
    throw $_
}








