



function Add-CELocationType {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $LocationGuid,
        [Parameter(Mandatory = $true)] [string] $LocationName
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    `"id`": `"$LocationGuid`",
    `"name`":  `"$LocationName`",
    "object_type": "dcim.locationtype",
    "content_types": [
        "ipam.prefix"
    ],
    "nestable": true,
    "parent": null
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}



function Add-RegionLocationType {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $LocationGuid,
        [Parameter(Mandatory = $true)] [string] $LocationName
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
        {
            `"id`": `"$LocationGuid`",
            `"name`":  `"$LocationName`",
            "object_type": "dcim.locationtype",
            "content_types": [],
            "nestable": true,
            "parent": null
        }
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}

function Add-SitesLocationType {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $LocationTypeGuid,
        [Parameter(Mandatory = $true)] [string] $LocationName,
        [Parameter(Mandatory = $true)] [string] $ParentLocationTypeGuid,
        [Parameter(Mandatory = $true)] [string] $ParentLocationTypeURL
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
        {
            `"id`": `"$LocationTypeGuid`",
            `"name`":  `"$LocationName`",
            "object_type": "dcim.locationtype",
            "content_types": [
                "dcim.device",
                "dcim.rack",
                "ipam.prefix",
                "ipam.vlan",
                "circuits.circuittermination",
                "dcim.powerpanel",
                "dcim.rackgroup",
                "ipam.vlangroup",
                "virtualization.cluster"
            ],
            "parent": {
                "id": `"$ParentLocationTypeGuid`",
                "object_type": "dcim.locationtype",
                "url": `"$ParentLocationTypeURL`"
            }
        }
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
#Azure & Global
function Add-AzureLocation {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $LocationGuid,
        [Parameter(Mandatory = $true)] [string] $LocationName,
        [Parameter(Mandatory = $true)] [string] $LocationTypeGuid,
        [Parameter(Mandatory = $true)] [string] $LocationTypeURL
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    "id": `"$LocationGuid`",
    "object_type": "dcim.location",
    "name": `"$LocationName`",
    "facility": "Azure",
    "parent": null,
    "location_type": {
        "id": `"$LocationTypeGuid`",
        "object_type": "dcim.locationtype",
        "url": `"$LocationTypeURL`"
    },
    "status": {
        "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
        "object_type": "extras.status",
        "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
    }
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
#1.0 ,2.0, eastus2, centralus, uksouth, ukwest
function Add-RegionLocation {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $LocationGuid,
        [Parameter(Mandatory = $true)] [string] $LocationName,
        [Parameter(Mandatory = $true)] [string] $LocationTypeGuid,
        [Parameter(Mandatory = $true)] [string] $LocationTypeURL,
        [Parameter(Mandatory = $true)] [string] $ParentLocationGuid,
        [Parameter(Mandatory = $true)] [string] $ParentLocationeURL
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    "id": `"$LocationGuid`",
    "object_type": "dcim.location",
    "name": `"$LocationName`",
    "facility": "Azure",
    "parent": {
        "id": `"$ParentLocationGuid`",
        "object_type": "dcim.location",
        "url": `"$ParentLocationeURL`"
    },
    "location_type": {
        "id": `"$LocationTypeGuid`",
        "object_type": "dcim.locationtype",
        "url": `"$LocationTypeURL`"
    },
    "status": {
        "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
        "object_type": "extras.status",
        "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
    }
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}

function Add-RootPrefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $PrefixGUID,    
        [Parameter(Mandatory = $true)] [string] $Prefix
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
    {
        "id": `"$PrefixGUID`",
        "prefix": `"$Prefix`",
        "type": {
            "value": "container",
            "label": "Container"
        },
            "status": {
        "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
        "object_type": "extras.status",
        "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
    },
        "parent": null
      }
"@

        Write-Debug $body
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response | ConvertTo-Json
    }
    catch {
        #throw $_
    }
    return $response.value
}

function Get-Prefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $Prefix,
        [Parameter(Mandatory = $true)] [string] $Type
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=" + "$Prefix" + "&type=" + $Type

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
function Add-ParentPrefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $PrefixGUID,    
        [Parameter(Mandatory = $true)] [string] $Prefix,
        [Parameter(Mandatory = $true)] [string] $ParentGuid,    
        [Parameter(Mandatory = $true)] [string] $ParentURL
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
    {
        "id": `"$PrefixGUID`",
        "prefix": `"$Prefix`",
        "type": {
            "value": "container",
            "label": "Container"
        },
            "status": {
        "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
        "object_type": "extras.status",
        "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
    },
        "parent": {
            "id": `"$ParentGuid`",
            "object_type": "dcim.locationtype",
            "url": `"$ParentURL`"
        }
      }
"@

        Write-Debug $body
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response | ConvertTo-Json
    }
    catch {
        #throw $_
    }
    return $response.value
}



try {
    Write-Output "Initiating Nuatobot Prepare Database Script " -Verbose

    $KeyVaultName = 'ng-prd-eus2-kv-01'
    $PATSecretName = 'GBL-SVC-NAUTOBOT-PAT'

    Set-AzContext -Subscription "US-HUB-Prod-01"
    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecretName `
        -ErrorAction Stop;
    Write-Output "getting PAT  from KV " -Verbose
    $PATValue = $PAT.SecretValue
    Write-Output "$PATValue " -Verbose
    if ($PATValue) {
        $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
        $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
        #$PATSecretText
    }
    else {
        { Write-Output "PAT is not found. please check the PAT Secret Value" }
    }
#Add Cloud Environment Location Type
    Add-CELocationType -LocationGuid "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationName "Cloud Environment"
#Add Region Location Type
    Add-RegionLocationType -LocationGuid "4660f6d6-148c-4b03-9dbf-53c0452af543" -LocationName "Region"
#Add Site Location Type
    Add-SitesLocationType -LocationTypeGuid "e9b496c4-2a79-4244-83c4-b706aaa9efe2" -LocationName "Site" -ParentLocationTypeGuid "4660f6d6-148c-4b03-9dbf-53c0452af543" -ParentLocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/4660f6d6-148c-4b03-9dbf-53c0452af543/"
#Add Azure & Global Location
    Add-AzureLocation -LocationGuid "c6202501-4c83-4e50-b389-fef65a547a27" -LocationName "Azure" -LocationTypeGuid "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/7a781a13-68c7-400b-8568-330713f3d8a7/"
    Add-AzureLocation -LocationGuid "c617a084-91ba-4744-bb40-e54d67738ea6" -LocationName "Global" -LocationTypeGuid "4660f6d6-148c-4b03-9dbf-53c0452af543" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/4660f6d6-148c-4b03-9dbf-53c0452af543/"
#Add all Regional Locations
    Add-RegionLocation -LocationGuid "3e62fb23-52ff-4106-9124-588a7edc258a" -LocationName "1.0" -LocationTypeGuid "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/7a781a13-68c7-400b-8568-330713f3d8a7/" -ParentLocationGuid "c6202501-4c83-4e50-b389-fef65a547a27" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c6202501-4c83-4e50-b389-fef65a547a27/"
    Add-RegionLocation -LocationGuid "7238da28-d537-4664-9325-c1452e67e0b9" -LocationName "2.0" -LocationTypeGuid "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/7a781a13-68c7-400b-8568-330713f3d8a7/" -ParentLocationGuid "c6202501-4c83-4e50-b389-fef65a547a27" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c6202501-4c83-4e50-b389-fef65a547a27/"
    Add-RegionLocation -LocationGuid "8e8027a0-67a6-4b20-a42d-33fdcd465642" -LocationName "eastus2" -LocationTypeGuid "e9b496c4-2a79-4244-83c4-b706aaa9efe2" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/e9b496c4-2a79-4244-83c4-b706aaa9efe2/" -ParentLocationGuid "c617a084-91ba-4744-bb40-e54d67738ea6" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c617a084-91ba-4744-bb40-e54d67738ea6/"
    Add-RegionLocation -LocationGuid "fb2b7012-d47e-4a60-9ede-dc22cc811751" -LocationName "centralus" -LocationTypeGuid "e9b496c4-2a79-4244-83c4-b706aaa9efe2" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/e9b496c4-2a79-4244-83c4-b706aaa9efe2/" -ParentLocationGuid "c617a084-91ba-4744-bb40-e54d67738ea6" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c617a084-91ba-4744-bb40-e54d67738ea6/"
    Add-RegionLocation -LocationGuid "ede37d0a-bc29-443d-8e30-006174f4449f" -LocationName "uksouth" -LocationTypeGuid "e9b496c4-2a79-4244-83c4-b706aaa9efe2" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/e9b496c4-2a79-4244-83c4-b706aaa9efe2/" -ParentLocationGuid "c617a084-91ba-4744-bb40-e54d67738ea6" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c617a084-91ba-4744-bb40-e54d67738ea6/"
    Add-RegionLocation -LocationGuid "0ce7c5fd-1add-4f36-ac5c-dee47f8a27c7" -LocationName "ukwest" -LocationTypeGuid "e9b496c4-2a79-4244-83c4-b706aaa9efe2" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/e9b496c4-2a79-4244-83c4-b706aaa9efe2/" -ParentLocationGuid "c617a084-91ba-4744-bb40-e54d67738ea6" -ParentLocationeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c617a084-91ba-4744-bb40-e54d67738ea6/"
<#
UK:    
10.114.0.0/16
10.79.0.0/16
10.83.0.0/16
US:
10.15.0.0/16
10.82.0.0/16
10.92.0.0/16
#>
    Add-RootPrefix -PrefixGUID "01e3113f-5a95-46d8-8889-91a5feacbc10" -Prefix "10.114.0.0/16"
    Add-RootPrefix -PrefixGUID "02e3113f-5a95-46d8-8889-91a5feacbc20" -Prefix "10.79.0.0/16"
    Add-RootPrefix -PrefixGUID "03e3113f-5a95-46d8-8889-91a5feacbc30" -Prefix "10.83.0.0/16"
    Add-RootPrefix -PrefixGUID "04e3113f-5a95-46d8-8889-91a5feacbc40" -Prefix "10.15.0.0/16"
    Add-RootPrefix -PrefixGUID "05e3113f-5a95-46d8-8889-91a5feacbc50" -Prefix "10.82.0.0/16"
    Add-RootPrefix -PrefixGUID "06e3113f-5a95-46d8-8889-91a5feacbc60" -Prefix "10.92.0.0/16"

<#
		               uksouth	       ukwest
UK	10.114.0.0/16	10.114.0.0/17	10.114.128.0/17
#>    
$GetPrefix =Get-Prefix -Prefix "10.114.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "01e3113f-5a95-46d8-8889-91a5feacbc11" -Prefix "10.114.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "01e3113f-5a95-46d8-8889-91a5feacbc12" -Prefix "10.114.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl

<#
UK	10.79.0.0/16	10.79.0.0/17	10.79.128.0/17
#>
$GetPrefix =Get-Prefix -Prefix "10.79.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl

Add-ParentPrefix -PrefixGUID "02e3113f-5a95-46d8-8889-91a5feacbc21" -Prefix "10.79.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "02e3113f-5a95-46d8-8889-91a5feacbc22" -Prefix "10.79.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl

<#
UK	10.83.0.0/16	10.83.0.0/17	10.83.128.0/17
#>
$GetPrefix =Get-Prefix -Prefix "10.83.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "03e3113f-5a95-46d8-8889-91a5feacbc31" -Prefix "10.83.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "03e3113f-5a95-46d8-8889-91a5feacbc32" -Prefix "10.83.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl

<#
		                eastus2	       centralus
US	10.15.0.0/16	10.15.0.0/17	10.15.128.0/17
#>
$GetPrefix =Get-Prefix -Prefix "10.15.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "04e3113f-5a95-46d8-8889-91a5feacbc41" -Prefix "10.15.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "04e3113f-5a95-46d8-8889-91a5feacbc42" -Prefix "10.15.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl

<#
US	10.82.0.0/16	10.82.0.0/17	10.82.128.0/17
#>
$GetPrefix =Get-Prefix -Prefix "10.82.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "05e3113f-5a95-46d8-8889-91a5feacbc51" -Prefix "10.82.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "05e3113f-5a95-46d8-8889-91a5feacbc52" -Prefix "10.82.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl

<#
US	10.92.0.0/16	10.92.0.0/17	10.92.128.0/17
#>
$GetPrefix =Get-Prefix -Prefix "10.92.0.0/16" -Type "container"
$Prefixresult =$GetPrefix.results
$ParentPrefixGuid = $Prefixresult.id
$ParentPrefixUrl = $Prefixresult.url
$ParentPrefixGuid
$ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "06e3113f-5a95-46d8-8889-91a5feacbc61" -Prefix "10.92.0.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl
Add-ParentPrefix -PrefixGUID "06e3113f-5a95-46d8-8889-91a5feacbc62" -Prefix "10.92.128.0/17" -ParentGuid $ParentPrefixGuid -ParentURL $ParentPrefixUrl


}

catch {
    throw $_
}