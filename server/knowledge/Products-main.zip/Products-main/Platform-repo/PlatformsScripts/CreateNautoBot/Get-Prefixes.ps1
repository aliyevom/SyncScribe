
[CmdletBinding(SupportsShouldProcess)]
Param(
    [string] $ManagementGroups,
    [string] $AzureGroup
)

$ErrorActionPreference = 'Stop'


<#All Functions definitions #>
#$PATSecretText ="d47b4573cfd1b53f418b81b6a89e62ffa55085d8"
function Get-Prefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETAddressSpace,
        [Parameter(Mandatory = $true)] [string] $Type
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=" + "$VNETAddressSpace" + "&type=" + $Type

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response
    }
    catch {
        #throw $_
    }
    return $response.value
}
#$GetPrefix = Get-Prefix -VNETAddressSpace "10.82.0.0/17" -Type "container"

function Get-Location {
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response
    }
    catch {
        #throw $_
    }
    return $response.value
}
#$GetLocation = Get-Location


function Get-LocationType {
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response
    }
    catch {
        throw $_
    }
    return $response.value
}
#$GetLocationType = Get-LocationType


function Add-GlobalLocation {
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    `"id`": `"c617a084-91ba-4744-bb40-e54d67738ea6`",
    `"object_type`": `"dcim.location`",
    `"name`": `"Global`",
    `"facility`": `"Azure`",
    `"location_type`": {
        `"id`": `"e9b496c4-2a79-4244-83c4-b706aaa9efe2`",
        `"object_type`": `"dcim.locationtype`",
        `"url`": `"https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/e9b496c4-2a79-4244-83c4-b706aaa9efe2/`"
    },
    `"status`": {
        `"id`": `"5612ea68-1c4a-428a-8185-b31afa62869d`",
        `"object_type`": `"extras.status`",
        `"url`": `"https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/`"
    }
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#$AddGlobalLocation = Add-GlobalLocation

function Add-Location {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETLocation,
        [Parameter(Mandatory = $true)] [string] $LocGuid,
        [Parameter(Mandatory = $true)] [string] $ParentLocGUID,
        [Parameter(Mandatory = $true)] [string] $ParentLocURL,
                [Parameter(Mandatory = $true)] [string] $LocationTypeID,
        [Parameter(Mandatory = $true)] [string] $LocationTypeURL
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    `"id`": `"$VNETGUID`",
    `"object_type`": `"dcim.location`",
    `"name`": `"$VNETLocation`",
    `"facility`": `"Azure`",
    `"parent`": {
        `"id`": "$ParentLocGUID`",
        `"object_type`": `"dcim.location`",
        `"url`": "$ParentLocURL`"
    },
    `"location_type`": {
        "id": "$LocationTypeID`",
        "object_type": "dcim.locationtype",
        "url": "$LocationTypeURL`"
    },
    `"status`": {
        `"id`": `"5612ea68-1c4a-428a-8185-b31afa62869d`",
        `"object_type`": `"extras.status`",
        `"url`": `"https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/`"
    }
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#$AddLocation =Add-Location -VNETLocation "Test3" -LocGuid "fdda098e-c5e3-4486-9a76-fe980a79d8be" -ParentLocGUID "c6202501-4c83-4e50-b389-fef65a547a27" -ParentLocURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/c6202501-4c83-4e50-b389-fef65a547a27/" -LocationTypeID "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/7a781a13-68c7-400b-8568-330713f3d8a7/"

function Add-CELocation {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETLocation,
        [Parameter(Mandatory = $true)] [string] $LocGuid,
                [Parameter(Mandatory = $true)] [string] $LocationTypeID,
        [Parameter(Mandatory = $true)] [string] $LocationTypeURL
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
{
    `"id`": `"$VNETGUID`",
    `"object_type`": `"dcim.location`",
    `"name`": `"$VNETLocation`",
    `"facility`": `"Azure`",
    `"parent`": null,
    `"location_type`": {
        "id": "$LocationTypeID`",
        "object_type": "dcim.locationtype",
        "url": "$LocationTypeURL`"
    },
    `"status`": {
        `"id`": `"5612ea68-1c4a-428a-8185-b31afa62869d`",
        `"object_type`": `"extras.status`",
        `"url`": `"https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/`"
    }
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#$AddCELocation =Add-CELocation -VNETLocation "Test3" -LocGuid "fdda098e-c5e3-4486-9a76-fe980a79d8be" -LocationTypeID "7a781a13-68c7-400b-8568-330713f3d8a7" -LocationTypeURL "https://nautobot.dpit.nationalgrid.com/api/dcim/location-types/7a781a13-68c7-400b-8568-330713f3d8a7/"

function Get-Tenant {
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/?limit=10000&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Tenant

function Add-Tenant {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETSubs
    )
    $ErrorActionPreference = "Stop";
    $VNETSubs = $VNETSubs.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
   {
     "name": `"$VNETSubs`",
     "description": ""
   }
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#Add-Tenant -VNETSubs "US-5874-QA-VNET-01"


function Get-Tags {
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/extras/tags/?limit=100000&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Tags

function Get-Tag {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETName
    )
    $ErrorActionPreference = "Stop";
    $VNETName =$VNETName.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/extras/tags/?name=" + $VNETName + "&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Tag


function Add-Tag {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETName
    )
    $ErrorActionPreference = "Stop";
    $VNETName =$VNETName.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
   {
    "name": `"$VNETName`",
    "object_type": "extras.tag",
    "content_types": [
        "ipam.prefix"
    ]
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/extras/tags/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
#Add-Tag -VNETName "US-5874-QA-VNET-01"


function Add-Prefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETGUID,
        [Parameter(Mandatory = $true)] [string] $VNETAddressSpace,
        [Parameter(Mandatory = $true)] [string] $Azure4LocationID,
        [Parameter(Mandatory = $true)] [string] $Azure4LocationURL,
        [Parameter(Mandatory = $true)] [string] $TenantID,
        [Parameter(Mandatory = $true)] [string] $TenantURL,
        [Parameter(Mandatory = $true)] [string] $TagID,
        [Parameter(Mandatory = $true)] [string] $TagURL
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
    {
        "id": `"$VNETGUID`",
        "prefix": `"$VNETAddressSpace`",
        "type": {
          "value": "network",
          "label": "Network"
        },
    "location":
        {
            "id": `"$Azure4LocationGUID`",
            "object_type": "dcim.location",
            "url": `"$Azure4LocationURL`"
        },
        "description": "",
        "status": {
          "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
          "object_type": "extras.status",
          "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
        },
        "tenant": {
            "id": `"$TenantID`",
            "object_type": "tenancy.tenant",
            "url": `"$TenantURL`"
        },
        "tags": [
            {
                "id": `"$TagID`",
                "object_type": "extras.tag",
                "url": `"$TagURL`"
            }
        ]
      }
"@

        Write-Debug $body
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response | ConvertTo-Json
    }
    catch {
        throw $_
    }
    return $response.value
}
#Add-Prefix -VNETGUID "fdda098e-c5e3-5486-9a76-fe980a79d8be" -VNETAddressSpace "10.10.10/24" -Azure3LocationID "7238da28-d537-4664-9325-c1452e67e0b9" -Azure3LocationURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/7238da28-d537-4664-9325-c1452e67e0b9/" -Azure4LocationID "21c5eba0-8fa6-4605-91db-5d3aa64c30f5" -Azure4LocationURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/21c5eba0-8fa6-4605-91db-5d3aa64c30f5/" -TenantID "bef5d476-99b2-4c0e-b091-0b615ff0e86a" -TenantURL "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/bef5d476-99b2-4c0e-b091-0b615ff0e86a/" -TagID "0462f477-4c5f-4447-b37d-2b09cdbbe326" -TagURL "https://nautobot.dpit.nationalgrid.com/api/extras/tags/0462f477-4c5f-4447-b37d-2b09cdbbe326/"


function Update-Prefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETGUID,
        [Parameter(Mandatory = $true)] [string] $VNETAddressSpace,
        [Parameter(Mandatory = $true)] [string] $Azure4LocationID,
        [Parameter(Mandatory = $true)] [string] $Azure4LocationURL,
        [Parameter(Mandatory = $true)] [string] $TenantID,
        [Parameter(Mandatory = $true)] [string] $TenantURL,
        [Parameter(Mandatory = $true)] [string] $TagID,
        [Parameter(Mandatory = $true)] [string] $TagURL
    )

    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
    [
    {
        "id": `"$VNETGUID`",
        "prefix": `"$VNETAddressSpace`",
        "type": {
          "value": "network",
          "label": "Network"
        },
    "locations":
        {
            "id": `"$Azure4LocationGUID`",
            "object_type": "dcim.location",
            "url": `"$Azure4LocationURL`"
        },
        "description": "",
        "status": {
          "id": "5612ea68-1c4a-428a-8185-b31afa62869d",
          "object_type": "extras.status",
          "url": "https://nautobot.dpit.nationalgrid.com/api/extras/statuses/5612ea68-1c4a-428a-8185-b31afa62869d/"
        },
        "tenant": {
            "id": `"$TenantID`",
            "object_type": "tenancy.tenant",
            "url": `"$TenantURL`"
        },
        "tags": [
            {
                "id": `"$TagID`",
                "object_type": "extras.tag",
                "url": `"$TagURL`"
            }
        ]
      }
      ]
"@

        Write-Debug $body
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/"

        $params = @{
            Method          = 'PATCH'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response | ConvertTo-Json
    }
    catch {
        throw $_
    }
    return $response.value
}
#Update-Prefix -VNETGUID "32bd271a-ef73-4895-9e60-650066fbb6e0" -VNETAddressSpace "10.82.100.0/26" -Azure3LocationID "7238da28-d537-4664-9325-c1452e67e0b9" -Azure3LocationURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/7238da28-d537-4664-9325-c1452e67e0b9/" -Azure4LocationID "21c5eba0-8fa6-4605-91db-5d3aa64c30f5" -Azure4LocationURL "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/21c5eba0-8fa6-4605-91db-5d3aa64c30f5/" -TenantID "4a4bc036-109d-486b-9d53-4d9ec5bfceca" -TenantURL "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/4a4bc036-109d-486b-9d53-4d9ec5bfceca/" -TagID "0462f477-4c5f-4447-b37d-2b09cdbbe326" -TagURL "https://nautobot.dpit.nationalgrid.com/api/extras/tags/0462f477-4c5f-4447-b37d-2b09cdbbe326/"





#$AzureGroup ="Azure 2.0"
$DuplicatePrefixes = New-Object System.Collections.Generic.List[System.Object]

try {

    Write-Output "Initiating Nuatobot Prefix discovery... " -Verbose


    $KeyVaultName = 'ng-prd-eus2-kv-01'
    $PATSecretName = 'GBL-SVC-NAUTOBOT-PAT'

    Set-AzContext -Subscription "US-HUB-Prod-01"
    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecretName `
        -ErrorAction Stop;
    Write-Output "getting PAT  from KV " -Verbose
    $PATValue = $PAT.SecretValue
    Write-Output "$PATValue " -Verbose
    if ($PATValue) {
        $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
        $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
        #$PATSecretText
    }
    else {
        { Write-Output "PAT is not found. please check the PAT Secret Value" }
    }


    <#Move Parent, Root & Global Object creation and retrieval here #>

    $GetLocationType = Get-LocationType
    $GetLocationTypeResults = $GetLocationType.results
    $GetLocationTypeResults
    foreach($locationType in $GetLocationTypeResults)
    {
    if($locationType.name -eq "Global")
    {
    $GloballocationtypeGuid = $locationType.id
    $GloballocationtypeURL = $locationType.url
    }
    if($locationType.name -eq "Cloud Environment")
    {
    $CElocationtypeGuid = $locationType.id
    $CElocationtypeURL = $locationType.url
    }
    if($locationType.name -eq "Region")
    {
    $RegionlocationtypeGuid = $locationType.id
    $RegionlocationtypeURL = $locationType.url
    }
    if($locationType.name -eq "Site")
    {
    $SitelocationtypeGuid = $locationType.id
    $SitelocationtypeURL = $locationType.url
    }
    }

    $getlocations = Get-Location
    $locationresults = $getlocations.results
    $locations = $getlocations.results.name
    $locations
    If ("Global" -notin $locations) {
        Write-Output "Global Location does not exist"
        $addlocation = Add-GlobalLocation
        $getlocations = Get-Location
        $locationresults =$getlocations.results
        $locations =$locationresults.name
    }
    else {
        Write-Output "Global Location exists"
        }

      If ("azure" -notin $locations) {
        Write-Output "azure Location does not exist"
        $AzureLocGuid = new-guid
        $addlocation = Add-CELocation -VNETLocation "Azure" -LocGuid $AzureLocGuid -LocationTypeID $CElocationtypeGuid -LocationTypeURL $CElocationtypeURL
        $getlocations = Get-Location
        $locationresults =$getlocations.results
        $locations =$locationresults.name
    }
    else {
        Write-Output "Azure Location exists"
        }

      If ("1.0" -notin $locations) {
        Write-Output "azure 1.0 Location does not exist"
        $Azure1LocGuid = new-guid
        $addlocation = Add-Location -VNETLocation "1.0" -LocGuid $Azure1LocGuid -ParentLocGUID $AzureLocationID -ParentLocURL $Azure1LocationURL -LocationTypeID $CElocationtypeGuid -LocationTypeURL $CElocationtypeURL
        $getlocations = Get-Location
        $locationresults =$getlocations.results
        $locations =$locationresults.name
    }
    else {
        Write-Output "Azure 1.0 Location exists"
        }

      If ("2.0" -notin $locations) {
        Write-Output "azure 2.0 Location does not exist"
        $Azure2LocGuid = new-guid
        $addlocation = Add-Location -VNETLocation "2.0" -LocGuid $Azure2LocGuid -ParentLocGUID $AzureLocationID -ParentLocURL $AzureLocationURL -LocationTypeID $CElocationtypeGuid -LocationTypeURL $CElocationtypeURL
        $getlocations = Get-Location
        $locationresults =$getlocations.results
        $locations =$locationresults.name
    }
    else {
        Write-Output "Azure 2.0 Location exists"
        }


        foreach ($location in $locationresults) {
    if ($location.name -eq "Global") {
        $GlobalLocationID = $location.id
        $GlobalLocationID
        $GlobalLocationURL = $location.url
        $GlobalLocationURL
    }


    if ($location.name -eq "azure") {
        $AzureLocationID = $location.id
        $AzureLocationID
        $AzureLocationURL = $location.url
        $AzureLocationURL
    }


   if ($location.name -eq "1.0") {
        $Azure1LocationID = $location.id
        $Azure1LocationID
        $Azure1LocationURL = $location.url
        $Azure1LocationURL
    }


       if ($location.name -eq "2.0") {
        $Azure2LocationID = $location.id
        $Azure2LocationID
        $Azure2LocationURL = $location.url
        $Azure2LocationURL
    }
    }

    if($AzureGroup -eq "Azure 1.0")
    {
        $Azure3LocationID = $Azure1LocationID
        $Azure3LocationID
        $Azure3LocationURL = $Azure1LocationURL
        $Azure3LocationURL
    }

    if($AzureGroup -eq "Azure 2.0")
    {
        $Azure3LocationID = $Azure2LocationID
        $Azure3LocationID
        $Azure3LocationURL = $Azure2LocationURL
        $Azure3LocationURL
    }

    $ExemptedSubs ="UK-5784C-PROD-05","UK-5784C-DEV-02","UK-0252A-DEV-03","UK-HUB-DEV-01","UK-5803A-DEV-01","UK-5803-DEV-01"
    #$ManagementGroups = 'Global-UK-NonProd','Global-US-NonProd','Global-UK-Prod','Global-US-Prod','UKAzure-Cloud1.0-Dev','UKAzure-Cloud1.0-Prod','USAzure-Cloud1.0-Dev','USAzure-Cloud1.0-Prod'
    #$ManagementGroups ='Global-US-NonProd'
    #$Tenat
    foreach ($ManagementGroup in $ManagementGroups) {

        $Subscriptions = Get-AzManagementGroup -GroupID $ManagementGroup -Expand -Recurse
        $subscriptionlist = $Subscriptions | foreach-object -MemberName Children
    
    
        $subscriptionlist | ForEach-Object {

            $subs = $_.Name
            $subs
            $subsName =$_.DisplayName
            $subsName
            if($subsName -notin $ExemptedSubs)
            {
                            <#
        Parse TenantID & TenantURL from Get-Parent
        #>
                        $GetTenants = Get-Tenant
                        $TenantResults = $GetTenants.results
                        #$TenantResults
                        $Tenants = $TenantResults.name
                        #$Tenants
                        $subsName = $subsName.ToLower()
                        if ($subsName -notin $Tenants) {
                            Write-Output "Tenant $subsName does not Exists"
                            $AddTenat = Add-Tenant -VNETSubs $subsName
                            $AddTenat
                        }
                        else {
                            Write-Output "Tenant Exists"
                        }

                        $GetTenants = Get-Tenant
                        $TenantResults = $GetTenants.results
                        foreach ($Tenant in $TenantResults) {
                            #$Tenant
                            $TenantName = $Tenant.name
                            if ($TenantName -eq $subsName) {
                                $TenantName
                                $TenantID = $Tenant.id
                                $TenantID
                                $TenantURL = $Tenant.url
                                $TenantURL
                            }
                        }

#GettingAddress Prefixes
            set-azcontext -SubscriptionId $subs
            $networks = Get-AzVirtualNetwork
            foreach ($network in $networks) {
            Write-output "Itterating through each VNET..."
                $VNETSubs = $subsName.ToLower()
                $VNETSubs
                $VNETName = $network.Name
                $VNETName =$VNETName.ToLower()
                $VNETLocation = $network.location
                $VNETLocation

                <#Add Tag specific logic here#>
                        $GetTags = Get-Tags
                        $tagresults = $GetTags.results
                        $Tags =$tagresults.name
                        #$Tags.GetType()
                       # foreach($tag in $Tags)
                        #{
                        if ($VNETName -notin $Tags) {
                            Write-output "Tag $VNETName does not exist, creating the tag..."
                            $Addtag = Add-Tag -VNETName $VNETName
                            $Addtag
                            $GetTags = Get-Tag -VNETName $VNETName
                            $tagresults = $GetTags.results
                            #$tagresults
                        }

                        else {
                            Write-output "Tag $VNETName already exists"
                       
                        }
                        #}
                        foreach ($Tag in $tagresults) {
                            #$Tenant
                            $TagName = $Tag.Name
                            if ($TagName -eq $VNETName) {
                                $TagName
                                $TagID = $Tag.id
                                $TagID
                                $TagURL = $Tag.url
                                $TagURL
                            }
                        }


                        If ($VNETLocation -notin $locations) {
                            Write-Output "$VNETLocation Location does not exist"
                            $LocGuid = new-guid
                            $addlocation = Add-Location -VNETLocation $VNETLocation -LocGUID $LocGuid -ParentLocGUID $GlobalLocationID -ParentLocURL $GlobalLocationURL -LocationTypeID $SitelocationtypeGuid -LocationTypeURL $SitelocationtypeURL
                            $addlocation
                            $getlocations = Get-Location
                            $locationresults = $getlocations.results
                         foreach ($location in $locationresults) {
                            if ($location.name -eq $VNETLocation) {
                                $VNETLocationID = $location.id
                                $VNETLocationID
                                $VNETLocationURL = $location.url
                                $VNETLocationURL
                            }
        
                        }
                        }

                        else {
        
                            Write-Output "$VNETLocation Location exists"

                         foreach ($location in $locationresults) {
                            if ($location.name -eq $VNETLocation) {
                                $VNETLocationID = $location.id
                                $VNETLocationID
                                $VNETLocationURL = $location.url
                                $VNETLocationURL
                            }

                        }
                    }


                $network.AddressSpace.AddressPrefixes | ForEach-Object {
                    $VNETAddressSpace = $_
                    write-output "current Subscription $VNETSubs has a VNET  - $VNETName in location $VNETLocation uses $VNETAddressSpace"
                    #Check if the Prefix exists
                     $CheckPrefix = Get-Prefix -VNETAddressSpace $VNETAddressSpace -Type "network"
                 
                     if ($null -eq $CheckPrefix.results) {
                        write-output "Address Prefix does not exists in Nautobot, Proceed to update..."

                        #Add VNET Prefixes in NautoBot
                        $VNETGUID =New-Guid
                        $UpdatePrefix = Add-Prefix -VNETGUID $VNETGUID -VNETAddressSpace $VNETAddressSpace -Azure4LocationID $VNETLocationID -Azure4LocationURL $VNETLocationURL -TenantID $TenantID -TenantURL $TenantURL -TagID $TagID -TagURL $TagURL
                        $UpdatePrefix
                        Write-Output "Address Prefix $VNETAddressSpace is updated in NautoBot "

                }
                else
                {
                write-output "Address Prefix exists in Nautobot, checking for updates and duplicates..."

                $CheckPrefixresults = $CheckPrefix.results
                $CheckPrefixresults
                $CheckPrefixLocationID =$CheckPrefixresults.Location.id 
                $CheckPrefixTagID = $CheckPrefixresults.Tags.id
                Write-output " Tag Check"
                $CheckPrefixTagID
                $TagID
                $CheckPrefixID = $CheckPrefixresults.id
                $CheckPrefixID
                $CheckPrefixParentID =$CheckPrefixresults.Parent.id
                $CheckPrefixParentID
                if($CheckPrefixTagID -eq $TagID)
                {
                    Write-output " No updates needed"
                }
                else {
                    Write-output "Address Space has been reassigned, checking for duplicates..."
                    $VNETAddressSpace
                    #Check if the container exists to identify duplicates. Tyep container will not have Tenant and hence, it is parent address space
                    $ParentAddressprefix = $VNETAddressSpace.Split('.')[0] + '.' + $VNETAddressSpace.Split('.')[1] + '.0.0/17'
                    $ParentAddressprefix
                    $GetParentAddressprefix = Get-Prefix -VNETAddressSpace $ParentAddressprefix -Type "container"
                    $GetParentAddressprefix
                    Write-Output "LocationIDs $VNETLocationID   $CheckPrefixLocationID "
                 if (($null -ne $GetParentAddressprefix.results) -and ($VNETLocationID -in $CheckPrefixLocationID))
                    {
                    Write-output " Address space is not duplicate..."
                    Write-output "Address Space needs to be updated with the new Tag"
                    #Update VNET Prefixes
                    #$VNETGUID =New-Guid
                    $CheckPrefixID
                    $VNETAddressSpace
                    $Azure3LocationID
                    $Azure3LocationURL
                    $VNETLocationID
                    $VNETLocationURL
                    $TenantID
                    $TenantURL
                    $TagID
                    $TagURL
                    $UpdatePrefix = Update-Prefix -VNETGUID $CheckPrefixID -VNETAddressSpace $VNETAddressSpace -Azure4LocationID $VNETLocationID -Azure4LocationURL $VNETLocationURL -TenantID $TenantID -TenantURL $TenantURL -TagID $TagID -TagURL $TagURL
                    $UpdatePrefix
                    Write-output "Address Space Update completed"
                       
                 }
                 else{

                 Write-output " Address space seems to be the duplicate one..."
                                $VNETName
                                $VNETAddressSpace
                                $DuplicatePrefixes.Add("$VNETName - $VNETAddressSpace")
                                $DuplicatePrefixes

                 }
                            


                }

                }

            }

        }
    }
}


}
write-output " List of duplicate address spaces"
$DuplicatePrefixes
Write-Host "##vso[task.setvariable variable=DuplicatePrefixes;isoutput=true]$DuplicatePrefixes"

}

catch {
    throw $_
    {1:<#Do this if a terminating exception happens#>}
}