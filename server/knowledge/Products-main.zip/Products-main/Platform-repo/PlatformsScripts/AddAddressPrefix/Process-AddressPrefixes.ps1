Function Get-QueueContext {
    param(

        [string]$storageAccountSubscriptionId,
        [string]$storageAccountName,
        [string]$storageAccountNameResourceGroup,
        [string]$queueName
    )

    try {
    
        Set-AzContext -Subscription $storageAccountSubscriptionId | Out-Null

        $staMetadata = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountNameResourceGroup
        $ctx = $staMetadata.Context

        # Retrieve a Address Prefix queue
        $queue = (Get-AzStorageQueue –Context $ctx).where( { $_.name -eq $queueName })

        If (-Not $queue ) {
            #create if doesnot exists.
            
            $queue = New-AzStorageQueue -Name $queueName -Context $ctx
        }
    }
    catch {
        throw "Exception `$_"
    }
    Return $queue
}

Function Add-VirtualNetworkPrefixToQueue {
    param(
        [string]$geo,
        [string]$subscriptionName,
        [string]$resourceGroupName,
        [string]$vNetName,
        [string]$subnetName,
        [string]$location,
        [string]$vNetAddressPrefix,
        [string]$subnetPrefix,
        [string]$requesterEmailAddress ,
        [string]$to,
        [string]$from,
        [Microsoft.WindowsAzure.Commands.Common.Storage.ResourceModel.AzureStorageBase]$queue
    )


    try {
        $addressPrefixMessage = @{
            SubscriptionName  = $subscriptionName
            resourceGroupName = $resourceGroupName
            VNetName          = $vNetName
            SubnetName        = $subnetName
            vNetAddressPrefix = $vNetAddressPrefix
            SubnetPrefix      = $subnetPrefix
            location          = $location
            geo               = $geo
            to                = $to
            from              = $from
            requesterEmailAddress = $requesterEmailAddress 
        } | ConvertTo-Json

        Write-Verbose "THERE IS A PROBLEM WITH THE BELOW QueueMessage in Azure PowerShell Version 12.1. Last Working Version is 11.3.1"

        $queueMessage = [Microsoft.Azure.Storage.Queue.CloudQueueMessage]::new($addressPrefixMessage)
        $queue.CloudQueue.AddMessage($queueMessage) 
        Write-Verbose "Request to update VirtualNetwork '$vNetName' and  adding address space '$($vNetAddressPrefix)' to Subscription '$($subscriptionName)' sucessfully added to Processing Queue." -Verbose

    }
    catch {
        throw "Exception ~$_"

    }

}

Function Get-VirtualNetworkPrefixFromQueue {
    param(
        [Microsoft.WindowsAzure.Commands.Common.Storage.ResourceModel.AzureStorageBase]$queue
    )
    try {
        # Read the message from the queue, then show the contents of the message.
        Write-Verbose "THERE IS A PROBLEM WITH THE BELOW QueueMessage in Azure PowerShell Version 12.1. Last Working Version is 11.3.1"
        $queueMessage = $queue.CloudQueue.GetMessageAsync()
    }
    catch {
        throw "Exception ~$_"
    }
    return $queueMessage 
}

Function Remove-MessageFromQueue {
    param(
        [Microsoft.WindowsAzure.Commands.Common.Storage.ResourceModel.AzureStorageBase]$queue,
        [System.Threading.Tasks.Task]$queueMessage
    )
    try {

        $queue.CloudQueue.DeleteMessageAsync($queueMessage.Result.Id, $queueMessage.Result.popReceipt)
    }
    catch {
        Throw "Exception `n$_"
    }
}