<#
 task will add a get next available product subnet
#>
Param(
    [string]$subscriptionName,
    [string]$virtualNetworkName,
    [Int32]$subnetCIDR

)

try {
    $virtualNetworkName = $virtualNetworkName.Trim()
    $subscriptionName = $subscriptionName.Trim()
    $vnet = (Get-AZVirtualNetwork).where( { $_.name -eq $virtualNetworkName }) 
    
    if ( -Not ([string]::IsNullOrEmpty($vnet)) ) {
        #
        # Get the current vnet configuration IP address space and all allocated subnets.
        # 
        # Need to re-arrange returned Address Prefixes values since values are arranged by provisioned order.
        #
        $subnetPrefixes = @($vnet.Subnets.AddressPrefix | Sort-Object -Descending)
        $addressPrefixes = @($vnet.AddressSpace.AddressPrefixes  | Sort-Object -Descending)
        Write-Verbose "Vnet Address Prefixes:`n$($addressPrefixes)`n" -Verbose
        Write-Verbose "Subnet Address Prefixes:`n$($subnetPrefixes)`n" -Verbose
        #
        # In case there is more than one address space, get the first address prefix from an ordered list
        # Initialize a pointer to only scope for current subnets Address prefix 

        $vSubnetIndex = 0
        
        foreach ($addressPrefix in $addressPrefixes) {
            #
            # we need to construct a list from the current IP Address space into all possible use case CIDRs.
            # this list will provide all potential available subnets that can be allocated.
            #
            Write-Verbose "Vnet Address Prefixes:`n$($addressPrefix)`n" -Verbose
            $splitSubnets = (Split-VirtualNetwork -addressPrefix $addressPrefix -subnetCIDR $subnetCIDR) 

            if ( -Not ($splitSubnets | Select-String 'greater or equal than Virtual Network CIDR')) {
              
                $addressPrefixRange = Get-SubnetRange -ipAddress $addressPrefix.ToString()
                #
                # Build Subnet prefix validation matrix to track which of vnet Subnets validation been verified for overlap or inuse.
                #
                $availableSubnets = New-Object 'object[,]' $($splitSubnets.Count), 2
                $i = 0
                foreach ($subnet in $splitSubnets) {
                    $availableSubnets[$i, 0] = $subnet 
                    $availableSubnets[$i, 1] = 1 # flag if this subnet is available for assignment.
                    $i++
                }
                #
                # Check all available potential subnets to be allocated from the above list. 
                # where each subnet is compared to the current in use subnet and verified if it overlaps, if so then this 
                # Potential subnet is not available for assignment.
                #
                $aSubnetIndex = 0
                for ($aSubnetIndex; $aSubnetIndex -lt $splitSubnets.Count; $aSubnetIndex++) {
                    #
                    # check all allocated subnets for availability or overlap/provisioned.
                    # First we get the subnet's Network ID (the first IP in the subnet) of a potential available subnet to use in validation
                    # validate potential subnet against currently allocated subnets for overlap and availability 
                    #
                    $subnetIndex = $vSubnetIndex 
                    $subentNetworkId = $availableSubnets[$aSubnetIndex, 0].Split('/')[0]
                    $availableHostIpAddress = Get-SubnetRange -ipAddress $availableSubnets[$aSubnetIndex, 0].ToString()
                    $subnetIndex = 0
                    for ($subnetIndex; $subnetIndex -lt $subnetPrefixes.Count; $subnetIndex++) {
                        #
                        # Since there would be potential of multiple address prefixes, we need to validate that we are dealing  
                        # with the selected subnet in validation scope 
                        # 
                        $allocatedNetworkId = $subnetPrefixes[$subnetIndex].ToString().Split('/')[0]
                        if ( $allocatedNetworkId -in $addressPrefixRange) {
                            # 
                            # Construct a list of IP address range from the current allocated subnet.
                            # This method will be utilized to check if subnets overlap.
                            #
                        
                            $hostIpAddress = Get-SubnetRange -ipAddress $subnetPrefixes[$subnetIndex].ToString()
                            #
                            # Now we need to check if the potential available subnet Network ID contained in the current allocated subent IP range.
                            # or if the current subnet over laps the proposed new subnet
                            #
                            if ( ($subentNetworkId -in $hostIpAddress ) -or ( $allocatedNetworkId -in $availableHostIpAddress)) {
                                #
                                # subnet in use and availablle subnet should not be selected.
                                #
                                $availableSubnets[$aSubnetIndex, 1] = 0
                                break
                            }
                        }
                    }
                    #
                    # We don't have a match, all current subnets validated and if no match, current 
                    # avaible subnet would be next to allocate, 
                    #
                    if ($availableSubnets[$aSubnetIndex, 1] -eq 1) {
                        #
                        # found an available subnet for use. set avaible flag and push the subnet value
                        #
                        Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'subnetPrefix', $availableSubnets[$aSubnetIndex, 0].ToString())
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subnetPrefix;issecret=false;isOutput=true', $availableSubnets[$aSubnetIndex, 0].ToString())
                        Write-Verbose "Found unallocated subnet : $($availableSubnets[$aSubnetIndex, 0].ToString())" -Verbose
                        return $availableSubnets[$aSubnetIndex, 0].ToString()
                    }
                }
                #
                # Get the starting Point indicator for the next set Subnet prefixes.
                #
                $vSubnetIndex = $SubnetIndex + 1
            }
        }
        #
        # All available subnets are exhausted and are either overlapped or already assigned.
        # The current provisioned vNet has no available IP block to assign. A new CIDR block needs to be provisioned
        #
        Write-Verbose "Warning | All possible IP address currenly inuse. Need to request new CIDR block" -Verbose
        Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'subnetPrefix', "Address Space Needed")
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subnetPrefix;issecret=false;isOutput=true', "Address Space Needed")

    }
    else {
        throw "Error | Exception`n$_"
    }
}
catch {
    throw "Error | Exception`n$_"
}
  
Write-Verbose  "`nGet Subnet Prefix completed." -Verbose

