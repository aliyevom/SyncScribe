<#
.SYNOPSIS
    Utility Functions of various capabilities

.DESCRIPTION
    Helper functions that provides utilities to various executions

.PARAMETER FUNCTIOS
    List of Utility functions
    
    Remove-Lock
    Add-Lock
    Remove-VirtualNetworkPeering
    Add-VirtualNetworkPeering
    Get-PeeringStatus
    Disconnect-VirtualNetworkPeering
    Update-VirtualNetwork
    Get-Subnet 
    Convert-IpAddressToBase64
    Convert-IpAddressToDot
    Split-VirtualNetwork
    Send-Mail
    Get-SubnetRange
    Find-AzureFirewallCollectionPriority
    Get-AzureFirewallRuleCollection
    New-FirewallRuleSet
    New-NetworkFirewallRuleSet
    New-ApplicationFirewallRuleSet
    Add-FirewallRuleSet
    Add-NetworkFirewallRuleSet
    Add-ApplicationFirewallRuleSet
    Test-ValidIpAddress
    Test-destinationPorts
    Add-TableStorage
    Update-IngressEgressTable
    Get-Office365EndPointURL
    Test-ValidIp
    Sync-VirtualNetworkPeering

.PARAMETER  subscriptionId
    Subscription Id in context.

.PARAMETER localVnetPeer
    Virtual Network Peering component. would refernce Virtual network in context

.PARAMETER remoteVnetPeer
    Virtual Network Peering component. would refer to partner virtual Network 

.PARAMETER virtualNetworkPeerName 
    Virtual Network Peering label

.PARAMETER IpAddress
    Type (IPADDRESS) an IPV4 IP address to perform actions 

.PARAMETER CIDR
    Integer that represents Network/subnet CIDR

.PARAMETER Int64
    type Long IPv4 Address representation 

.PARAMETER vNetCIDR
    Integer that represents Network CIDR

.PARAMETER subnetCIDR
   Integer that represents Subnet CIDR

.PARAMETER addressPrefix
   String representation of virtual Network / Subnet address spaces.

.PARAMETER azFireWall
   Firewall metadata object.

.PARAMETER ruleCollectionType
   String representation of Firewall (classic) rules collection type (NetworkRuleCollections /ApplicationRuleCollections )
   
.PARAMETER ruleCollectionName
   String representation of an Azure Firewall Rule Collection.

.PARAMETER firewallRule
   PowerShell object representation of the firewall rule

.PARAMETER collectionPriority
   Integer value for the next available Collection type priority number

.PARAMETER subscriptionId
   Subscription Id activitiies based on (spoke subscription)

.PARAMETER sourceIpAddress
   IPv4 String representation of IP address 

.PARAMETER region
   Azure region  

.PARAMETER servicePorts
   Array String type of IP ports 

.PARAMETER appServicePorts
   Array String type of Firewall supported Application rules ports (443,80 and 1443)

.EXAMPLE

.NOTES
	Version      : 1.1.0
	Last Updated : 7/30/2021
#>
<#
# Function Send-Mail
#   This function can be leveraged to send email
#
# Input:
#   to:
#       Email message to
#   from:
#       Email message from
#   emailSubject:
#       Email Subject
#   messageContent: 
#       Email Message Body
#   smtpServer:
#       SMTP Server Name
#   portnumber:
#       Port Number
# Output:
#   Informational or Exception 
#>
Function Send-Mail {
    param(
        [string[]] $to,
        [string] $from,
        [string] $emailSubject,
        [string] $messageContent,
        [string] $smtpServer,
        [int32] $portnumber
    )

    try {
        Write-Verbose "Sending Mail.." -Verbose 
        $emailPattern = '^[^@\s]+@[^@\s]+\.[^@\s]+$'
        $toEmailAddresses = @()
   
        foreach ($emailAddress in $to.Split(',')) {
       
            if ($emailAddress -match $emailPattern) {
                $toEmailAddresses += $emailAddress
            }
        }
        $mailBody = @{
            To         = $toEmailAddresses
            From       = $from 
            Subject    = $emailSubject
            Body       = $messageContent
            smtpServer = $smtpServer
            Port       = $portnumber
            BodyAsHtml = $true
        }
        Send-MailMessage @mailBody -Verbose
        Write-Verbose "Email sent with subject:$emailSubject" -Verbose
    }
    catch {
        Write-Warning -Message "Failed to send Mail`n$_" -Verbose
    }
}

Function Remove-Lock {
    Param(
        [Hashtable]$resourceLock
    )

    try {

        if ( ($lock = (Get-AzResourceLock @resourceLock | Where-Object { $_.properties.level -eq 'CanNotDelete' })) ) {
            $lock
            $i = 0
            if ( $lock.GetType().Name -eq 'Object[]') {
                foreach ($lck in $lock) {
                    if ($lck.Name -eq 'resourceGroupDoNotDelete') {
                        $lock = $lock[$i]
                        break
                    }
                    else {
                        $i++
                    }
                }
            }
            Remove-AzResourceLock @resourceLock -LockName $lock.Name -Force
            Start-Sleep -Seconds 60
            Write-Verbose "Lock '$($lock.Name)' for resource '$($resourceLock.ResourceName)' Removed." -Verbose
            Return $true
        }
    }
    catch {
        if (($_ -contains 'A positional parameter cannot be found that accepts') ) {
            Write-Verbose "Resource '$($resourceLock.ResourceName)' not locked for delete." -Verbose
        }
        else {
            throw "Exception remove Lock `n$_"
        }
    }
    Return $false
}
Function Add-Lock {
    Param(
        [Hashtable]$resourceLock
    )

    try {
        $resourceLock
        New-AzResourceLock @resourceLock -Force
        Start-Sleep -Seconds 60
        Write-Verbose "Lock '$($resourcelock.LockName)' for resource '$($resourceLock.ResourceName)' added." -Verbose
        
    }
    catch {
   
        Write-verbose "Exception adding Lock `n$_" -Verbose
    }
}
<#
# Function Remove VirtualNetworkPeering
#   This function deletes the vnet-vnet peering . 
#
# Input:
#   subscriptionId:
#       Subscription Id to initialize the peering from
#   localVnetPeer:
#       The Virtual Network Object that initiated the peering request
#   virtualNetworkPeerName:
#       Constructed peering object name
#
# Output:
#   Informational or Exception 
#>
Function Remove-VirtualNetworkPeering {
    PARAM(
        [string] $subscriptionId,
        [object] $localVnetPeer,
        [string] $virtualNetworkPeerName 
    )

    # Remove Vnet Peering.
    try {
        Set-AzContext -Subscription $subscriptionId
        Remove-AZVirtualNetworkPeering  -ResourceGroupName $localVnetPeer.ResourceGroupName `
            -VirtualNetwork $localVnetPeer.Name `
            -Name $virtualNetworkPeerName -Force `
            -ErrorAction SilentlyContinue -ErrorVariable er

        if ($er) {
            Throw "Error | Virtual Network  $($localVnetPeer.Name)  Peering $($virtualNetworkPeerName)  Peering failed`n" + $er
        }
        else {
            $info = "Information | Virtual Network $($localVnetPeer.Name)  Peering $($virtualNetworkPeerName) successfully removed."
        }
    }
    catch {
        Throw "Error | Exception deleting Virtual Network Peering`n" + $_ 
    }
    Return $info
}
<#
                   

<#
# Function Add VirtualNetworkPeering
#   This function performs the vnet-vnet peering. This funtion will identify if the peering direction and set the peering status according .
#   Peering Hub to Spoke we need to enable transit gateway while spoke to hub enable remotegateway switching. 
#
# Input:
#   subscriptionId:
#       Subscription Id to initialize the peering from
#   vnetPeeringName:
#       Constructed peering object name
#   localVnetPeer:
#       The Virtual Network Object that initiated the peering request
#   remoteVnetPeer:
#       The remote peering partner Network Object

# Output:
#   Informational or Exception 
#>
Function Add-VirtualNetworkPeering {
    PARAM(
        [string] $vnetPeeringName,
        [object] $localVnetPeer,
        [string] $remoteVnetPeerId,
        [switch] $isHub = $false,
        [switch] $remoteHub = $false
    )
    # Peer local VNet to Remote VNet.
    try {
        $vNetPeering = @{
            Name                   = $vnetPeeringName 
            VirtualNetwork         = $localVnetPeer
            RemoteVirtualNetworkId = $remoteVnetPeerId
            AllowForwardedTraffic  = $true
            ErrorAction            = "SilentlyContinue" 
            ErrorVariable          = "er" 
            Verbose                = $true
        }
        if ($isHub) {
            $vNetPeering.Add("AllowGatewayTransit", $true)
        }
        else {
            if ($remoteHub) {
                $vNetPeering.Add("UseRemoteGateways", $true)                
            }
        }
        Add-AZVirtualNetworkPeering @vNetPeering
        if ($er) {           
            Throw "Error | Peering Virtual Networks '$($localVnetPeer.Name)' Peering Id  '$($remoteVnetPeerId)' failed`n" + $er
        }
        else {
            $info = "Information | Virtual Networks '$($localVnetPeer.Name)' Peering Id  '$($remoteVnetPeerId)' successfully created."
        }
    }
    catch {
        Throw "Error | Exception creating Virtual Network Peering`n " + $_ 
    }                       

    Return $info 



}

<#
# Function Sync VirtualNetworkPeering
#   This function performs the hub vnet-spoke vnet peering sync. This funtion will identify if the peering in not in full sync and do a sync of  the peering status according .
# Input:
#   subscriptionName:
#       Subscription Name to Sync the peering for
#   ResourceGroupName:
#       ResourceGroup of the Vnet
#   VirtualNetworkName:
#       The Virtual Network Name to get the peering
#   remoteVnetPeer:
#       The remote peering partner Network Object
#   isHub:
#       an Identifier whether the peering initiaited for a hub or spoke to set peeering paramters accordingly
#
# Output:
#   Informational or Exception 
#>


Function Sync-VirtualNetworkPeering {
    PARAM(
        [string] $geo,    
        [string] $region,    
        [string] $subscriptionName,
        [string] $ResourceGroupName,
        [string] $VirtualNetworkName
    )
    # Sync peering of local VNet to Remote VNet.
    try {
        set-azcontext -Subscription $subscriptionName
        $VNet = Get-AzVirtualNetwork -Name $VirtualNetworkName -ResourceGroupName $ResourceGroupName
        if ($VNet) {
            $Peerings = $Vnet.VirtualNetworkPeerings
            $Peerings
            $SVnetRG = $VNet.ResourceGroupName
            $SVNetName = $VNet.Name
            if ($Peerings) {
                foreach ($Peering in $Peerings) {
                    $PeeringName = $Peering.Name
                    $SVnetRG
                    $PeeringName
                    $remoteVirtualNetworkId = ($Peering.RemoteVirtualNetwork.Id).Split('/', [System.StringSplitOptions]::RemoveEmptyEntries)
                    $remoteVirtualNetworkId
                    $remoteSubscriptionId = $remoteVirtualNetworkId[1]
                    $remoteSubscriptionId
                    $remoteNetworkResourceGroupName = $remoteVirtualNetworkId[3]
                    $remoteNetworkResourceGroupName
                    $remoteNetworkName = $remoteVirtualNetworkId[-1]
                    $remoteNetworkName
                    #Sopke Peer Sync Initiation
                    set-azcontext -Subscription $subscriptionName
                    $SVnetPeer = Get-AzVirtualNetworkPeering -Name $PeeringName -VirtualNetworkName $SVNetName -ResourceGroupName $SVnetRG
                    $SVNetpeerSyncStatus = $SVnetPeer.PeeringSyncLevel
                    Write-Output "$PeeringName is $SVNetpeerSyncStatus" -Verbose
                    if ($SVNetpeerSyncStatus -ne 'FullyInSync') {
                        Write-Output "Initiatig VNet Peering Sync" -Verbose
                
                        $SVnetPeer | Sync-AzVirtualNetworkPeering
                
                    }
                    #Hub Peer Sync Initialization
                    $RemotepeeringName = $remoteNetworkName+"-to-"+$SVNetName+"-peer"
                    set-azcontext -Subscription $remoteSubscriptionId
                    $HVnetPeer = Get-AzVirtualNetworkPeering -Name $RemotepeeringName -VirtualNetworkName $remoteNetworkName -ResourceGroupName $remoteNetworkResourceGroupName   
                    if ($HVnetPeer) {
                    
                        $HVNetpeerSyncStatus = $HVnetPeer.PeeringSyncLevel
                        Write-Output "$RemotepeeringName is $HVNetpeerSyncStatus" -Verbose
                        if ($HVNetpeerSyncStatus -ne 'FullyInSync') {
                            Write-Output "Initiatig VNet Peering Sync" -Verbose

                            $HVnetPeer | Sync-AzVirtualNetworkPeering

                        }
                
                        }

                    }
                }
            }
        }
            catch {
                Throw "Error | Exception Syncing Virtual Network Peering`n " + $_ 
            }                       

            Return $info 
        }

#
# This Function validates if a spoke vNet is already peered to its hub. The function will then retreieve the 
# Peering Name and pass it back to the calling api. The function expects the Hub and Spoke Virtual Network
# objects.
#
# Inputs:
#   localVnetPeer : 
#       This is an Azure vNet object that is designated to the source vNet.
#   remoteVnetPeer:
#       This is an Azure vNet object that is designated to the remote Parneter vNet.
#
# Output:
#   Peering Name or an Error
#
Function Get-PeeringStatus {
    PARAM(
        [object] $localVnetPeer,
        [object] $remoteVnetPeer 
    )

    try {
        if (($peered = $localVnetPeer.VirtualNetworkPeerings | Where-Object { $_.RemoteVirtualNetwork.Id -eq $remoteVnetPeer.Id })) {
            $info = $peered.Name
        }
        else {
            $info = "Warning | No peering for '$($localVnetPeer.Name)' can not be found"
        }
    }
    catch {
        $info = "Error | Exception $_"
    }
    Return  $info 
}
<#
#
#  Function Delete VnetPeering
#   This is a peering driver function, first validatesv validates if remote/spoke are peered and if it is will remove  peering pair by first peeing Spoke to its remote
#   The Peer the remote to Spoke
#
#  Input:
#   remoteSubscriptionId:
#       The  remote subscription ID, there should be only one remote hub per Geo/region
#   remoteNetworkResourceGroupName:
#       The  remote Network resource group, one per region 
#   remoteNetworkName:
#       The  Virtual Network name, there should be one virtual Network per remote per region
#   localubscriptionId:
#       The  product line Subscription to peer remote with
#   localNetworkResourceGroupName:
#       The  spoke Network resource group, one per region 
#   localNetworkName:
#       The spoke Virtual Network name, there should be one virtual Network per Product Line  per region
#
# Output:
#   Informational or Exception
#>
Function Disconnect-VirtualNetworkPeering {
    PARAM(
        [String] $remoteSubscriptionId,
        [String] $remoteNetworkResourceGroupName,
        [String] $remoteNetworkName,
        [String] $localSubscriptionId,
        [String] $localNetworkResourceGroupName,
        [String] $localNetworkName
    )

    try {
        #
        # Get remote/local Vnet Metadata
        #
        Write-Verbose "Setting Remote Context."-Verbose
        Set-AzContext -Subscription  $remoteSubscriptionId
        $remotevNetObject = Get-AZVirtualNetwork -ResourceGroupName $remoteNetworkResourceGroupName -Name $remoteNetworkName
        $remotevNetObject
        # only if Remote Network Locks enabled
        $vNetLocked = @{
            ResourceGroupName = $remoteNetworkResourceGroupName
        }
        $remoteLocked = Remove-Lock -resourceLock $vNetLocked 
        Write-Verbose "Remote Virtual Network Lock status`n$remoteLocked " -Verbose
        Write-Verbose "Setting Local Context."-Verbose
        Set-AzContext  -subscription $localSubscriptionId
        $localvNetObject = Get-AzVirtualNetwork -Name $localNetworkName -ResourceGroupName $localNetworkResourceGroupName
        $localvNetObject 

        $virtualNetworkPeerName = Get-PeeringStatus -localVnetPeer $localvNetObject -remoteVnetPeer $remotevNetObject
        if ( -not (($virtualNetworkPeerName | Select-String 'Error' ) -or ($virtualNetworkPeerName | Select-String 'Warning' ))) {
            Write-Verbose "Removing Spoke Peering object " -Verbose
            $peeringObject = @{
                subscriptionId         = $localSubscriptionId 
                localVnetPeer          = $localvNetObject  
                virtualNetworkPeerName = $virtualNetworkPeerName
            }
           
            $peeringObject 
            Remove-VirtualNetworkPeering  @peeringObject  -Verbose
            Write-Verbose "Removing Spoke Peering object Completed " -Verbose
        }
        else {
            if ($virtualNetworkPeerName | Select-String 'Error' ) {
                Throw " Exception `n$virtualNetworkPeerName"
            }
        }

        $virtualNetworkPeerName = Get-PeeringStatus -localVnetPeer $remotevNetObject -remoteVnetPeer $localvNetObject
        if ( -not (($virtualNetworkPeerName | Select-String 'Error' ) -or ($virtualNetworkPeerName | Select-String 'Warning' ))) {
            Write-Verbose "Removing Remote Peering object  " -Verbose
            $peeringObject = @{
                subscriptionId         = $remoteSubscriptionId 
                localVnetPeer          = $remotevNetObject  
                virtualNetworkPeerName = $virtualNetworkPeerName
            }
            Remove-VirtualNetworkPeering @peeringObject  -Verbose
            Write-Verbose "Removing Remote Peering object Completed " -Verbose
        }
        else {
            if ($virtualNetworkPeerName | Select-String 'Error' ) {
                Throw " Exception `n$virtualNetworkPeerName"
            }
        }
        # Only if Remote Virtual Network Locks were enabled.
        Write-Verbose "Remote Locked is: `n$remoteLocked " -Verbose
        if ($remoteLocked) {
            $resourceLock = @{
                LockLevel         = "CanNotDelete"
                LockName          = "resourceGroupDoNotDelete"
                ResourceGroupName = $remoteNetworkResourceGroupName
            }
            Add-Lock -resourceLock $resourceLock
        }

    }
    catch {
        throw "Error | Exception $_"
    }
    Return $virtualNetworkPeerName 
}

<#
# This Function will update an exisiting Virtual Network with a newly allocated IP Address space. the Function will not update the Subnets 
# also assumes a virtual network already exists.
#
#  
#  Input:
#   SubscriptionId:
#       This is the Susbcriotion where the new IP address space is allocated
#   networkResourceGroupName:
#       This is the Virtual Network resource group Name
#     IpAddress:
#       This is new IP prefix to be added and must be with the following format x.x.x.x/n
#
#  Output:
#       Virtual network update status Sucess or failure
#>
Function Update-VirtualNetwork {
    PARAM(
        [string] $subscriptionId,
        [string] $virtualNetworkName,
        [string] $networkResourceGroupName,
        [string] $ipAddress
    )

    # Get Vnet Metadata (like vNet name, subnet, peering objects, IP address prefix etc.
    try {
        #
        # Virtual Network Metadata
        #
        $virtualNetworkName = $virtualNetworkName.Trim()
        $networkResourceGroupName = $networkResourceGroupName.Trim()
        $subscriptionId = $subscriptionId.Trim()
        Set-AzContext -Subscription  $subscriptionId
        $vNetObject = Get-AZVirtualNetwork -ResourceGroupName $networkResourceGroupName -Name $virtualNetworkName


        if ( -not ($ipAddress -in $vNetObject.AddressSpace.AddressPrefixes)) {
            # Add the new IP address block to the existing list after validating no duplicates. This will not validate overlap 
            $vNetObject.AddressSpace.AddressPrefixes.Add($ipAddress)
            Set-AzVirtualNetwork -VirtualNetwork $vNetObject 
            Write-Verbose "Information | IP address block '$($IpAddress)' added to Virtual Network '$($vNetObject.Name)' IP Address prefix set" -Verbose

        }
        else {
            Write-Verbose " IP address block '$($IpAddress)' already set to Virtual Network '$($vNetObject.Name)'. " -Verbose
        }
    }
    catch {
        Throw  "Error | Exception retrieving Virtual Network Metadata Object `n" + $_ 
    }
    
}

Function Get-Subnet {

    param(
        [IPAddress]$IpAddress,
        [Int32]$CIDR
    )
    
    try { 
        # Get CIDR Address by parsing it into an IP-Address and and it 
        $CIDRAddress = [System.Net.IPAddress]::Parse([System.Convert]::ToUInt64(("1" * $CIDR).PadRight(32, "0"), 2))
        $networkIdBinary = $IpAddress.Address -band $CIDRAddress.Address
        $networkId = [System.Net.IPAddress]::Parse([System.BitConverter]::GetBytes([UInt32]$networkIdBinary) -join ("."))
        $hostBits = ('1' * (32 - $CIDR)).padLeft(32, "0")       
        # Convert Bits to Int64
        $availableIPs = [Convert]::ToInt64($hostBits, 2) + 1
            
        # Build subnets and number of hosts hash table
        $result = [pscustomobject]@{
            NetworkID = $networkId
            IPs       = $AvailableIPs
        }
    }
    catch {
        $result = "Error | (Get-Subnet) Exception $_"
    }

    Return  $result
    
}
<#
# Function Convert IpAddressToBase64
#   This function converts an IP address into its base 64 format to use for computing hosts and other computations
# 
# Input:
#   IpAddress:
#       The IP address to be converted
# 
# Output:
#   IP Address string
#>
Function Convert-IpAddressToBase64 {
    PARAM(
        [IPAddress]$IpAddress
    ) 

    $Octets = $IpAddress.ToString().Split(".")    
    $Int64 = [long]([long]$Octets[0] * 16777216 + [long]$Octets[1] * 65536 + [long]$Octets[2] * 256 + [long]$Octets[3]) 

    Return $Int64
}
<#
# Function Convert IpAddressToDot
#   This function converts an IP address into its dot format string
# 
# Input:
#   IpAddress:
#       The IP address to be converted
#
# Output:
#   IP Address string
#>
Function Convert-IpAddressToDot {
    PARAM(
        [long]$Int64
    ) 

    $ipAddress = [IPAddress](([System.Math]::Truncate($Int64 / 16777216)).ToString() + "." + `
        ([System.Math]::Truncate(($Int64 % 16777216) / 65536)).ToString() + "." + `
        ([System.Math]::Truncate(($Int64 % 65536) / 256)).ToString() + "." + `
        ([System.Math]::Truncate($Int64 % 256)).ToString())
     
    Return  $ipAddress 
}
<#
# Function Split VirtualNetwork 
# purpose to take an IP Address block and then breaks the Network into designated subnets
#
# Inputs:
#   IpAddress:
#       This is an Azure vNet IP address space object that is for the new services.
#   vNetCIRD:
#       The virtual Network CIDR in use
#   subnetCIDR:
#       The Subnets CIRD to break the Virtual Network IP block 
#
# Output:
#   Subnets List or Exception
#
#>
Function Split-VirtualNetwork {
    
    param(
        [Parameter(Mandatory)]
        [string]$addressPrefix,

        [Parameter(Mandatory)]
        [Int32]$subnetCIDR        
    )
      
    begin {
        Write-Debug ("{0} entered" -f $MyInvocation.MyCommand) 
    }
    
    process {
        $info = @()
        [IPAddress]$IpAddress = ($addressPrefix -split '/')[0]
        [Int32]$vNetCIDR = ($addressPrefix -split '/')[1]
        if ($vNetCIDR -gt $subnetCIDR) {
            $info = "Erorr | Subnet CIDR (/$subnetCIDR) can't be greater or equal than Virtual Network CIDR (/$vNetCIDR)"
        }
        else {
            # Calculate the current Subnet
            $subnet = Get-Subnet -IpAddress $IpAddress -CIDR $vNetCIDR
            if ( -not ($subnet | Select-String "Error")) {

                $NewHostBits = ('1' * (32 - $subnetCIDR)).PadLeft(32, "0")
                $NewAvailableIPs = ([Convert]::ToInt64($NewHostBits, 2) + 1)
                $networkId_Int64 = Convert-IpAddressToBase64 -IpAddress $Subnet.NetworkID
        
                # Build new subnets, and return a list of subnets

                for ($i = 0; $i -lt $Subnet.IPs; $i += $NewAvailableIPs) {
                    $ipcidr = "{0}/{1}" -f (Get-Subnet -IpAddress (Convert-IpAddressToDot -Int64 ($NetworkID_Int64 + $i)) -CIDR $subnetCIDR).NetworkID.ToString(), $subnetCIDR
                    $info += $ipcidr
                    
                }               
            }
            else {
                $info = $subnet
            }
        }
        Return $info 
    }
    
    end {
        Write-Debug ("{0} exited" -f $MyInvocation.MyCommand) 
    }
} 
<#
# Function Get SubnetRange. 
# A function that will build a list of IP address contained in a subnet. The Function will take an Network Address in CIDR format then break it up 
#          into Network Id and number of hosts. The final outcome will be a list of IP address including the NetworkId and the broadcast Addresses.
# 
# Inputs:
#   IpAddress:
#       This is an Azure vNet/subnet IP address space in the format x.x.x.x/n.
#
# Output:
#   A List of IP address or Exception
#
#>
function Get-SubnetRange {
    param(
        [string]$ipAddress
    )
    #
    # Declare Array List to host all IPs for the specified subnet
    #
    $subnetRange = [System.Collections.ArrayList]@()
    if ($ipAddress.Contains('/')) {
        $temp = $ipAddress.Split('/')
        $ipAddress = $temp[0]
        $cidr = $temp[1]
    }
    else {
        Return "Error | The Ip Address prefix '$($ipAddress)' format is not valid.`nIP Address prefix should be in the following format x.x.x.x/nn"
    }
    try {

        $network = Get-Subnet $ipAddress $cidr
        if ( -not ($network | Select-String "Error")) {
            #
            # Get the Network Id and the number of available hosts for the selected Network/subnet
            #
            $networkId = Convert-ipAddressToBase64 -ipAddress $network.NetworkID
            $numberOfHosts = $network.IPs + $networkId
            #
            # Build a list of IP addresses that are contained in this subnet.
            #
            for ($i = $($networkId); $i -lt $numberOfHosts; $i++) {
                $subnetRange.Add((Convert-IpAddressToDot -Int64 $i).IPAddressToString) | Out-Null
            }
        }
        else {
            $subnetRange = $network
        }
    }
    catch {
        $subnetRange = "Error | (Get-SubnetRange) Exception construction subnet IP address ranges. `n$_"
    }

    Return $subnetRange
}
<#   
# Function Find AzureFirewallCollectionPriority
# 
#  A Function to programmatically generate Network or Application rule collections next available priority Number. The exception for the two
#  default rules Datadog and Egress proxy which will get 100 and 200 assignment.
#
#  Input:
#   azFireWall                : Azure Firewall object to be updated.
#   Rulecollection Type : Azure Firewall supports 3 types of Rule collections "NAT Rule Collection", 
#                        "Network Rule Collection" and "Application Rule Collection"
#
#  Output:
#       Priority or Exception/Error 
#>
Function Find-AzureFirewallCollectionPriority {
    param(
        [psObject] $azFireWall,
        [string] $ruleCollectionType
    )

    try {
        if (-Not ([string]::IsNullOrEmpty($ruleCollectionType))) {
            
            $collectionPriorities = @($azFireWall.$($ruleCollectionType) | select-object -ExpandProperty  priority | Sort-Object  ) 
            $collectionPriority = $defaultBasePriority

            if ($collectionPriorities[-1] -ge $defaultBasePriority) {
                $collectionPriority = $collectionPriorities[-1] + $defaultPriorityIncrement
            }
    
        }
        else {
            $collectionPriority = "Error | Azure Firewall Collection Rule type can't be Null."
        }
    }
    catch {
        $collectionPriority = "Error | (Find-AzureFirewallCollectionPriority) Exception $_"
    }

    Return $collectionPriority
}
<#   
# Function Get AzureFirewallRuleCollection
#
#  Function to retrieve a match rule collection. The Function will get either Application or Network Rule collection.
#  if None is found, an indication to create new rule collection. The collection retrieve based on Customer rule selection type
#
#  Input:
#    azFireWall : Firewall metadata object
#    rulecollectonName : name of the collection to match
#    rulecollectionType : the type of collection Network or application
#
#  Output:
#       Rulecollection Object or Exception/Error 
#>
Function Get-AzureFirewallRuleCollection {
    param(
        [PsObject]$azFireWall,
        [string]$ruleCollectionName,
        [string]$ruleCollectionType
    )

    try {
        if (-Not ([string]::IsNullOrEmpty($ruleCollectionType))) {

            switch ($ruleCollectionType) {

                NetworkRuleCollections { $status = $azFireWall.GetNetworkRuleCollectionByName($ruleCollectionName) }
                ApplicationRuleCollections { $status = $azFireWall.GetApplicationRuleCollectionByName($ruleCollectionName) }
                Default { $status = "Error | Azure Firewall Collection Rule type invalid." }

            }

        }
        else {
            $status = "Error | (Get-AzureFirewallRuleCollection) Azure Firewall Collection Rule type can't be Null."
        } 

    }
    catch {

        $status = "Error |(Get-AzureFirewallRuleCollection) $_"
    }
    Return $status
}
<#
# Function New AzureFirewallRule
#
#  Function to create a new Collection set. The collectionset to create either Network or Application and will be created based on 
#  the collection type passed to the runbook from the api
#
#  Input:
#    azFireWall               : Firewall metadata object
#    rulecollectonName  : name of the collection to match
#    rulecollectionType : the type of collection Network or application
#    firewallRule       : Rule to to create in the form of Hash Table
#
#  Output:
#    Rulecollection Object or Exception/Error 
#>
Function New-FirewallRuleSet {
    param(
        [PsObject]$azFireWall,
        [string]$ruleCollectionName,
        [string]$ruleCollectionType,
        [psObject]$firewallRule
  
    )

    try {

        $collectionPriority = Find-AzureFirewallCollectionPriority -azFireWall $azFireWall -ruleCollectionType  $ruleCollectionType
    
        if (-Not ($collectionPriority | Select-String "Error")) {
            #
            # Selection rule set Type to create.
            #
            switch ($ruleCollectionType) {

                NetworkRuleCollections {
                    $status = New-NetworkFirewallRuleSet     -azFireWall $azFireWall -ruleCollectionName $ruleCollectionName `
                        -firewallRule $firewallRule -collectionPriority $collectionPriority
                }
                
                ApplicationRuleCollections {
                    $status = New-ApplicationFirewallRuleSet -azFireWall $azFireWall -ruleCollectionName $ruleCollectionName `
                        -firewallRule $firewallRule -collectionPriority $collectionPriority
                }
                
                Default { $status = "Error | Azure Firewall Collection Rule type invalid." }
            }
        }
        else {
            $status = $collectionPriority
        }
        
    }
    catch {
        throw $_
    }
    Return $status
}
<#   
Function New NetworkFirewallRuleSet
#
#  This function will create a new Network Collection ruleset and then add the new Network rule to the collection. Priority of the collection
#  generated and passed as parameter.
#
#  Input:
#    azFireWall                : Firewall metadata object
#    rulecollectonName   : name of the Network ruleset collection to create
#    collection Priority : Network Collection ruleset priority.
#    firewallRule        : Network Rule to create in the form of Hash Table
#
#  Output:
#    Network Rule creation details or Exception/Error 
#>
Function New-NetworkFirewallRuleSet {
    param(
        [psObject]$azFireWall,
        [int]$collectionPriority,
        [string]$ruleCollectionName,
        [psObject]$firewallRule
  
    )

    try {
        $destinationAddressArray = @($firewallRule.DestinationFqdns -split ',')
        Write-Verbose "Destination Address:$destinationAddressArray" -Verbose
        ForEach ($ipAddress in $destinationAddressArray) {
            if (Test-ValidIp -IpAddress $ipAddress) {
                $validIP = $true
            }
        }

        if ($validIP) {
            $networkRule = New-AzFirewallNetworkRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress -Protocol $firewallRule.Protocol `
                -destinationAddress $firewallRule.DestinationFqdns -DestinationPort $firewallRule.DestinationPort
        }
        else {
            $firewallRule.Name = $firewallRule.Name + '-fqdn'
            $networkRule = New-AzFirewallNetworkRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress -Protocol $firewallRule.Protocol `
                -DestinationFqdn $firewallRule.DestinationFqdns -DestinationPort $firewallRule.DestinationPort
        }
        $collection = New-AzFirewallNetworkRuleCollection -Name $ruleCollectionName -Priority $collectionPriority -Rule $networkRule -ActionType Allow
        $azFireWall.AddNetworkRuleCollection($collection)

        $status = Set-AzFirewall -AzureFirewall $azFireWall
    }
    catch {
        $status = "Error | ( New-NetworkFirewallRuleSet) $_"
    }

    Return $status


}
<#   
# Function New ApplicationFirewallRuleSet
#
#  This function will create a new Application Collection ruleset and then add the new Application rule to the collection. Priority of the collection
#  generated and passed as parameter. 
# 
#  Application Rules can have two type of destination depending on the requirements each destination have a different
#  rule format and parameters. The function will detect the rule type based on the rule input.
#
#  Application Destination
#
#    - TargetFqdn : This destination type expects the destination to be well formed FQDNs,
#    - FqdnTags   : This destination type expects the destination to be Microsoft Service Tags,
#
#  Input:
#    azFireWall                : Firewall metadata object
#    rulecollectonName   : name of the Application ruleset collection to create
#    collection Priority : Network Collection ruleset priority.
#    firewallRule        : Application Rule to create in the form of Hash Table
#
#  Output:
#     Application Rule creation details or Exception/Error 
#>
Function New-ApplicationFirewallRuleSet {
    param(
        [psObject]$azFireWall,
        [string]$ruleCollectionName,
        [int]$collectionPriority,
        [psObject]$firewallRule
  
    )

    try {
        #
        #  Check and select application rule type to create.
        #
        if ($firewallRule.TargetFqdn) {
            $applicationRule = New-AzFirewallApplicationRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress `
                -TargetFqdn  $firewallRule.TargetFqdn -Protocol $firewallRule.Protocol
        }
        else {
            $applicationRule = New-AzFirewallApplicationRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress `
                -FqdnTag $firewallRule.FqdnTags
        }
        $collection = New-AzFirewallApplicationRuleCollection -Name $ruleCollectionName -Priority $collectionPriority -Rule $applicationRule -ActionType Allow
        $azFireWall.AddApplicationRuleCollection($collection)
        $status = Set-AzFirewall -AzureFirewall $azFireWall  

    }
    catch {
        throw $_
    }

    Return $status

}
<#
# Function Add FirewallRuleSet
#  Function to Add a new rule, either application or network rule. the selection type based on the  rulecollectionType parameter passed.
#
#  Input:
#    azFireWall                 : Firewall metadata object
#    ruleCollectionObject : Matched Network rule collection object to update
#    rulecollectionType   : the type of collection Network or application
#    firewallRule         : Rule to to create in the form of Hash Table
#
#  Output:
#    Rulecollection Object or Exception/Error   
#>
Function Add-FirewallRuleSet {
    param(
        [PsObject]$azFireWall,
        [psObject]$ruleCollectionObject,
        [string]$ruleCollectionType,
        [psObject]$firewallRule
  
    )
    switch ($ruleCollectionType) {

        NetworkRuleCollections { $status = Add-NetworkFirewallRuleSet     -azFireWall $azFireWall -ruleCollectionObject $ruleCollectionObject -firewallRule $firewallRule }
        ApplicationRuleCollections { $status = Add-ApplicationFirewallRuleSet -azFireWall $azFireWall -ruleCollectionObject $ruleCollectionObject -firewallRule $firewallRule }
        Default { $status = "Error | Azure Firewall Collection Rule type invalid." }

    }

    Return $status
}
<#   
# Function Add AzureFirewallRuleCollection
#
#  Function to add a new Network rule to an existing Collection set. 
#
#  Input:
#    azFireWall                 : Firewall metadata object
#    ruleCollectionObject : Matched Network rule collection object to update
#    firewallRule         : Network Rule to add in the form of Hash Table
#
#  Output:
#    Network Rule Addition details or Exception/Error 
#>
Function Add-NetworkFirewallRuleSet {
    param(
        [psObject]$azFireWall,
        [PsObject]$ruleCollectionObject,
        [psObject]$firewallRule 
    )

    
    try {
        $destinationAddressArray = @($firewallRule.DestinationFqdns -split ',')
        Write-Verbose "Destination Address:$destinationAddressArray" -Verbose
        ForEach ($ipAddress in $destinationAddressArray) {
            if (Test-ValidIp -IpAddress $ipAddress) {
                $validIP = $true
            }
        }
        try {
            if (-Not $validIP) {
                $firewallRule.Name = $firewallRule.Name + '-fqdn'
            }
            $ruleOverwrite = ($ruleCollectionObject.GetRuleByName($firewallRule.Name))
        }
        catch {}
        if ($validIP) {
            if ($null -ne $ruleOverwrite) {
                $postRule = $ruleCollectionObject.GetRuleByName($firewallRule.Name)
                $postRule.DestinationAddresses = $postRule.DestinationAddresses + $firewallRule.DestinationFqdns
            }
            else {
                $networkRule = New-AzFirewallNetworkRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress -Protocol $firewallRule.Protocol `
                    -destinationAddress $firewallRule.DestinationFqdns -DestinationPort $firewallRule.DestinationPort
            
                $ruleCollectionObject.AddRule($networkRule)
            }
        }
        else {
            if ($null -ne $ruleOverwrite) {
                $postRule = $ruleCollectionObject.GetRuleByName($firewallRule.Name)
                $postRule.DestinationFqdns = $postRule.DestinationFqdns + $firewallRule.DestinationFqdns
            }
            else {
                $networkRule = New-AzFirewallNetworkRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress -Protocol $firewallRule.Protocol `
                    -DestinationFqdn $firewallRule.DestinationFqdns -DestinationPort $firewallRule.DestinationPort
            
                $ruleCollectionObject.AddRule($networkRule)
            }
           
        }

        $status = Set-AzFirewall -AzureFirewall $azFireWall
    }
    catch {
        throw "Error | (Add-NetworkFirewallRuleSet) $_"
        $status = "Error | (Add-NetworkFirewallRuleSet) $_"
    }


    Return $status
}
<#   
# Function Add ApplicationFirewallRuleSet
#
#  Function to add a new Application rule to an existing Collection set. 
#
#  Input:
#    azFireWall                 : Firewall metadata object
#    ruleCollectionObject : Matched Application rule collection object to update
#    firewallRule         : Application Rule to add in the form of Hash Table
#
#  Output:
#    Application Rule Addition details or Exception/Error 
#>
Function Add-ApplicationFirewallRuleSet {
    param(
        [PsObject]$azFireWall,
        [PsObject]$ruleCollectionObject,
        [psObject]$firewallRule  
    )

    try {
        $ruleOverwrite = ($ruleCollectionObject.GetRuleByName($firewallRule.Name))
    }
    catch {}
    try {
        if ($firewallRule.TargetFqdn) {
            if ($null -ne $ruleOverwrite) {
                $postRule = $ruleCollectionObject.GetRuleByName($firewallRule.Name)
                $postRule.TargetFqdns = $postRule.TargetFqdns + $firewallRule.TargetFqdn
            }
            else {
                $applicationRule = New-AzFirewallApplicationRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress `
                    -TargetFqdn  $firewallRule.TargetFqdn -Protocol $firewallRule.Protocol

                $ruleCollectionObject.AddRule($applicationRule)
            }
        }
        else {
            if ($null -ne $ruleOverwrite) {
                $postRule = $ruleCollectionObject.GetRuleByName($firewallRule.Name)
                $postRule.FqdnTags = $postRule.FqdnTags + $firewallRule.FqdnTags
            }
            else {
                $applicationRule = New-AzFirewallApplicationRule -Name $firewallRule.Name -SourceAddress $firewallRule.SourceAddress `
                    -FqdnTag $firewallRule.FqdnTags
                $ruleCollectionObject.AddRule($applicationRule)
            }
        }
    
        $status = Set-AzFirewall -AzureFirewall $azFireWall

    }
    catch {
        $status = "Error | (Add-ApplicationFirewallRuleSet) $_"
    }

    Return $status

}

Function Test-ValidIpAddress {
    param(
        [string]$subscriptionId,
        [string]$sourceIpAddress,
        [string]$region

    )

    # Single IP address pattern.
    $ipPattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
    # Is Destination a vaild IPV4 address
    if (-Not ($sourceIpAddress -match $ipPattern)) {
        Return $false
    }
    # Is Destination IP belongs to requester's Subscription
    Set-AzContext $subscriptionId | Out-Null
    $vNet = Get-AzVirtualNetwork | Where-Object { $_.Location -eq $region.Replace(' ', '') }
    if ( -Not $vNet) {
        Return $false
    }
    try {
        $addressPrefixes = @($vnet.AddressSpace.AddressPrefixes  ) | Sort-Object
   
        foreach ($addressPrefix in $addressPrefixes) {
            $addressPrefixRange = Get-SubnetRange -ipAddress $addressPrefix.ToString()
            Write-Verbose "SourceIPAddress:$sourceIpAddress" -Verbose
            Write-Verbose "AddressPrefixRange:$addressPrefixRange" -Verbose
            if ( $sourceIpAddress -in $addressPrefixRange) {
                Write-Verbose "Valid IP in Subscription" -Verbose
                $validHost = $true
                break
            }
            else {
                Write-Verbose "Invalid IP, not part of subscription" -Verbose
                $validHost = $false
            }
        }
    }
    catch {
        Write-Verbose "Exception" -Verbose
        Return $false
    }

    Return $validHost
}
<#

#>
Function Test-destinationPorts {
    param(
        [string[]]$destinationPorts,
        [string[]]$appServicePorts
    )

    foreach ($serviceport in $destinationPorts) {
        if ( $servicePort -notin $appServicePorts) {
            Return $false
        }

    }
    Return $true
}
<#
# Function Add TableStorage
#  Function to add a new Table in Storage Account if it does not exist
#
#  Input:
#    storageAccountSubscriptionId  : SubscriptionId where the storage account exists
#    storageAccountName            : Storage account name where table has to be created
#    storageAccountResourceGroup   : Resource Group where storage account is deployed
#    tableName                     : Table name to be created
#
#  Output:
#    Warning if table already exists
#>
Function Add-TableStorage {
    param(
        [Parameter(Mandatory = $true)] [string] $storageAccountSubscriptionId,
        [Parameter(Mandatory = $true)] [string] $storageAccountName,
        [Parameter(Mandatory = $true)] [string] $storageAccountResourceGroup,
        [Parameter(Mandatory = $true)] [string] $tableName
    )
    try {
        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        Get-AzStorageTable -Name $tableName -Context $ctx -ErrorAction SilentlyContinue -ErrorVariable err
        if ($err[0] -match "Can not find table") {
            Write-Verbose "Creating new table" -Verbose
            New-AzStorageTable –Name $tableName –Context $ctx -Verbose    
        }
        else {
            Write-Warning "Table with name $tableName already exists" -Verbose
        }

    }
    catch {
        throw $_
    }
}
<#
# Function Update Ingress/Egress Table
# Function to update ingress egress rules table. Skips updates if row already exists
#
#  Input:
#    storageAccountSubscriptionId  : SubscriptionId where the storage account exists
#    storageAccountName            : Storage account name where table has to be created
#    storageAccountResourceGroup   : Resource Group where storage account is deployed
#    tableName                     : Table name to be created
#    subscription                  : Subscription Name whose IP Ranges have to be allowed (Can be * for All Subs)
#    sourceIpAddress               : Source IP address requesting  Egress Access
#    destinationAddresses          : Destination list of FQDNs or Network IPs (Comma separated)
#    protocol                      : Protocol requirement for outbound Access TCP/UDP
#    port                          : Comma Separated Destination Ports required to be opened
#    action                        : allow/deny
#    ruleType                      : ingress/egress
#  Output:
#    Returns updated rows and existing rows in table for the specfic subscription or rule for all subs(*) 
#>
Function Update-IngressEgressTable {
    param(
        [Parameter(Mandatory = $true)] [string] $storageAccountSubscriptionId,
        [Parameter(Mandatory = $true)] [string] $storageAccountName,
        [Parameter(Mandatory = $true)] [string] $storageAccountResourceGroup,
        [Parameter(Mandatory = $true)] [string] $tableName,
        [Parameter(Mandatory = $true)] [string] $subscription,
        [Parameter(Mandatory = $true)] [string] $sourceIpAddress,
        [Parameter(Mandatory = $true)] [string] $destinationAddresses,
        [Parameter(Mandatory = $true)] [string] $protocol,
        [Parameter(Mandatory = $true)] [string] $port,
        [Parameter(Mandatory = $true)] [string] $action,
        [Parameter(Mandatory = $true)] [string] $ruleType
    )
    try {

        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        # $dateTime = Get-date -f MM-dd-yyyy_HH_mm_ss
        $cloudTable = (Get-AzStorageTable –Name $tableName –Context $ctx).CloudTable
        if ($subscription -eq "*") {

            $subscriptionId = "*"
        }
        else {
            $subscriptionId = (Get-AzSubscription -SubscriptionName $subscription).Id
            
        }

        if ("egress" -eq $ruleType) {
            $exists = Get-AzTableRow -Table $cloudTable -ColumnName "Destination" -Value "$destinationAddresses" -Operator Equal
        }
        else {
            $exists = Get-AzTableRow -Table $cloudTable -ColumnName "Source" -Value "$sourceIpAddress" -Operator Equal
        }

        if ($null -eq $exists) {

            if ("egress" -eq $ruleType) {            
                Write-Verbose "Updating Table and adding $destinationAddresses" -Verbose
                ## The Scope column is either the Subscription ID or *
                $update = Add-AzTableRow `
                    -table $cloudTable `
                    -partitionKey $ruleType `
                    -rowKey ("$destinationAddresses") -property @{"Source" = "$sourceIpAddress"; "Destination" = "$destinationAddresses"; "Port" = "$port"; "Protocol" = "$protocol"; "Subscription" = "$subscription"; "Scope" = "$subscriptionId"; "Action" = "$action" }
            }
            else {
                Write-Verbose "Updating Table and adding $sourceIpAddress" -Verbose
                ## The Scope column is either the Subscription ID or *
                $sourceIpAddress2 = $sourceIpAddress.replace('/', '_')
                $update = Add-AzTableRow `
                    -table $cloudTable `
                    -partitionKey $ruleType `
                    -rowKey ("$sourceIpAddress2") -property @{"Source" = "$sourceIpAddress"; "Destination" = "$destinationAddresses"; "Port" = "$port"; "Protocol" = "$protocol"; "Subscription" = "$subscription"; "Scope" = "$subscriptionId"; "Action" = "$action" }                    
            }

            if ($update) {
                Write-Verbose "Table update successful" -Verbose
            }
            else {
                Write-Verbose "Table update not successful" -Verbose
            }
            
        }
        else {
            Write-Verbose "Entry for {source: $sourceIpAddress, destination: $destinationAddresses} already exists. Skipping Table update" -Verbose
        }

    }
    catch {
        throw $_
    }
    Return $result
}

<#
# Function Get Office365EndPointURL
#  Function get latest O365 endpoints
#
#  Input:
#    NA
#  Output:
#    List of Service Required URL's to be allowed for Office 365
#>

Function Get-Office365EndPointURL {

    try {
        $guid = New-Guid
        #Get the latest endpoints information from Microsoft

        Write-Verbose "Getting latest Office365 Endpoints" -Verbose
        $office365IPs = Invoke-WebRequest -Uri "https://endpoints.office.com/endpoints/worldwide?clientrequestid=$guid" | ConvertFrom-Json
        #Capture required Fqdns and ports  
        $serviceAreaUrls = $office365IPs | Where-Object { $_.required -eq "True" -and ($_.tcpPorts -ilike "*80*" -or $_.tcpPorts -ilike "*443*") } | Sort-Object | Select-Object -Unique -Property urls, tcpPorts, id       

    }
    catch {
        throw $_
    }
    Return $serviceAreaUrls
}

<#   
Function Test-ValidIp
#
#  This function tests if the input is a valid IP V4 address
#
#  Input:
#    IpAddress  : Ip Address 
#
#  Output:
#    True/False
#>

Function Test-ValidIp {
    param(
        [string]$IpAddress
    )

    # Single IP address pattern.
    $ipPattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
    # Is Destination a vaild IPV4 address
    if (-Not ($IpAddress -match $ipPattern)) {
        Return $false
    }
    else {
        Return $true
    } 
}


<#
# Function Get VNET Update Status
#  Function to Get the update status of Virtual Network and it's Subnets
#
#  Input:
#    resourceGroupName  : resourceGroupName where the VNet exists
#    virtualNetworkName            : virtualNetworkName name
#
#  Output:
#    Warning true if the Vnet & Subnets are not going under any updates or else return false
#>
Function Get-VNETUpdateStatus {
    param (
        [string]$resourceGroupName,
        [string]$virtualNetworkName
    )
try
{
    # Get the VNet
    $vnet = Get-AzVirtualNetwork -ResourceGroupName $resourceGroupName -Name $virtualNetworkName

    # Check the provisioning state of the VNet
    if ($vnet.ProvisioningState -ne 'Succeeded') {
        Write-Output "The VNet '$virtualNetworkName' is currently in state: $($vnet.ProvisioningState). Cannot proceed with the update."
        return $false
    }

    # Check the provisioning state of each subnet
    foreach ($subnet in $vnet.Subnets) {
        if ($subnet.ProvisioningState -ne 'Succeeded') {
            Write-Output "The subnet '$($subnet.Name)' in VNet '$virtualNetworkName' is currently in state: $($subnet.ProvisioningState). Cannot proceed with the update."
            return $false
        }
    }

    # If both the VNet and all subnets are in a stable state
    Write-Output "The VNet '$virtualNetworkName' and its subnets are in a stable state. You can proceed with the update."
}

    catch {
        throw $_
    }
    return $true
}
