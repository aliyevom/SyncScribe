<#
.SYNOPSIS
Update the Spoke VNET DNS IP Address to specified addresses
Update Spoke NSGs with new DNS IP address

.DESCRIPTION
Update the Spoke VNET DNS IP Address to specified addresses. The script updates the existing DNS Servers to NULL before applying the new list of DNS Servers

#>
function Update-SpokeDNSIPs {
    param (
        
    )
        
    $vnets = Get-AzVirtualNetwork 
    foreach ($vnet in $vnets) {
        try {
            Write-Output "Updating Virtual Network $($vnet.Name)" -Verbose
            # Sets the existing DNS servers to NULL before applying the new list of DNS servers   
            $vnet.DhcpOptions.DnsServers = $null
               
            $vnet.DhcpOptions.DnsServers = $dnsIPs[$($vnet.Location)]
                
            Set-AzVirtualNetwork -VirtualNetwork $vnet
        }
            
        Catch {
            Write-Error "DNS Update for '$($vnet.Name)' Failed." -Verbose
        }
    }
    
    
}
function Update-Nsgs {
    param (
        
    )
    $nsgs = Get-AzNetworkSecurityGroup
    foreach ($nsg in $nsgs) {
        try {
            Write-Output "Updating Virtual Network Security Group $($nsg.Name)" -Verbose
            $nsgDnsRules = ($nsg | Get-AzNetworkSecurityRuleConfig).where( { $_.destinationPortRange -contains "53" -and $_.Protocol -eq 'UDP'} )
            $dnsIP = $dnsIPs[$($nsg.Location)]
            foreach ($dnsRule in $nsgDnsRules) {
                try {
                    if ($dnsRule.Direction -eq 'Inbound') {
                
                        Set-AzNetworkSecurityRuleConfig -NetworkSecurityGroup $nsg `
                            -Name $dnsRule.Name `
                            -Access $dnsRule.Access `
                            -Protocol $dnsRule.Protocol `
                            -Direction $dnsRule.Direction `
                            -Priority $dnsRule.Priority `
                            -SourceAddressPrefix  $dnsIP `
                            -SourcePortRange $dnsRule.SourcePortRange `
                            -DestinationAddressPrefix $dnsRule.DestinationAddressPrefix `
                            -DestinationPortRange $dnsRule.DestinationPortRange `
                            -Description $dnsRule.Description
                    }
                    else {
                    
                        Set-AzNetworkSecurityRuleConfig -NetworkSecurityGroup $nsg `
                            -Name $dnsRule.Name `
                            -Access $dnsRule.Access `
                            -Protocol $dnsRule.Protocol `
                            -Direction $dnsRule.Direction `
                            -Priority $dnsRule.Priority `
                            -SourceAddressPrefix  $dnsRule.SourceAddressPrefix `
                            -SourcePortRange $dnsRule.SourcePortRange `
                            -DestinationAddressPrefix $dnsIP `
                            -DestinationPortRange $dnsRule.DestinationPortRange `
                            -Description $dnsRule.Description
                    }
                }
                catch {
                    Write-Error "Nsg $($nsg.Name) rule $($dnsRule.Name) failed to update DNS IP prefix" -Verbose
                }            
            }
            $nsg | Set-AzNetworkSecurityGroup
        }
        catch {
            Write-Error "Nsg $($nsg.Name) failed to update DNS IP prefix, Configuration Error" -Verbose
        }
    }
}

#  
#  Start main DNS update
#
$dnsIPs = @{
    eastus2   = @("10.82.2.100", "10.82.194.68", "10.127.0.5", "10.105.64.69", "10.105.64.213")
    centralus = @("10.82.194.68", "10.82.2.100", "10.127.0.5", "10.105.64.69", "10.105.64.213")
    uksouth   = @("10.83.2.68", "10.83.194.68", "10.127.0.1", "10.105.64.197", "10.105.64.85")
    ukwest    = @("10.83.194.68", "10.83.2.68", "10.127.0.1", "10.105.64.197", "10.105.64.85")
}
$subscriptions = get-content -path C:\temp\subscriptions.txt
foreach ($ubscription in $subscriptions) {
    try {
        Write-Output "Updating Subscription $($ubscription)"
        Set-AzContext -Subscription $ubscription
        Update-SpokeDNSIPs
        Update-Nsgs
    }
    catch {
        Write-Error "DNS Update failed.`n$_" -Verbose
    }
}