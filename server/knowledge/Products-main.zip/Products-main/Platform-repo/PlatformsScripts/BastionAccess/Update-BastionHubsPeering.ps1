Function Add-PeeringSpokeToBastionHub {


    Param(
        [string]$localSubscriptionId ,
        [String]$bastionSubscriptionId 

    )

    $templateFilePath = "Modules/VirtualNetworkPeering/deploy.json"
    $parameterFilePath = "LandingZone/SpokeNetwork/Parameters/VirtualnetworkPeering/parameters.spokeToHub.json"
    try {
        # Change Context to Local Subscription
        Set-AzContext -Subscription $localSubscriptionId
        $vNetIds = (Get-AzVirtualNetwork | Where-Object { $_.ResourceGroupName -like '*-spokenetwork-rg' })
        foreach ($localNetwork in $vNetIds) {
            Set-AzContext -Subscription $bastionSubscriptionId
            #
            # Local Spoke and remote Bastion network
            #
            $basvNetId = Get-AzVirtualNetwork | Where-Object { $_.Location -eq $localNetwork.Location -and $_.Name -like '*-vnet-02' }
            $remotevNetId = $basvNetId.Id
            $localNetworkName = $localNetwork.Name
            $localNetworkResourceGroupName = $localNetwork.ResourceGroupName
            $remoteNetworkName = $basvNetId.Name
            $peeringName = "$localNetworkName-to-$remoteNetworkName-peer"

            Write-Verbose "Processing Virtual network '$($localNetworkName)' Peering '$($peeringName)'" -verbose  
    

            $peeringConnection = @{ 
                Name                   = "BastionPeering-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
                TemplateFile           = $templateFilePath
                TemplateParameterFile  = $parameterFilePath
                localVnetName          = $localNetworkName
                remoteVirtualNetworkId = $remotevNetId
                useRemoteGateways      = if ($remoteNetworkName -like '*-vnet-01') { $true }else { $false }
                peeringName            = $peeringName
                Verbose                = $true
                ErrorAction            = 'Stop' 
            }
            $peeringConnection
            Set-AzContext -Subscription $localSubscriptionId
            New-AzResourceGroupDeployment @peeringConnection -ResourceGroupName $localNetworkResourceGroupName
            #
            #  retrun path from Bastion to Spoke
            # local bation Network and remote Spoke
            #
            $remotevNetId = $localNetwork   # this is the vNet object of Spoke network in current context.
            $localNetwork = $basvNetId
            $remoteNetworkId = $remotevNetId.Id
            $remoteNetworkName = $remotevNetId.Name
            $localNetworkName = $localNetwork.Name
            $remoteNetworkResourceGroupName = $localNetwork.ResourceGroupName
               
            $peeringName = "$localNetworkName-to-$remoteNetworkName-peer"
            Write-Verbose "Processing Remote network '$($remoteNetworkName)' Peering '$($peeringName)'" -verbose 
            Set-AzContext -Subscription $bastionSubscriptionId

            $peeringConnection = @{ 
                Name                   = "bashubPeering-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
                TemplateFile           = $templateFilePath
                TemplateParameterFile  = $parameterFilePath
                localVnetName          = $localNetworkName
                remoteVirtualNetworkId = $remoteNetworkId
                useRemoteGateways      = $false
                allowGatewayTransit    = if ($localNetworkName -like '*-vnet-01') { $true }else { $false }
                peeringName            = $peeringName
                Verbose                = $true
                ErrorAction            = 'Stop' 
            }
            $peeringConnection

            New-AzResourceGroupDeployment @peeringConnection -ResourceGroupName $remoteNetworkResourceGroupName                       
            Write-Verbose "Virtual Network '$($vNetId.Name)' Peering Connection with '$($remoteNetworkName)' completed" -verbose
        }
    }
    catch {
        Throw $_
    }
}



$spokeSubscriptions = Get-Content -Path c:\temp\subscriptions.txt

foreach ($subscription in $spokeSubscriptions) {
    if ($subscription -like 'US*'){
        $bastionSubscriptionName = 'US-HUB-PROD-01'

    }else {
        $bastionSubscriptionName = 'UK-HUB-PROD-01'
    }
    
    Write-Verbose "$bastionSubscriptionName $subscription" -Verbose
    Add-PeeringSpokeToBastionHub -localSubscriptionId $subscription -bastionSubscriptionId $bastionSubscriptionName -verbose
}