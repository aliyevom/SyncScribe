
#inb-bastion-tcp-22-3389-2009-allow" 

Function Update-NetworkSecurityGroupRule {
    param(
        [PSCustomObject]$nsgObj,
        [Array]$newBastionSubnets
    )
    try {
        $nsgRule = $nsgObj.SecurityRules.where( { $_.Name -like "inb-bastion-tcp-*-allow" -or ($_.DestinationPortRange -contains '3389' -and $_.DestinationPortRange -contains '22' -and $_.Direction -eq 'Inbound') })
        if ( -Not ([string]::IsNullOrEmpty($nsgRule) )) {
           
                $nsgRuleUpdate = @{
                
                    Name                     = $nsgrule.Name
                    Description              = $nsgRule.description
                    Protocol                 = $nsgRule.Protocol
                    DestinationPortRange     = $nsgRule.DestinationPortRange
                    SourcePortRange          = "*"
                    SourceAddressPrefix      = $newBastionSubnets 
                    DestinationAddressPrefix = $nsgRule.DestinationAddressPrefix
                    Access                   = $nsgRule.Access
                    Priority                 = $nsgRule.Priority
                    Direction                = $nsgRule.Direction
                    NetworkSecurityGroup     = $nsgobj
                }

                Set-AzNetworkSecurityRuleConfig @nsgRuleUpdate | Set-AzNetworkSecurityGroup
                Write-verbose "Network Security Gorup $($nsgobj.Name)' bastion subnet Rule updated " -Verbose

        }
        else {
            Write-verbose "Network Security Gorup '$($nsgobj.Name)' does not have a bastion Allow rule " -Verbose
        }
    }
    catch {
        Write-Verbose "Exception $($nsgobj.Name)'`n$_" -Verbose
    }

}

$bastionSubnets = @{
    UK = @("10.83.163.128/26", "10.83.101.64/26")
    US = @("10.82.163.64/26", "10.82.102.128/26")
}

$subscriptions = get-content -path C:\temp\subscriptions.txt
foreach ($subscription in $subscriptions) {
    

    try {
        Set-AzContext -Subscription $subscription
        $country = $subscription.Substring(0, 2)
        $nsgs = (Get-AzNetworkSecurityGroup).Where( { $_.ResourceGroupName -like '*-spokenetwork-rg' -or $_.ResourceGroupName -like '*-hubnetwork-rg' })
    
        foreach ($nsg in $nsgs) {
            Update-NetworkSecurityGroupRule -nsgObj $nsg -newBastionSubnets $bastionSubnets[$country]
        
        }
    }
    Catch {
        Write-Verbose "subscription '$($subscriptionName)' processing NSG '$($nsg.Namr)'Failed."
    }
}