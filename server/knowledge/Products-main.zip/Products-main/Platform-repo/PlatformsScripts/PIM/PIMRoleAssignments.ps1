<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$subscriptionName,
    [string]$ownerEmailAddress,
    [string]$region,
    [string]$startDate,
    [int]$days
)


$ErrorActionPreference = 'Stop'

$UpperSubscriptionName = $subscriptionName.ToUpper()

Write-Verbose "Starting PIM Role Assignment" -Verbose

try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose

    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable
    
    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString

    ## Azure Resource PIM Example

    Set-AzContext -Subscription $UpperSubscriptionName
    
    Write-Verbose "Print ownersEmailAddres variable" -Verbose
    $ownerEmailAddress

    $owners_value = $ownerEmailAddress
    $owners = $owners_value.split(",")

    
    foreach ($owner in $owners) {
        $owner = $owner.Trim()
        $owner


        if ($owner -like "*us.nationalgrid.com") {
            $userPrincipal = $owner
        }
        elseif ($owner -like "*uk.nationalgrid.com") {
            $userPrincipal = $owner
        }
        elseif (Get-EntraUser -Filter "mail eq '$owner'")
        {
            $upn = Get-EntraUser -Filter "mail eq '$owner'"
            $userPrincipal = $upn.UserPrincipalName
            $principalID = $upn.ObjectId
            $principalType = "Entra User"
        }
        elseif (Get-EntraUser -Filter "userprincipalname eq '$owner'") {
            $upn = Get-EntraUser -Filter "userprincipalname eq '$owner'"
            $userPrincipal = $upn.UserPrincipalName
            $principalID = $upn.ObjectId
            $principalType = "Entra User"
        }
        elseif (Get-EntraGroup -Filter "DisplayName eq '$owner'")
        {
            $upn = Get-EntraGroup -Filter "DisplayName eq '$owner'"
            $principalID = $upn.ObjectId
            $principalType = "Entra Group"
        }
        elseif (Get-AzADServicePrincipal -DisplayName $owner)
        {
            $upn = Get-AzADServicePrincipal -DisplayName $owner
            $principalID = $upn.Id
            $principalType = "Entra Service Principal Name"
        }
        else {
            Write-Warning "Invalid User Principal"
        }
        
        Write-Verbose "User Princial  is $userPrincipal $principalID"  -Verbose
        Write-Verbose "Princial type is $principalType" -Verbose
   
        $subscriptionID = (get-azsubscription -SubscriptionName $UpperSubscriptionName).SubscriptionId

        Write-Verbose "Subscription is $subscriptionID" -Verbose

        $roleDefinitionID = "b24988ac-6180-42a0-ab88-20f7382dd24c" #Built-in Contributor Role Definition ID example
        #$targetuserID = (Get-EntraUser -ObjectId $userPrincipal).ObjectId  # Replace user ID
 
        Write-Verbose "Starting PIM PowerShell Process" -Verbose
        #Write-Verbose "Target ID is $principalID" -Verbose

        $reason = "Utilizing PIM Pipeline for Time-Gated Access"

        if ($days -gt 30) {
            Write-Warning "Days can only be set to 30 days at the maximum. Setting to 30 days instead of $days"
            $days = 30
        }

        Write-Verbose "New Privileged Role Assignment Request" -Verbose

        $endDate = ((Get-Date).AddDays($days)).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    
        Write-Output "The end date is" $endDate

        #Guid is needed for ID of the PIM request
        $guid = (New-Guid).Guid
        $startTime = Get-Date -Date $startDate -Format o
        $scope = "/subscriptions/$subscriptionID"
    
        # Create temporary active role assignment
            try {
                New-AzRoleAssignmentScheduleRequest -Name $guid -Scope $scope -ExpirationEndDateTime $endDate -ExpirationType AfterDateTime -PrincipalId $principalID -RequestType AdminAssign -RoleDefinitionId subscriptions/$subscriptionID/providers/Microsoft.Authorization/roleDefinitions/$roleDefinitionID -ScheduleInfoStartDateTime $startTime -Justification $reason
            }
            catch {
                if ( $_.exception | Select-String "The Role assignment already exists") {
                    Write-Warning  "Duplicate role assignment detected. <$principalID> is already assigned at scope $scope"
                }
                else {
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
                    throw  $_
                } 
            }
    }
}
catch {
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
    throw  $_
}

