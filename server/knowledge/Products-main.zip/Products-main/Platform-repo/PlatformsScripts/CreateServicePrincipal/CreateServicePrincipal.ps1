<#
.SYNOPSIS
Create developer's provisioning SPN 

.DESCRIPTION
Create developer's provisioning SPN.
The Created SPN will be scoped at specified subscription or Management group based on input. The SpN application Id and Randomly generated 
Password will be stored in CCoE designated Keyvault.

SPN password expiration date can be set by the pipeline and currently set to 3 years

.PARAMETER scopeId
Mandatory. Management/subscription Id role assignment scope selectable at runtime.

.PARAMETER spnName
Mandatory. The SPN display Name.

.PARAMETER builtInRole
Mandatory. The role assignment to grant SPN at specified scope.

.PARAMETER expiresInYears
Mandatory. Number of years before SPN password expires.

.PARAMETER keyvaultName
Mandatory. CCoE Keyvault Name to store SPN ID and Password.

.PARAMETER scopeSubscription
Mandatory. if set, the scope of the SPN Role at subscription level.

.EXAMPLE
$scopeId = "mgId"
$servicePrincipal = Create-ServicePrincipal -scopeId $scopeId -spnName $spnName -builtInRole 'contributor' -expiresInYears 3 -keyvaultName "kvmName" 

//Scope at subscription

$scopeId = "sub Name"
$servicePrincipal = Create-ServicePrincipal -scopeId $scopeId -spnName $spnName -builtInRole 'contributor' -ScopeSubscription -expiresInYears 3 -keyvaultName "kvmName"
#>

[CmdletBinding(SupportsShouldProcess)]
Param(
[string]$scopeId ,
[string]$spnName,
[string]$builtInRole ,
[int32] $expiresInYears,
[string]$keyvaultName,
[switch]$ScopeSubscription
)
$ErrorActionPreference = 'Stop'
try{
    if ($ScopeSubscription){
        $ScopeSubscriptionId = (get-azsubscription -SubscriptionName $scopeId).SubscriptionId
        $scope = "/subscriptions/$ScopeSubscriptionId"
        
    }
    else{
        $scope = "/providers/Microsoft.Management/managementGroups/$scopeId"
    }
    $servicePrincipal = Get-AzADServicePrincipal -DisplayName $spnName -ErrorAction SilentlyContinue
    if(-Not $servicePrincipal){

        #These commands were changed as of 3/2/2022 to utilize the new 7.1.0 PS Commands. Prior to this, we used 6.3.0 commands.
        $startDate = Get-Date
        $endDate = $startDate.AddYears(2)
        $app = New-AzADServicePrincipal -DisplayName $spnName
        Write-Host "Print AzADServicePrincipal"
        $app
        
        $Credentials = New-AzADServicePrincipalCredential -ObjectId $app.id -StartDate $startDate -EndDate $endDate
        
        Start-Sleep -Seconds 60 
        write-Host  "Developer's provisioning SPN <$spnName> Created"
        $servicePrincipalApplicationId = $app.AppId

        $secretValue = ConvertTo-SecureString -String $Credentials.SecretText -AsPlainText -Force
        Set-AzKeyVaultSecret -VaultName $keyvaultName -Name $($spnName+"-Password") -SecretValue $SecretValue

        $secretValue = ConvertTo-SecureString -String $servicePrincipalApplicationId -AsPlainText -Force
        Set-AzKeyVaultSecret -VaultName $keyvaultName -Name $($spnName+"-appId") -SecretValue $SecretValue
        
        $servicePrincipal = $app
    }
    else{
        Write-Warning "Developer's provisioning SPN <$spnName> already exists in Azure Active Directory"
    }

    $servicePrincipalApplicationId = $servicePrincipal.AppId
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'servicePrincipalApplicationId', $servicePrincipalApplicationId)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'servicePrincipalApplicationId;issecret=false;isOutput=true', $servicePrincipalApplicationId)

    $servicePrincipalObjectId = $servicePrincipal.Id
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'servicePrincipalObjectId', $servicePrincipalObjectId)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'servicePrincipalObjectId;issecret=false;isOutput=true', $servicePrincipalObjectId)    

    New-AzRoleAssignment -ObjectId $servicePrincipal.Id -RoleDefinitionName $builtInRole -Scope $scope

}
catch{
    if($_.Exception | Select-String "Operation returned an invalid status code 'Conflict'"){
        Write-Warning "Duplicate role assignment <$builtInRole> for <$spnName> already exist at scope $scope"
    }
    else{
        throw $_
    }
    
}
