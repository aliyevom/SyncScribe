Function Send-Mail {
    param(
        [string[]] $to,
        [string] $from,
        [string] $emailSubject,
        [string] $smtpServer,
        [int32]  $portnumber,
        [string] $startDate,
        [string] $endDate,
        [string] $geo,
        [string] $Environment,
        [string] $Communication
    )

    try {
        Write-Verbose "Sending Mail.." -Verbose 
        $emailPattern =   '^[^@\s]+@[^@\s]+\.[^@\s]+$'
        $toEmailAddresses = @()
   
        foreach($emailAddress in $to.Split(',')){
       
           if($emailAddress -match $emailPattern){
               $toEmailAddresses += $emailAddress
           }
        }


        $emailbody1 = @"

        <!DOCTYPE html><html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="x-apple-disable-message-reformatting"><title></title><style>table, td, div, h1, p {font-family: Arial, sans-serif;}</style></head>
<body style="margin:0;padding:0;"><table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;"><tr> </tr><tr><td align="center" style="padding:0 0 5px 0;background:#70bbd9;"><img src="cid:header.jpg" alt="" width="602" style="height:auto;display:block;" /></td></tr><tr><td style="padding:36px 30px 42px 30px;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;"><tr><td style="padding:0 0 36px 0;color:#153643;">
                <h1 style="font-size:24px;margin:0 0 0px 0;font-family:Arial,sans-serif;">
"@

    $emailbody2 = " Azure 2.0 Maintenance Notification: " + $Communication
    $emailbody3 = @"
    </h1><p style="font-size:14px;margin:0 0 20px 0;font-family:Arial,sans-serif;">
                <span style="color:#626cf5" ><b>Region: </b></span>
"@
    $emailbody4= $geo
    $emailbody5=@"
                <span style="color:#626cf5" ><b> >Environment: </b></span>
"@

   $emailbody6 = $Environment
   $emailbody7 =@"
                <span style="color:#fccf07" ><b> >Resource: </b></span> 
"@
   $emailbody8 ="Virtual Machine"
   $emailbody9 =@"
                </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#626cf5" ><b>Dear Valued Users,</b></span> 
                </br>
"@

   $emailbody10 ="The CCoE Platform Team has scheduled automated updates on all Azure 2.0 "
   $emailbody11="<b>"
   $emailbody12="Servers"
   $emailbody13= "</b><u> in "
   $emailbody14=$geo +" "+$Environment + " Environment"
   $emailbody15=@"
                 </u></p>
            </br><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#11d379" >
            <b>Start Time: </b> </span>
"@
   $emailbody16=$startDate
   $emailbody17=@"
              </P><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#11d379" >
                <b>End Time: </b></span>
"@
   $emailbody18= $endDate
   $emailbody19= @" 
                </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
   $emailbody20="We do not expect any impact on the Virtual Machines (VMs). <b>VMs will require a reboot by DevOps owners in order to successfully complete the updates.</b> It is recommended to do this as soon as possible."
   $emailbody21 =@"
   </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
   $emailbody22="Please refer below execution plan and process for more details"

   $emailbody23=@"
   </p><p style="margin:0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"><a href="
"@
   $emailbody24 ="http://www.example.com"
   $emailbody25=@"
   " style="color:s#ee4c50;text-decoration:underline;">
"@

   $emailbody26 ="Patch Management User Guide"
   $emailbody27 =@"
   </a></p>
            </br><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">The CCoE Team is available to answer any questions you may have. </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Thank you in advance for your cooperation. </p></td></tr></table></td></tr> <tr><td style="padding:30px;background:#e99415;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;"><tr><td style="padding:0;width:50%;" align="left"><p style="margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;"><a href="http://www.example.com" style="color:#ffffff;text-decoration:underline;">Subscribe</a>
                </p></td><td style="padding:0;width:50%;" align="right"><p style="margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;"><a href="mailto:box.cloudcoe@nationalgrid.com?subject=Update%20Management%20query" style="color:#ffffff;text-decoration:underline;">Contact CCOE Team</a></p></td></tr></table></td></tr></table></body></html>
"@

$emailbody =$emailbody1 +$emailbody2 +$emailbody3 +$emailbody4 +$emailbody5 +$emailbody6 +$emailbody7 +$emailbody8 +$emailbody9 +$emailbody10 +$emailbody11 +$emailbody12 +$emailbody13 +$emailbody14 +$emailbody15 +$emailbody16 +$emailbody17 +$emailbody18 +$emailbody19 +$emailbody20 +$emailbody21 +$emailbody22 +$emailbody23 +$emailbody24 +$emailbody25 +$emailbody26 +$emailbody27



        $mailBody = @{
            To         = $toEmailAddresses
            From       = $from 
            Subject    = $emailSubject
            Body       = $emailbody
            smtpServer = $smtpServer
            Port       = $portnumber
            BodyAsHtml = $true
            Attachment = ".\PlatformsScripts\UpdateManagement\Images\header.jpg"
        }
        Send-MailMessage @mailBody -Verbose
        Write-Verbose "Email sent with subject:$emailSubject" -Verbose
    }
    catch {
        Write-Warning -Message "Failed to send Mail`n$_" -Verbose
    }
}
