<#connect-azaccount
.SYNOPSIS
A function that schedule Update

.DESCRIPTION
This function create schedule for update Management


.EXAMPLE
CreateSchedule @functionInput -Verbose 

#>


function CreateSchedule {

  param (
 
      [parameter(Mandatory = $true)]
      [string] $SubscriptionName,

      [parameter(Mandatory = $false)]
      [string[]] $VMList,

      [parameter(Mandatory = $true)]
      [string] $Geo,

      [parameter(Mandatory = $true)]
      [string] $VMTypes ,

      [parameter(Mandatory = $true)]
      [string] $ScheduleDate ,

      [parameter(Mandatory = $true)]
      [string] $StartTime ,

      [parameter(Mandatory = $true)]
      [string]$ADTOwner ,

      [parameter(Mandatory = $true)]
      [string]$Timezone ,

      [parameter(Mandatory = $true)]
      [string]$smtpServer ,

      [parameter(Mandatory = $true)]
      [string]$portNumber ,

      [parameter(Mandatory = $true)]
      [string]$emailFrom
  )
  $ScheduleDate=$ScheduleDate
  $StartTime=$StartTime
  $ADTOwner=$ADTOwner
  $emailFrom=$emailFrom
  $portNumber=$portNumber
  $smtpServer=$smtpServer
  $Timezone=$Timezone
  $VMTypes=$VMTypes
  $Geo=$Geo
  $SubscriptionName =$SubscriptionName
  $VMList=$VMList

  try { 
    #$Duration="6"
    $aaccountrg ="ng-pd-eus2-centralcompmgmt-rg"
    $aaccount ="ng-pd-eus2-compmgmt-02"
    $umTag = @{"UpdateManagement"= @("True")}
    $processedSubs = @()
    $processedVMs = @()
    [System.Collections.ArrayList]$SubsAzureQueries=@()
    [System.Collections.ArrayList]$VMsAzureQueriesL=@()
    [System.Collections.ArrayList]$VMsAzureQueriesW=@()
    $EmailAddresses=@()
    $EmailAddresses +='arvind.mahto@nationalgrid.com'

    Set-AzContext -SubscriptionName "US-HUB-PROD-01"
    Write-Verbose "Getting Hyrid worker list"
    $HWGHealth= Get-AzAutomationHybridWorkerGroup -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount

###################################################################
# Defining the scope of Update Management by adding Subscription Resources
###################################################################
  $Checksub= Get-AzSubscription -SubscriptionName $SubscriptionName
if (!$Checksub) {
  Write-Verbose "No subscription named '$($SubscriptionName) was found'"
  $subsOwner='NA'
  $Scoped='No'
  $Details='Subscription not found/enabled'
  $subsObject = New-Object -TypeName PSObject
  $subsObject | Add-Member -Name 'SubscriptionName' -MemberType Noteproperty -Value $SubscriptionName -Force -PassThru
  $subsObject | Add-Member -Name 'SubscriptionOwner' -MemberType Noteproperty -Value 'NA' -Force -PassThru
  $subsObject | Add-Member -Name 'Scoped' -MemberType Noteproperty -Value $Scoped -Force -PassThru
  $subsObject | Add-Member -Name 'Details' -MemberType Noteproperty -Value $Details -Force -PassThru
  $processedSubs += $subsObject
}
else{
  Write-Verbose "Subscription  '$($SubscriptionName)  found'"
  $SubID=$Checksub.Id
  $SubResourceID="/subscriptions/"+$SubID
  $SubsAzureQueries.Add($SubResourceID)
  $tags = Get-AzTag -ResourceId $SubResourceID

  foreach($tagKey in $tags.Properties.TagsProperty.Keys) {
      $tagValue = $tags.Properties.TagsProperty[$tagKey]
      Write-Host "$($tagKey):$($tagValue)"
      If ($tagKey -eq "owner name")
      {
      $tagValue
      $subsOwner=$tagValue
      $tempemail1 =$tagValue
      if ($EmailAddresses -notcontains $tempemail1)
      {
      $EmailAddresses += $tempemail1
      }
      }
      }
      $Scoped='Yes'
      $Details='Review selected VMs in VM Assessment Section'
      $subsObject = New-Object -TypeName PSObject
      $subsObject | Add-Member -Name 'SubscriptionName' -MemberType Noteproperty -Value $SubscriptionName -Force -PassThru
      $subsObject | Add-Member -Name 'SubscriptionOwner' -MemberType Noteproperty -Value $subsOwner -Force -PassThru
      $subsObject | Add-Member -Name 'Scoped' -MemberType Noteproperty -Value $Scoped -Force -PassThru
      $subsObject | Add-Member -Name 'Details' -MemberType Noteproperty -Value $Details -Force -PassThru
      $processedSubs += $subsObject

}

          $processedSubs1=$processedSubs | ConvertTo-Html -Fragment
          Write-Verbose "The html version   $processedSubs1"
          $SubsAzureQueries
###################################################################
# Defining the scope of Update Management by adding VM Resources
###################################################################
if($VMList -eq 'NoVM')
{
  Set-AzContext -SubscriptionName $SubscriptionName
  $VMs =Get-azVM -Status
  foreach ($AVM in $VMs)
  {

    [array]$VMListf +=$AVM.Name
  }
  $VMListf
}

else{
  $VMListf=$VMList
}
 Set-AzContext -SubscriptionName $SubscriptionName
foreach ($VM in $VMListf) {
    $CheckVM= Get-azVM -Name $VM -Status
if (!$CheckVM) {
    Write-Verbose "No Virtual machine '$($VM) was found'"
    $VMOwner='NA'
    $Scoped='No'
    $Details='VM not found/incorrect'
    $VMsObject = New-Object -TypeName PSObject
    $VMsObject | Add-Member -Name 'VMName' -MemberType Noteproperty -Value $VM -Force -PassThru
    $VMsObject | Add-Member -Name 'VMOwner' -MemberType Noteproperty -Value 'NA' -Force -PassThru
    $VMsObject | Add-Member -Name 'VMStatus' -MemberType Noteproperty -Value 'NA' -Force -PassThru
    $VMsObject | Add-Member -Name 'Scoped' -MemberType Noteproperty -Value $Scoped -Force -PassThru
    $VMsObject | Add-Member -Name 'Details' -MemberType Noteproperty -Value $Details -Force -PassThru
    $processedVMs += $VMsObject
}
else
{
    $VMResourceID=$CheckVM.Id
    If($CheckVM.StorageProfile.OSDisk.OSType -eq "Linux")
    {
      $VMsAzureQueriesL.Add($VMResourceID)
    }
    if($CheckVM.StorageProfile.OSDisk.OSType -eq "Windows")
    {
      $VMsAzureQueriesW.Add($VMResourceID)
    }
    $CheckVM.PowerState
    $vmnme=$CheckVM.Name+'*'
    Write-Verbose "Virtual machine '$($VM) is found'"
    $HWGHealthcheck= $HWGHealth | Where-Object {($_.Name -like $vmnme)}|select-object Name
    #Where-Object {($_.RunbookWorker -like '*vmf8055345f3*')}
If($HWGHealthcheck)
{

Write-Verbose "hyrid worker group exists for $vmnme"


If($CheckVM.PowerState -eq "VM running" -and $CheckVM.StorageProfile.imageReference.publisher -eq "center-for-internet-security-inc" -and $CheckVM.StorageProfile.OSDisk.OSType -eq "Linux" -and $CheckVM.Tags['UpdateManagement'] -eq $True)
   {

    $vmagntexthelath= Get-AzVMExtension -ResourceGroupName $CheckVM.ResourceGroupName -VMName $CheckVM.Name -Name "OMSAgentForLinux" -Status
    if($vmagntexthelath.ProvisioningState -eq "Succeeded")
    {
        $Scoped='Yes'
        $Details='Selected VM is eligible for Patching'
        $VMStatus="VM Running"
    }
    }
 elseif($CheckVM.PowerState -eq "VM running" -and $CheckVM.StorageProfile.imageReference.publisher -eq "center-for-internet-security-inc" -and $CheckVM.StorageProfile.OSDisk.OSType -eq "Linux" -and $CheckVM.Tags['UpdateManagement'] -eq $False)
   {
    $vmagntexthelath= Get-AzVMExtension -ResourceGroupName $CheckVM.ResourceGroupName -VMName $CheckVM.Name -Name "OMSAgentForLinux" -Status
    if($vmagntexthelath.ProvisioningState -eq "Succeeded")
    {
        $Scoped='No'
        $Details="Update Management: False"
        $VMStatus="VM Running"
    }
    }

  elseif($CheckVM.PowerState -eq "VM running" -and $CheckVM.StorageProfile.imageReference.publisher -eq "RedHat" -and $CheckVM.StorageProfile.OSDisk.OSType -eq "Linux" -and $CheckVM.Tags['UpdateManagement'] -eq $True)
   {
    $vmagntexthelath= Get-AzVMExtension -ResourceGroupName $CheckVM.ResourceGroupName -VMName $CheckVM.Name -Name "OMSAgentForLinux" -Status
    if($vmagntexthelath.ProvisioningState -eq "Succeeded")
    {
        $Scoped='Yes'
        $Details='Selected VM is eligible for Patching'
        $VMStatus="VM Running"
    }
    }

  elseif($CheckVM.PowerState -eq "VM running" -and $CheckVM.StorageProfile.imageReference.publisher -eq "RedHat" -and $CheckVM.StorageProfile.OSDisk.OSType -eq "Linux" -and $CheckVM.Tags['UpdateManagement'] -eq $False)
   {
    $vmagntexthelath= Get-AzVMExtension -ResourceGroupName $CheckVM.ResourceGroupName -VMName $CheckVM.Name -Name "OMSAgentForLinux" -Status
    if($vmagntexthelath.ProvisioningState -eq "Succeeded")
    {
        $Scoped='No'
        $Details="Update Management: False"
        $VMStatus="VM Running"
    }
    }

elseif($CheckVM.PowerState -eq "VM running" -and $CheckVM.StorageProfile.OSDisk.OSType -eq "Windows" -and $CheckVM.Tags['UpdateManagement'] -eq $True)
   {
    $vmagntexthelath= Get-AzVMExtension -ResourceGroupName $CheckVM.ResourceGroupName -VMName $CheckVM.Name -Name "MicrosoftMonitoringAgent" -Status
    if($vmagntexthelath.ProvisioningState -eq "Succeeded")
    {
        $Scoped='Yes'
        $Details='Selected VM is eligible for Patching'
        $VMStatus="VM Running"
    }
    }
    else {
            $VMStatus=$CheckVM.PowerState
            $Scoped='No'
            $Details='Selected VM is not eligible for Patching'

    }
  }
  else
{
  Write-Verbose "hyrid worker group does not exists for $vmnme"
  $VMStatus=$CheckVM.PowerState
  $Scoped='No'
  $Details='VM is not onboarded to Update Management'
}


    $tags = Get-AzTag -ResourceId $VMResourceID

    foreach($tagKey in $tags.Properties.TagsProperty.Keys) {
        $tagValue = $tags.Properties.TagsProperty[$tagKey]
        Write-Host "$($tagKey):$($tagValue)"
        If ($tagKey -eq "owner name")
        {
        $tagValue
        $VMOwner=$tagValue
        $tempemail2 =$tagValue
        if ($EmailAddresses -notcontains $tempemail2)
        {
        $EmailAddresses += $tempemail2
        }
        }
        }
        $VMsObject = New-Object -TypeName PSObject
        $VMsObject | Add-Member -Name 'VMName' -MemberType Noteproperty -Value $VM -Force -PassThru
        $VMsObject | Add-Member -Name 'VMOwner' -MemberType Noteproperty -Value $VMOwner -Force -PassThru
        $VMsObject  | Add-Member -Name 'VMStatus' -MemberType Noteproperty -Value $VMStatus -Force -PassThru
        $VMsObject | Add-Member -Name 'Scoped' -MemberType Noteproperty -Value $Scoped -Force -PassThru
        $VMsObject | Add-Member -Name 'Details' -MemberType Noteproperty -Value $Details -Force -PassThru
        $processedVMs += $VMsObject

}
}
            $VMsAzureQueriesL
            $VMsAzureQueriesW
            $processedVMs1=$processedVMs |ConvertTo-Html -Fragment
            $EmailAddresses
            $EmailAddresses= $EmailAddresses| Sort-Object -Property @{Expression={$_.Trim()}} -Unique
            Write-Verbose "emailaddresses $EmailAddresses"
Write-Verbose "processed VMs $processedVMs"
###################################################################
# Defining the scope of Update Management by adding all resource IDs
###################################################################
Write-verbose "Starting Schedule creation with below details..."
If($Geo -eq 'US')
{
$azqueryloc =@("eastus", "eastus2", "centralus")
}
If($geo -eq 'UK')
{
$azqueryloc =@("uksouth", "ukwest")
}
Write-Verbose "Query location set to $azqueryloc"

Set-AzContext -SubscriptionName "US-HUB-PROD-01"

if($VMsAzureQueriesL)
{
  Write-Verbose "Linux query $VMsAzureQueriesL " -Verbose
$azqvmL= New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -scope $VMsAzureQueriesL -Location $azqueryloc -Tag $umTag
$dazqvmL = @($azqvmL)
Write-Verbose "Linux query created $dazqvmL" -Verbose
}
if($VMsAzureQueriesW)
{
  Write-Verbose "Windows query $VMsAzureQueriesW " -Verbose
$azqvmW= New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -scope $VMsAzureQueriesW -Location $azqueryloc -Tag $umTag
$dazqvmW = @($azqvmW)
Write-Verbose "Windows query created $dazqvmW" -Verbose
}
if($SubsAzureQueries)
{
  Write-Verbose "Subscription query $SubsAzureQueries " -Verbose
$azqvmS= New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -scope $SubsAzureQueries -Location $azqueryloc -Tag $umTag
$dazqvmS = @($azqvmS)
Write-Verbose "Subscription query created $dazqvmS" -Verbose
}

########################################################
# Preparing schedule for the patching
########################################################

#Get-TimeZone -Name "*GMT *"
#$TimeZone = "Eastern Standard Time"
#([System.TimeZoneInfo]::Local).Id

$DateTime1 =$ScheduleDate +" "+$StartTime
Write-Verbose " Start time submitted by user: $DateTime1" -Verbose
$ScheduledDateTime1=[DateTime]$DateTime1
Write-Verbose " Start time scheduled for Windows: $ScheduledDateTime1" -Verbose
$ScheduledDateTime2=$ScheduledDateTime1.AddHours(3)
Write-Verbose " Start time scheduled for Linux: $ScheduledDateTime2" -Verbose
$startTimel = [DateTimeOffset]$ScheduledDateTime1
$startTimew = [DateTimeOffset]$ScheduledDateTime2
$duration = New-TimeSpan -Hours 3
Write-Verbose "  timezone scheduled by User: $TimeZone" -Verbose
$currentdate=Get-date
$ScheduleNameW = "Patching_"+"ondemand_"+$currentdate.Month+"_"+$currentdate.Year+"_" +"Windows"+ (get-date).Second
$ScheduleNameL = "Patching_"+"ondemand__"+$currentdate.Month+"_"+$currentdate.Year+"_" +"Linux"+(get-date).Second

$ScheduleW= New-AzAutomationSchedule -Name $ScheduleNameW -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -StartTime $startTimel -OneTime -ForUpdateConfiguration -TimeZone $TimeZone
$ScheduleL= New-AzAutomationSchedule -Name $ScheduleNameL -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -StartTime $startTimew -OneTime -ForUpdateConfiguration -TimeZone $TimeZone

########################################################
# check if the Request is submitted by valid user
########################################################
If ($EmailAddresses -contains $ADTOwner)
{
Write-verbose "Schedule creation in progress..." -Verbose
foreach($VMType in $VMTypes)
{
If($VMType -eq "Windows" -and $VMList -eq "NoVM")
{
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -Schedule $ScheduleW -AzureQuery $dazqvmS -IncludedUpdateClassification Security -Duration $duration -Windows -RebootSetting Never
Write-verbose "Windows VMs Schedule created successfully" -Verbose
}
elseIf($VMType -eq "Windows" -and $VMList -ne "NoVM")
{
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -Schedule $ScheduleW -AzureQuery $dazqvmW -IncludedUpdateClassification Security -Duration $duration -Windows -RebootSetting Never
Write-verbose "Windows VMs Schedule created successfully" -Verbose
}

elseIf($VMType -eq "Linux"  -and $VMList -eq "NoVM")
{
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -Schedule $ScheduleL -AzureQuery $dazqvmS -IncludedPackageClassification Security -Duration $duration -Linux -RebootSetting Never
Write-verbose "Linux VMs Schedule created successfully" -Verbose
}
elseIf($VMType -eq "Linux"  -and $VMList -ne "NoVM")
{
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $aaccountrg -AutomationAccountName $aaccount -Schedule $ScheduleL -AzureQuery $dazqvmL -IncludedPackageClassification Security -Duration $duration -Linux -RebootSetting Never
Write-verbose "Linux VMs Schedule created successfully"
}
}
}
else
{ 
  $error2mailBody = @{
    To         = $ADTOwner
    From       = "AzureNoReply@nationalgrid.com"
    Subject    = "Failed: On-demand VM Update submission for " +$SubscriptionName
    Body       = "We could not recognize you as either Landing Zone Owner or VM Owner. Please check and resubmit the request"
    smtpServer = "smtpapp.nationalgrid.com"
    Port       = 25
    BodyAsHtml = $true
  }
  #$error2mailBody
  Send-MailMessage @error2mailBody -Verbose
  break
}
}

Catch
{
  $Errorlog=$_.Exception
  <#$errormailBody = @{
    To         = $ADTOwner
    From       = "AzureNoReply@nationalgrid.com"
    Subject    = "Failed: On-demand VM Update submission for " +$SubscriptionName
    Body       = "Please find the below Error: \n"+ $Errorlog
    smtpServer = "smtpapp.nationalgrid.com"
    Port       = 25
  }
  $errormailBody
  Send-MailMessage @errormailBody -Verbose#>
  Break
}



#working email

$mailfunction = @{
  emailAddresses     = $EmailAddresses 
  DateTime1          =$DateTime1
  ADTOwner           =$ADTOwner
  Geo                = $Geo
  SubscriptionName   =  $SubscriptionName
  processedVMs       = $processedVMs1
  processedSubs      = $processedSubs1
  VMTypes            = $VMTypes
}
#$mailfunction
Send-Mail @mailfunction
#Send-Mail $EmailAddresses $ScheduleDate $Geo $SubscriptionName $processedVMs $processedSubs $VMTypes
}

########################################################
# Sending Email Notification for the patching
########################################################
Function Send-Mail {
  param(
      [string[]] $EmailAddresses,
      [string] $DateTime1,
      [string] $ADTOwner,
      [string] $Geo,
      [string] $SubscriptionName,
      [string] $processedVMs1,
      [string] $processedSubs1,
      [string] $VMTypes
  )

  $EmailAddresses=$EmailAddresses
  $DateTime1=$DateTime1
  $ADTOwner=$ADTOwner
  $Geo=$Geo
  $SubscriptionName=$SubscriptionName
  $processedVMs1=$processedVMs1
  $processedSubs1=$processedSubs1
  $VMTypes=$VMTypes
  try {

      Write-Verbose "Sending Mail.." -Verbose 
      $emailPattern =   '^[^@\s]+@[^@\s]+\.[^@\s]+$'
      $toEmailAddresses= @()
 
      foreach($emailAddress in $EmailAddresses){
     
         if($emailAddress -match $emailPattern)
         {
               $toEmailAddresses += $emailAddress
            }

         }
Write-Verbose "email addresses .. $toEmailAddresses" -Verbose 
#>
      $emailbody1 = @"

      <!DOCTYPE html><html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="x-apple-disable-message-reformatting"><title></title><style>table, td, div, h1, p {font-family: Arial, sans-serif;}</style></head>
<body style="margin:0;padding:0;"><table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;"><tr> </tr><tr><td align="center" style="padding:0 0 5px 0;background:#70bbd9;"><img src="cid:header.jpg" alt="" width="602" style="height:auto;display:block;" /></td></tr><tr><td style="padding:36px 30px 42px 30px;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;"><tr><td style="padding:0 0 36px 0;color:#153643;">
              <h1 style="font-size:24px;margin:0 0 0px 0;font-family:Arial,sans-serif;">
"@

  $emailbody2 = "User Requested VM Update Notification"
  $emailbody3 = @"
  </h1><p style="font-size:14px;margin:0 0 20px 0;font-family:Arial,sans-serif;">
              <span style="color:#626cf5" ><b>Subscription: </b></span>
"@
  $emailbody4= $SubscriptionName
  $emailbody5=@"
              <span style="color:#626cf5" ><b> >Region: </b></span>
"@

 $emailbody6 = $Geo
 $emailbody7 =@"
              <span style="color:#fccf07" ><b> >Resource: </b></span> 
"@
 $emailbody8 ="Virtual Machine"
 $emailbody9 =@"
              </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#626cf5" ><b>Dear Valued Users,</b></span> 
              </br>
"@

 $emailbody10 ="ADT Team has scheduled on-demand updates for the "
 $emailbody11="<b>"
 $emailbody12="Subscription "
 $emailbody13= "</b><u>"
 $emailbody14=$SubscriptionName +" in "+$Geo + " Region"
 $emailbody15=@"
               </u></p>
          </br><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#11d379" >
          <b>Start Time: </b> </span>
"@
 $emailbody16=$DateTime1
 $emailbody17=@"
            </P><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"> <span style="color:#11d379" >
              <b>Duration: 6 Hours </b></span>
"@
 #$emailbody18= $
 $emailbody19= @" 
              </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
 $emailbody20="We do not expect any impact on the Virtual Machines (VMs). <b>VMs will require a reboot by DevOps owners in order to successfully complete the updates.</b> It is recommended to do this as soon as possible."
 $emailbody21 =@"
 </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
 $emailbody22="Please refer below Assessment details and fix the issues before schedule. please refer wiki for more details"

 $emailbody100= @"
</br><b>Subscription Details:
"@
$emailbody101 =$processedSubs1

 $emailbody102= @"
</br><b>VM Assessment:
"@
$emailbody103 =$processedVMs1
 $emailbody23=@"
 </p><p style="margin:0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"><a href="
"@
 $emailbody24 ="https://dev.azure.com/NGRID/CCoE/_wiki/wikis/CCoE%20User%20Manual/7073/Update-Management-Virtual-Machines"
 $emailbody25=@"
 " style="color:s#ee4c50;text-decoration:underline;">
"@

 $emailbody26 ="Patch Management User Guide"
 $emailbody27 =@"
 </a></p>
          </br><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">The CCoE Team is available to answer any questions you may have. </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Thank you in advance for your cooperation. </p></td></tr></table></td></tr> <tr><td style="padding:30px;background:#e99415;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;"><tr><td style="padding:0;width:50%;" align="left"><p style="margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;"><a href="
"@ 
$emailbody28 = "mailto:" +$ADTOwner +"?subject=Update%20Management%20query for " +$SubscriptionName
$emailbody29 =@"      
" style="color:#ffffff;text-decoration:underline;">Contact Requestor</a>
              </p></td><td style="padding:0;width:50%;" align="right"><p style="margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;"><a href="mailto:box.cloudcoe@nationalgrid.com?subject=Update%20Management%20query" style="color:#ffffff;text-decoration:underline;">Contact CCOE Team</a></p></td></tr></table></td></tr></table></body></html>
"@

$emailbody =$emailbody1 +$emailbody2 +$emailbody3 +$emailbody4 +$emailbody5 +$emailbody6 +$emailbody7 +$emailbody8 +$emailbody9 +$emailbody10 +$emailbody11 +$emailbody12 +$emailbody13 +$emailbody14 +$emailbody15 +$emailbody16 +$emailbody17 +$emailbody19 +$emailbody20 +$emailbody21 +$emailbody22+$emailbody100 +$emailbody101 +$emailbody102 +$emailbody103 +$emailbody23 +$emailbody24 +$emailbody25 +$emailbody26 +$emailbody27 +$emailbody28 +$emailbody29
#removed  +$emailbody18
#cc         = $toEmailAddresses

#Send-MailMessage -To $toEmailAddresses -From $emailFrom -Subject $emailSubject -Body $emailbody -smtpServer $smtpServer -Port $portNumber -Attachments ".\PlatformsScripts\UpdateManagement\Images\header.jpg" -BodyAsHtml $true
Write-verbose "Recepients list: $toEmailAddresses"
$emailSubject = "On-demand VM Update submitted for " +$SubscriptionName
$mailBody = @{
  To         = $toEmailAddresses
  cc         ="box.cloudcoe@nationalgrid.com"
  From       = "AzureNoReply@nationalgrid.com"
  Subject    = $emailSubject
  Body       = $emailbody
  smtpServer = "smtpapp.nationalgrid.com"
  Port       = 25
  BodyAsHtml = $true
  Attachments = ".\PlatformsScripts\UpdateManagement\Images\header.jpg"
}
$mailBody
Send-MailMessage @mailBody -Verbose
      Write-Verbose "Email sent with subject:$emailSubject" -Verbose
  }
  catch {
      Write-Warning -Message "Failed to send Mail`n$_" -Verbose
      break
  }
}
<#
$functioninput=@{
VMTypes                       = "Linux"
portNumber                    =25
smtpServer                     ="smtpapp.nationalgrid.com"
VMList                         ="NoVM"
ScheduleDate                   ='2/10/2022'
emailFrom                      ="AzureNoReply@nationalgrid.com"
Geo                            ='US'
SubscriptionName               ="US-CCOE-SPOKETEST-01"
Timezone                       ="Eastern Standard Time"
StartTime                      ="04:00:00 PM"
ADTOwner                       ="arvind.mahto@nationalgrid.com"

}
$functioninput

CreateSchedule @functioninput
#>