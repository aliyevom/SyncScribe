
#Install-Module AzTable -scope currentuser

param (
   
    [Parameter(Mandatory=$True)] 
    [String] $Cmanagementgrp,
    
    [Parameter(Mandatory=$True)] 
    [String] $location
)

$connectionName = 'AzureRunAsConnection'
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         
 
    "Logging in to Azure..."
    Connect-AzAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

[System.String]$ScriptBlock = {

needs-restarting -r
 }
$FileName = "Checkreboot.sh"
Out-File -FilePath $FileName -InputObject $ScriptBlock -NoNewline

<#
# Function Add TableStorage
#  Function to add a new Table in Storage Account if it does not exist
#
#  Input:
#    storageAccountSubscriptionId  : SubscriptionId where the storage account exists
#    storageAccountName            : Storage account name where table has to be created
#    storageAccountResourceGroup   : Resource Group where storage account is deployed
#    tableName                     : Table name to be created
#
#  Output:
#    Warning if table already exists
#>
Function Add-TableStorage {
 
    param(
        [Parameter(Mandatory = $true)] [string] $storageAccountSubscriptionId,
        [Parameter(Mandatory = $true)] [string] $storageAccountName,
        [Parameter(Mandatory = $true)] [string] $storageAccountResourceGroup,
        [Parameter(Mandatory = $true)] [string] $tableName
    )

    try {
        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        Get-AzStorageTable -Name $tableName -Context $ctx -ErrorAction SilentlyContinue -ErrorVariable err
        if ($err[0] -match "Can not find table") {
            Write-Verbose "Creating new table" -Verbose
            New-AzStorageTable –Name $tableName –Context $ctx -Verbose    
        }
        else {
            Write-Warning "Table with name $tableName already exists" -Verbose
        }

    }
    catch {
        throw $_
    }
}

<#
# Function Update Ingress/Egress Table
# Function to update ingress egress rules table. Skips updates if row already exists
#
#  Input:
#    storageAccountSubscriptionId  : SubscriptionId where the storage account exists
#    storageAccountName            : Storage account name where table has to be created
#    storageAccountResourceGroup   : Resource Group where storage account is deployed
#    tableName                     : Table name to be created
#    subscription                  : Subscription Name whose IP Ranges have to be allowed (Can be * for All Subs)
#    sourceIpAddress               : Source IP address requesting  Egress Access
#    destinationAddresses          : Destination list of FQDNs or Network IPs (Comma separated)
#    protocol                      : Protocol requirement for outbound Access TCP/UDP
#    port                          : Comma Separated Destination Ports required to be opened
#    action                        : allow/deny
#    ruleType                      : ingress/egress
#  Output:
#    Returns updated rows and existing rows in table for the specfic subscription or rule for all subs(*) 
#>
Function Update-LogTable {
    param(
        [Parameter(Mandatory = $true)] [string] $storageAccountSubscriptionId,
        [Parameter(Mandatory = $true)] [string] $storageAccountName,
        [Parameter(Mandatory = $true)] [string] $storageAccountResourceGroup,
        [Parameter(Mandatory = $true)] [string] $tableName,
        [Parameter(Mandatory = $true)] [string] $subscription,
        [Parameter(Mandatory = $true)] [string] $timestamp,
        [Parameter(Mandatory = $true)] [string] $VMidentifier,
        [Parameter(Mandatory = $true)] [string] $VM,
        [Parameter(Mandatory = $true)] [string] $logSource,
        [Parameter(Mandatory = $true)] [string] $logType,
        [Parameter(Mandatory = $true)] [string] $logDescription,
        [Parameter(Mandatory = $true)] [string] $ruleType
    )

    try {

        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        #$Timestamp = Get-date -f MM-dd-yyyy_HH_mm_ss
        $cloudTable = (Get-AzStorageTable –Name $tableName –Context $ctx).CloudTable
           
                Write-Verbose "Updating Table and adding $destinationAddresses" -Verbose
                ## The Scope column is either the Subscription ID or *
                $update = Add-AzTableRow `
                    -table $cloudTable `
                    -partitionKey $ruleType `
                    -rowKey ("$VMidentifier") -property @{"Timestamp" = "$timestamp"; "VM" = "$VM"; "logType" = "$logType"; "logSource" = "$logSource"; "Subscription" = "$subscription"; "Scope" = "$subscriptionId"; "logDescription" = "$logDescription" }


            if ($update) {
                Write-Verbose "Table update successful" -Verbose
            }
            else {
                Write-Verbose "Table update not successful" -Verbose
            }
            
      

    }
    catch {
        throw $_
    }
    Return $result
}


#Connect-AzAccount
#$Cmanagementgrp = 'Global-US-NonProd'
#
#$location = 'EastUS2'
$Subscriptions = Get-AzManagementGroup -GroupID $CManagementGrp -Expand -Recurse
$subscriptionlist=$Subscriptions |foreach-object -MemberName Children

#[System.Collections.Generic.List[PSObject]]$vmlist= @()
#$Rgs=@()

#$subslist=$subscriptionlist.DisplayName

#$Subslist
$storageAccountSubscriptionId="d004487f-755f-432f-981b-63d14a835b16"
$storageAccountName= "ngccoeumlstorageeus2"
$storageAccountResourceGroup="willtest-dev-eus2-budget-rg"
$tableName= 'updateMgmtlog'
$ruleType ="Pre-check"

Add-TableStorage $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName

$subscriptionlist |ForEach-Object {

$subs=$_.DisplayName

Set-AzContext -Subscription $subs |Out-Null

<#
$computeRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Compute

    if ($computeRp.RegistrationState[1] -eq "NotRegistered") {

        Write-Verbose "Registering Microsoft.Compute Resource Provider...." -Verbose

        Register-AzResourceProvider -ProviderNamespace "Microsoft.Compute" -Verbose
        }#>
#$Rgs= Get-AzResourceGroup -Location $location
Get-AzVM -Location $location -Status |ForEach-Object {
$subscription=$subs
$VM=$_.Name

If($_.PowerState -eq "VM running" -and $_.StorageProfile.imageReference.publisher -eq "center-for-internet-security-inc" -and $_.StorageProfile.OSDisk.OSType -eq "Linux" -and $_.Tags['UpdateManagement'] -eq $True)
{
"VM is running"
$_.Name

try
{
[string]$RGName=$_.ResourceGroupName
$vmagntexthelath= Get-AzVMExtension -ResourceGroupName $RGName -VMName $_.Name -Name "OMSAgentForLinux" -Status
$vmdpagntexthelath= Get-AzVMExtension -ResourceGroupName $RGName -VMName $_.Name -Name "DependencyAgentLinux" -Status
}
catch{
 throw $_
      $logSource ="Agent-Health"
      $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
      $VMidentifier =$VM+$timestamp
     $logType = "Error" #Info, Error
     $logDescription = "The VM agent returned exception, please chck VM agent health Manually"   #Logoutput
    Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType


}



If($vmagntexthelath.ProvisioningState -eq "Succeeded" -and $vmdpagntexthelath.ProvisioningState -eq "Succeeded")
{ 
     $logSource ="Agent-Health"
     $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
     $VMidentifier =$VM+$timestamp
     $logType = "Info" #Info, Error
     $logDescription = "The Agent is ready for patching"   #Logoutput
     Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType
try{

    Set-AzContext -Subscription $subs |Out-Null
    [string]$ResourceGroup= $_.ResourceGroupName
    $out = Invoke-AzVMRunCommand -ResourceGroupName $ResourceGroup -VMName $_.Name -CommandId 'RunShellScript' -ScriptPath $FileName
    $out
    #Formating the Output with the VM name
    $output = $_.Name + " " + $out.Value[0].Message
    "Getting output...."
    $output

     $logSource ="VM-Health"
     $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
     $VMidentifier =$VM+$timestamp
     $logType = "Info" #Info, Error
     $logDescription = "The pending reboot script returned: " +$output   #Logoutput
     Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType

}

Catch
{
throw $_
     $logSource ="VM-Health"
     $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
     $VMidentifier =$VM+$timestamp
     $logType = "Error" #Info, Error
     $logDescription = "The pending reboot script returned error, please check the VM health "   #Logoutput
     Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType


}

}
else
{

     $logSource ="Agent-Health"
     $errordetails= "The VM Agent is unhealthy. Update will fail. " + "Agent Provisioning Status: " + $vmagntexthelath.ProvisioningState + " " +$vmagntexthelath.Statuses + " " +$vmagntexthelath.SubStatuses + "  Agent Dependecny Provisioning Status : " + $vmdpagntexthelath.ProvisioningState + " " +$vmdpagntexthelath.Statuses + " " +$vmdpagntexthelath.SubStatuses
     $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
     $VMidentifier =$VM+$timestamp
     $logType = "Error" #Info, Error
     $logDescription = $errordetails   #Logoutput
    Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType

}
}
If($_.PowerState -ne "VM running" -and $_.StorageProfile.imageReference.publisher -eq "center-for-internet-security-inc" -and $_.StorageProfile.OSDisk.OSType -eq "Linux" -and $_.Tags['UpdateManagement'] -eq $True)
{
     $errordetails= "The VM is not running. Please validate VM health. Currently VM is in  "+ "'" + $_.PowerState + "'"+" status"
     $timestamp =Get-date -f MM-dd-yyyy_HH_mm_ss
     $VMidentifier =$VM+$timestamp
     $logSource ="VM-Health"
     $logType = "Error" #Info, Error
     $logDescription = $errordetails   #Logoutput

    Update-LogTable $storageAccountSubscriptionId $storageAccountName $storageAccountResourceGroup $tableName $subscription $timestamp $VMidentifier $VM $logSource $logType $logDescription $ruleType

}

}
}
#Set-AzContext -Subscription "d004487f-755f-432f-981b-63d14a835b16" |Out-Null
#Get-AzProviderFeature -FeatureName "RunCommandPreview" -ProviderNamespace "Microsoft.Compute"
#Register-AzProviderFeature -FeatureName "RunCommandPreview" -ProviderNamespace "Microsoft.Compute"

