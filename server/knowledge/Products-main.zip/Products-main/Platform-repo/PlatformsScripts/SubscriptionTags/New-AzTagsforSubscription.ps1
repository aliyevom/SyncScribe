param
(
    [parameter(Mandatory = $true)]
    [String] 
    $invp,
    [parameter(Mandatory = $true)]
    [String]
    $owner,
    [parameter(Mandatory = $true)]
    [String]
    $bu,
    [parameter(Mandatory = $true)]
    [String]
    $bu1,
    [parameter(Mandatory = $true)]
    [String] 
    $costCenter,
    [parameter(Mandatory = $true)]
    [String] 
    $projectName,
    [parameter(Mandatory = $true)]
    [String] 
    $region,
    [parameter(Mandatory = $true)]
    [String]
    $environment,
    [parameter(Mandatory = $true)]
    [String]
    $applicationID,
    [parameter(Mandatory = $true)]
    [String]
    $companyCode,
    [parameter(Mandatory = $true)]
    [String]
    $financialOwner,
    [parameter(Mandatory = $true)]
    [String]
    $app_name,
    [parameter(Mandatory = $true)]
    [String]
    $service_owner,
    [parameter(Mandatory = $true)]
    [String]
    $project_manager,
    [parameter(Mandatory = $true)]
    [String]
    $workOrder,
    [parameter(Mandatory = $true)]
    [String]
    $opsCode,
    [parameter(Mandatory = $true)]
    [String]
    $wbsCode,
    [string]$scopeId ,
    [switch]$ScopeSubscription
)

$ErrorActionPreference = 'Stop'
try {
    if ($ScopeSubscription) {
        $ScopeSubscriptionId = (get-azsubscription -SubscriptionName $scopeId).SubscriptionId
        $scope = "/subscriptions/$ScopeSubscriptionId"
        
    }
    else {
        $scope = "/providers/Microsoft.Management/managementGroups/$scopeId"
    }
    if ($invp -like "INVP*") {
        Write-Verbose "TRUE, leaving invp alone" -Verbose
    }
    else {
        Write-Verbose "FALSE, doesn't contain INVP" -Verbose
        $invp = "BUSI"
    }
    if ($opsCode.equals('0000')) {
        Write-Verbose "Operations Code is empty" -Verbose
        $opsCode = " "
    }
    else {
        Write-Verbose "Operations Code is NOT empty, Resume" -Verbose
    }
    if ($applicationID.equals('99999')) {
        Write-Verbose "ApplicationID Code is empty" -Verbose
        $applicationID = " "
    }
    else {
        Write-Verbose "ApplicationID is NOT empty, Resume" -Verbose
    }
    if ($bu1.equals('999')) {
        Write-Verbose "ApplicationID Code is empty" -Verbose
        $bu1 = "N/A"
    }
    if ($app_name.equals('999')) {
        Write-Verbose "ApplicationID Code is empty" -Verbose
        $app_name = "N/A"
    }
    else {
        Write-Verbose "ApplicationID is NOT empty, Resume" -Verbose
    }
    

    if ($bu -eq 'ESO') {
        $companyCode = "1105" 
        $costCenter = "101257"
        $wbsCode = "ITX/07400-99-01-01"
    }
        

    if ($region -eq 'UK') {
        $tags = @{"Application ID" = $applicationID ; "Application Name" = $app_name; "Business Unit" = $bu ; "Business Unit 1" = $bu1 ; "Company Code" = $companyCode ; "Cost Center" = $costCenter; "Environment" = $environment; "Financial Owner" = $financialOwner ; "WBS Code" = $wbsCode ; "Project Code" = $invp ; "Project Manager" = $owner ; "Project Name" = $projectName; "Service Owner" = $service_owner ; }
    }
    else {
        $tags = @{"Application ID" = $applicationID ; "Application Name" = $app_name; "Business Unit" = $bu ; "Business Unit 1" = $bu1 ; "Company Code" = $companyCode ; "Cost Center" = $costCenter; "Environment" = $environment; "Financial Owner" = $financialOwner ; "Internal or Work Order" = $workOrder ; "Operations Code (WO)" = $opsCode ; "Project Code" = $invp ; "Project Manager" = $project_manager ; "Project Name" = $projectName; "Service Owner" = $service_owner ; }
    }

    New-AzTag -ResourceId $scope -Tag $tags

     

}
catch {
    throw $_
}
