<#
.SYNOPSIS
Grant designated SPN membership of designated GBL-CCoE-SharedServices Group

.DESCRIPTION
Grant designated SPN membership of designated Security Group.

.PARAMETER TargetGroupObjectId
Mandatory. The object id of the group to add the member(s) to.

.PARAMETER MemberObjectId
Mandatory. The object id of the member to add to the group.

.EXAMPLE
 addSpnToGroup.ps1' -TargetGroupObjectId 'f9013f60-1af2-4c7e-9189-8a87a3f52a5d' -MemberObjectId '<SPNObjectId>' 
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$TargetGroupObjectId,
    [string]$MemberObjectId
)

$ErrorActionPreference = 'Stop'

try {

    Add-AzADGroupMember -TargetGroupObjectId $TargetGroupObjectId -MemberObjectId $MemberObjectId
    Write-verbose  "<$MemberObjectId> has been added as a member of AD group <$TargetGroupObjectId>" -Verbose

}
catch {
    if ( $_.exception | Select-String "One or more added object references already exist for the following modified properties: 'members'.") {
        Write-Warning  "<$MemberObjectId> is already a member of AD group <$TargetGroupObjectId>"
    }
    else {
        throw  $_
    } 
}
