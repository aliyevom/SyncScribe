<#
.DESCRIPTION
Automate Adding A records to Azure Private DNS Zone with PowerShell.
#>

Function Invoke-privateDNSzones {
  param(
    [Parameter(Mandatory = $true)] [string] $dnsZoneName,
    [Parameter(Mandatory = $true)] [string] $dnsRecordAction,
    [Parameter(Mandatory = $true)] [string] $dnsRecordSetType,
    [Parameter(Mandatory = $true)] [string] $resourceName,
    [Parameter(Mandatory = $true)] [string] $recordValue
  ) 

  Install-Module -Name Az.PrivateDns -force
  Import-Module Az.Dns
  Import-Module Az.PrivateDns

  $subscriptionId = "US-HUB-PROD-01"
  $resourceGroupName = "ng-prd-eus2-privateDns-rg"

  Set-AzContext -SubscriptionId $subscriptionId
  Write-Verbose "$subscriptionId" -Verbose    
  
  #to remove the dns zone name from the resource name
  if ($resourceName -like "*$dnsZoneName*") {
     $resourceName = $resourceName.Replace($dnsZoneName, "").TrimEnd('.')
     Write-Verbose  "Updated resource name: $resourceName" -Verbose
  } 

  try {
    ### Creates A record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'A') -and ($dnsRecordAction -eq 'create')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -IPv4Address $recordValue)
    }
    ### Creates TXT record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'TXT') -and ($dnsRecordAction -eq 'create')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -Value $recordValue)
    }
    ### Creates CNAME record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'CNAME') -and ($dnsRecordAction -eq 'create')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -Cname $recordValue)
    }
    ### Modifies A record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'A') -and ($dnsRecordAction -eq 'modify')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -IPv4Address $recordValue) -Confirm:$False -Overwrite
    }
    ### Modifies TXT record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'TXT') -and ($dnsRecordAction -eq 'modify')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -Value $recordValue) -Confirm:$False -Overwrite
    }
    ### Modifies CNAME record set in a Private DNS zone
    if (($dnsRecordSetType -eq 'CNAME') -and ($dnsRecordAction -eq 'modify')) {
         $RecordSet = New-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -Cname $recordValue) -Confirm:$False -Overwrite
    }
    ### Deletes record set in a Private DNS zone
    if ($dnsRecordAction -eq 'delete') {
         $RecordSet = Get-AzPrivateDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -ZoneName $dnsZoneName
         Remove-AzPrivateDnsRecordSet -RecordSet $RecordSet
    }  

  }
  catch {
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
    throw $_
  }

}