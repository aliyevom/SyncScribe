<#
.SYNOPSIS
Register Resource Providers

.DESCRIPTION
Register required Resource Providers in Spoke Subscriptions

.PARAMETER SubscriptionID
Mandatory. Subscription ID
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [parameter(Mandatory = $true)]
    [string]$SubscriptionID
)
try {
    Set-AzContext -Subscription $SubscriptionID
    $computeRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Compute
    $rsvRp = Get-AzResourceProvider -ProviderNamespace Microsoft.RecoveryServices
    $nwRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Network
    $auRp= Get-AzResourceProvider -ProviderNamespace Microsoft.Automation
    $webRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Web
    $purviewRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Purview
    $synapseRp = Get-AzResourceProvider -ProviderNamespace Microsoft.Synapse
    $mlsRp = Get-AzResourceProvider -ProviderNamespace Microsoft.MachineLearningServices
    $RService = Get-AzResourceProvider -ProviderNamespace Microsoft.SignalRService
    $dashBoard = Get-AzResourceProvider -ProviderNamespace Microsoft.Dashboard
    $encryptionAtHost = Get-AzProviderFeature -FeatureName "EncryptionAtHost" -ProviderNamespace "Microsoft.Compute"
    $mapsAccount = Get-AzResourceProvider -ProviderNamespace Microsoft.Maps
    $ADFRP = Get-AzResourceProvider -ProviderNamespace Microsoft.DataFactory
    if ($computeRp.RegistrationState[1] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Compute Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Compute" -Verbose
    }
    else { 
        Write-Warning "Microsoft.Compute Resource Provider is already registered" -Verbose
    }
    if ($nwRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Network Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Network" -Verbose
    }
    else {
        Write-Warning "Microsoft.Network Resource Provider is already registered" -Verbose
    }
    if ($rsvRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.RecoveryServices Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.RecoveryServices" -Verbose
    }
    else {
        Write-Warning "Microsoft.RecoveryServices Resource Provider is already registered" -Verbose
    }
    if ($auRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Automation Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Automation" -Verbose
    }
    else {
        Write-Warning "Microsoft.Automation Resource Provider is already registered" -Verbose
    }
    if ($webRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Web Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Web" -Verbose
    }
    else {
        Write-Warning "Microsoft.Web Resource Provider is already registered" -Verbose
    }
    if ($purviewRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Purview Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Purview" -Verbose
    }
    else {
        Write-Warning "Microsoft.Purview Resource Provider is already registered" -Verbose
    }
    if ($synapseRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Synapse Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Synapse" -Verbose
    }
    else {
        Write-Warning "Microsoft.Synapse Resource Provider is already registered" -Verbose
    }
    if ($mlsRp.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.MachineLearningServices Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.MachineLearningServices" -Verbose
    }
    else {
        Write-Warning "Microsoft.MachineLearningServices Resource Provider is already registered" -Verbose
    }
    if ($RService.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.SignalRService Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.SignalRService" -Verbose
    }
    else {
        Write-Warning "Microsoft.SignalRService Resource Provider is already registered" -Verbose
    }
    if ($dashBoard.RegistrationState[0] -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Dashboard Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Dashboard" -Verbose
    }
    else {
        Write-Warning "Microsoft.Dashboard Resource Provider is already registered" -Verbose
    }
    if ($encryptionAtHost.RegistrationState -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.EncryptionAtHost Resource Provider...." -Verbose
        Register-AzProviderFeature -FeatureName "EncryptionAtHost" -ProviderNamespace "Microsoft.Compute"
    }
    else {
        Write-Warning "Microsoft.Compute EncryptionAtHost Resource Provider is already registered" -Verbose
    }
    if ($mapsAccount.RegistrationState -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.Maps Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.Maps" -Verbose
    }
    else {
        Write-Warning "Microsoft.Maps Resource Provider is already registered" -Verbose
    }
    if ($ADFRP.RegistrationState -eq "NotRegistered") {
        Write-Verbose "Registering Microsoft.DataFactory Resource Provider...." -Verbose
        Register-AzResourceProvider -ProviderNamespace "Microsoft.DataFactory" -Verbose
    }
    else {
        Write-Warning "Microsoft.DataFactory Resource Provider is already registered" -Verbose
    }
}
catch {
    throw  $_
}


