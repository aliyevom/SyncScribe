param
(
    [parameter(Mandatory = $true)]
    [String] 
    $BillingScope,
    [parameter(Mandatory = $true)]
    [String]
    $SubscriptionName,
    [parameter(Mandatory = $true)]
    [String]
    $ManagementGroupId
)
# Capitalize Subscription Name
$UpperSubscriptionName = $SubscriptionName.ToUpper()

# Module updated as of 8/4/2023
Install-Module -Name Az.Subscription -Scope CurrentUser -Force -RequiredVersion 0.9.0

$subscription = Get-AzSubscription -SubscriptionName $UpperSubscriptionName -ErrorAction SilentlyContinue

$Workload = 'DevTest'
Write-Verbose "Print BillingScope $BillingScope" -Verbose

try {
    if (-not $subscription) {
         $UpperSubsEnv= $UpperSubscriptionName.Split("-")[2]
        if ($UpperSubsEnv -cin ("QA","UAT")) {
            $ManagementGroupId = $ManagementGroupId.Replace("NonProd", "Prod")
        }
        if ($UpperSubsEnv -ceq "PROD") {
            $ManagementGroupId = $ManagementGroupId.Replace("NonProd", "Prod")
            $Workload = 'Production'
        }
        if ($UpperSubscriptionName -like "*-UK-*") {
            $ManagementGroupId = $ManagementGroupId.Replace("US", "UK")
        }

        Write-Verbose "STARTING SUBSCRIPTION PROCESS : $UpperSubscriptionName" -Verbose
        $subscription = New-AzSubscriptionAlias -AliasName $UpperSubscriptionName -SubscriptionName $UpperSubscriptionName -BillingScope $BillingScope -Workload $Workload

        Write-Verbose "STARTING SUBSCRIPTION PROCESS SECOND : $subscription" -Verbose
        #Delay for Bug #43295 in ADO
        Start-Sleep -Seconds 60
        
        # Get Subscription Id
        $subscriptionId = (Get-AzSubscription -SubscriptionName $UpperSubscriptionName).Id

        # move subscription under a management group
        New-AzManagementGroupSubscription -GroupId $ManagementGroupId -SubscriptionId $subscriptionId
    }
    else {
        Write-Warning "Subscription $subscription is already deployed" -Verbose
        $subscriptionDeployed = $true
        Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'subscriptionDeployed', $subscriptionDeployed)
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionDeployed;issecret=false;isOutput=true', $subscriptionDeployed)
    }

    $subscriptionId = (Get-AzSubscription -SubscriptionName $UpperSubscriptionName -ErrorAction SilentlyContinue).Id
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'newSubscriptionID', $subscriptionId)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'newSubscriptionID;issecret=false;isOutput=true', $subscriptionId)
}
catch {
    throw $_
}


return $subscription