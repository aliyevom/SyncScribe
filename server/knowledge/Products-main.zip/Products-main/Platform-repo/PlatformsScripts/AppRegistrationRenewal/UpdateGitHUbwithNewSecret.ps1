[CmdletBinding(SupportsShouldProcess)]
Param(
    [string]$USSPNs,
    [string]$UKSPNs,
    [string]$Step
    )
    $ErrorActionPreference = 'Continue'
    $USSPNs11 = $USSPNs.TrimEnd()
    $USSPNs12 =$USSPNs11.Split(",")
    $USSPNs12.Length
    $USSPNs1= $USSPNs12 | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    $UKSPNs11 = $UKSPNs.TrimEnd()
    $UKSPNs12 =$UKSPNs11.Split(",")
    $UKSPNs12.Length
    $UKSPNs1 = $UKSPNs12 | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    function Get-AllOrgs {

        $ErrorActionPreference = "continue";
        $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $headers.Add("Content-Type", "application/json")
        $headers.Add("Authorization", "Basic $GITPat")
        try {
        
        #Write-Debug $body
        #https://api.github.com/user/orgs
        $URI ="https://api.github.com/user/orgs"
        
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params
        
        $response
            }
            catch{

                #throw $_
            
            }
            return $response.value
        }

function Get-Repository {
            PARAM(
                [Parameter(Mandatory = $true)] [string] $OrgName,
                [Parameter(Mandatory = $true)] [string]$RepoName
            )
            $ErrorActionPreference = "continue";
            $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/json")
            $headers.Add("Authorization", "Basic $GITPat")
            try {
            
            #Write-Debug $body
            #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
            $URI ="https://api.github.com/repos/"+ $OrgName +"/" + $RepoName
            
            $params = @{
                Method          = 'GET'
                UseBasicParsing = $true
                Headers         = $headers
                Uri             = $URI
                ContentType     = 'application/json'
            };
            $response = Invoke-RestMethod @params
            
            $response
                }
                catch{
        
                    #throw $_
                
                }
                return $response.value
            }

function Get-Environment {
                PARAM(
                    [Parameter(Mandatory = $true)] [string]$OrgName,
                    [Parameter(Mandatory = $true)] [string]$RepoName,
                    [Parameter(Mandatory = $true)] [string]$Environment
                )
                $ErrorActionPreference = "continue";
                $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $headers.Add("Content-Type", "application/json")
                $headers.Add("Authorization", "Basic $GITPat")
                try {
                
                #Write-Debug $body
                #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
                #  https://api.github.com/repos/nationalgrid-cloud-team/US-5125/environments/dev
                $URI ="https://api.github.com/repos/"+ $OrgName +"/"+ $RepoName + "/environments/" + $Environment
                
                $params = @{
                    Method          = 'GET'
                    UseBasicParsing = $true
                    Headers         = $headers
                    Uri             = $URI
                    ContentType     = 'application/json'
                };
                $response = Invoke-RestMethod @params
                
                $response
                    }
                    catch{
                        #throw $_
                    }
                    return $response.value
                }

function Get-EnvSecret {
                    PARAM(
                        [Parameter(Mandatory = $true)] [string]$OrgName,
                        [Parameter(Mandatory = $true)] [string]$RepoName,
                        [Parameter(Mandatory = $true)] [string]$Environment,
                        [Parameter(Mandatory = $true)] [string]$SecretName
                    )
                    $ErrorActionPreference = "continue";
                    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                    $headers.Add("Content-Type", "application/json")
                    $headers.Add("Authorization", "Basic $GITPat")
                    try {
                    
                    #Write-Debug $body
                    #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
                    #  https://api.github.com/repos/nationalgrid-cloud-team/US-5125/environments/dev/secrets/AZURE_CLIENT_ID
                    $URI ="https://api.github.com/repos/"+ $OrgName +"/"+ $RepoName + "/environments/" + $Environment +"/secrets/"+ $SecretName
                    
                    $params = @{
                        Method          = 'GET'
                        UseBasicParsing = $true
                        Headers         = $headers
                        Uri             = $URI
                        ContentType     = 'application/json'
                    };
                    $response = Invoke-RestMethod @params
                    
                    $response
                        }
                        catch{
                            #throw $_
                        }
                        return $response.value
                    }
function Get-EnvPublicKey {
                PARAM(
                    [Parameter(Mandatory = $true)] [string]$RepoID,
                    [Parameter(Mandatory = $true)] [string]$Environment
                )
                $ErrorActionPreference = "continue";
                $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $headers.Add("Content-Type", "application/json")
                $headers.Add("Authorization", "Basic $GITPat")
                try {
                
                #Write-Debug $body
                #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
                #https://api.github.com/repositories/REPOSITORY_ID/environments/ENVIRONMENT_NAME/secrets/public-key
                $URI ="https://api.github.com/repositories/"+ $RepoID +"/environments/" + $Environment + "/secrets/public-key"
                
                $params = @{
                    Method          = 'GET'
                    UseBasicParsing = $true
                    Headers         = $headers
                    Uri             = $URI
                    ContentType     = 'application/json'
                };
                $response = Invoke-RestMethod @params
                
                $response
                    }
                    catch{
                        #throw $_
                    }
                    return $response.value
                }

function Add-EnvSecret {
                    PARAM(
                        [Parameter(Mandatory = $true)] [string]$RepoID,
                        [Parameter(Mandatory = $true)] [string]$Environment,
                        [Parameter(Mandatory = $true)] [string]$SecretName,
                        [Parameter(Mandatory = $true)] [string]$EncryptedSecret,
                        [Parameter(Mandatory = $true)] [string]$KeyID
                    )
                    $ErrorActionPreference = "continue";
                    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                    $headers.Add("Content-Type", "application/json")
                    $headers.Add("Authorization", "Basic $GITPat")
                    try {
             $body = @"
             {
                 `"encrypted_value`": `"$EncryptedSecret`",
                 `"key_id`":  `"$KeyID`"
                 }
"@
                    
                    Write-Debug $body
                    #'https://api.github.com/repositories/REPOSITORY_ID/environments/ENVIRONMENT_NAME/secrets/SECRET_NAME
                    $URI ="https://api.github.com/repositories/"+ $RepoID +"/environments/" + $Environment + "/secrets/"+ $SecretName
                    
                    $params = @{
                        Method          = 'PUT'
                        Body            = $body
                        UseBasicParsing = $true
                        Headers         = $headers
                        Uri             = $URI
                        ContentType     = 'application/json'
                    };
                    $response = Invoke-RestMethod @params
                    
                    $response
                        }
                        catch{
                            #throw $_
                        }
                        return $response.value
                    }



#Install-Module -Name PSSodium -RequiredVersion '0.4.2' -Force -Scope CurrentUser
function Load-Module ($m) {

# If module is imported say that and do nothing
if (Get-Module | Where-Object { $_.Name -eq $m }) {
    write-host "Module $m is already imported."
}
else {

    # If module is not imported, but available on disk then import
    if (Get-Module -ListAvailable | Where-Object { $_.Name -eq $m }) {
        Import-Module $m -Verbose
    }
    else {

        # If module is not imported, not available on disk, but is in online gallery then install and import
        if (Find-Module -Name $m | Where-Object { $_.Name -eq $m }) {
            Install-Module -Name $m -RequiredVersion '0.4.2' -Force -Verbose -Scope CurrentUser -ErrorAction Continue
            Import-Module $m -Verbose
        }
        else {

            # If the module is not imported, not available and not in the online gallery then abort
            write-host "Module $m not imported, not available and not in an online gallery, exiting."
        }
    }
}
}

function Update-Secret {
    param (
        [Parameter(Mandatory = $true)] [string]$OrgName,
        [Parameter(Mandatory = $true)] [string]$SPN,
        [Parameter(Mandatory = $true)] [string]$RepoName,
        [Parameter(Mandatory = $true)] [string]$RepoId,
        [Parameter(Mandatory = $true)] [string]$Region,
        [Parameter(Mandatory = $true)] [string]$Environment
    )

#Extracting all Secrets from key Vault
if ($Region -eq "US") {
    $KeyVaultName = 'ng-prd-eus2-kv-01'
    Write-Output "setting context to...$Region " -Verbose
    Set-AzContext -Subscription "US-HUB-Prod-01"
}

else {
    $KeyVaultName = 'ng-prd-uks-kv-01'
    Write-Output "setting context to...$Region " -Verbose
    Set-AzContext -Subscription "UK-HUB-Prod-01"
}

$APPIDName = $SPN + "-appId"
$appID = `
    Get-AzKeyVaultSecret `
    -VaultName $KeyVaultName `
    -Name $APPIDName `
    -ErrorAction Continue;
    Write-Output "getting APP ID  from KV $APPIDName " -Verbose
$APPPSWDName = $SPN + "-Password"
$spnPassword = `
    Get-AzKeyVaultSecret `
    -VaultName $KeyVaultName `
    -Name $APPPSWDName `
    -ErrorAction Continue;
    #$spnPassword = `
#If (($null -ne $appID) -and ($null -ne $spnPassword)) {
If ($null -ne $appID) {
    $ApplicationID = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($appID.SecretValue)
    $ApplicationIDText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ApplicationID)
    $ApplicationIDText
    Write-Output "SPN - $ApplicationIDText and Password exists in key vault " -Verbose
    $ServicePrincipalPasswd = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($spnPassword.SecretValue)
    $ServicePrincipalPasswdText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ServicePrincipalPasswd)
    #$ServicePrincipalPasswdText
    Write-Output "Initiating Encryption tasks... " -Verbose
    #$EncryptedSecret =ConvertTo-SodiumEncryptedString -Text $Secret -PublicKey $PublicKey
    #$EncryptedSecret

}
else {
    Write-Error "AppID and Secret not found in Key Vault" -Verbose
}

        $EnvPublicKey = Get-EnvPublicKey -RepoID $RepoID -Environment $Environment
        if ($EnvPublicKey) {
            Write-Output "Successfully retrieved Public Key of the Repository " -Verbose
        }
        else {
            Write-Output "Retrieve Public Key returned an unknown error" -Verbose
        }

        $EnvPublicKey
        $PublicKey = $EnvPublicKey.Key
        $PublicKey
        $PublicKeyID = $EnvPublicKey.key_Id
        $PublicKeyID

        Write-Output "Checking environment $Environment in $RepoName... " -Verbose
        $CheckEnv = Get-Environment -OrgName $OrgName -RepoName $RepoName -Environment $Environment
        $CheckEnv
        if ($CheckEnv) {

            Write-Output "$Environment environment exists.... " -Verbose

            $CheckAppSecret = Get-EnvSecret -OrgName $OrgName -RepoName $RepoName -Environment $Environment -SecretName "AZURE_CLIENT_SECRET"
            if ($CheckAppSecret) {
                Write-Output "AZURE_CLIENT_SECRET exists, starting update.... " -Verbose
                #Add Secret
                $Appsecretencrypt = ConvertTo-SodiumEncryptedString -Text $ServicePrincipalPasswdText -PublicKey $PublicKey
                if ($Appsecretencrypt) {
                    Write-Output " Client ID Secret Encryption Succeeded " -Verbose
                }
                else {
                    Write-Output " SPNID Secret Encryption failed " -Verbose
                }
                $Appsecretencrypt
                $AddAppsecretencrypt = Add-EnvSecret -RepoID $RepoID -Environment $Environment -SecretName "AZURE_CLIENT_SECRET" -EncryptedSecret $Appsecretencrypt -KeyID $PublicKeyID
                if ($AddAppsecretencrypt) {
                    Write-Output " Client ID Secret environment variable updated successfully " -Verbose
                }
                else {
                    Write-Output " Update of Client Id Secret environment variable failed " -Verbose
                }
                $AddAppsecretencrypt
    
            }
            else {
                Write-Output " AZURE_CLIENT_SECRET Secret does not exists...environment variable will not up updated " -Verbose
            }
    

        }
        else {
            Write-Output "$Environment environment does not exists... " -Verbose
        }
}



Write-Output "provided US SPNS are $($USSPNs1)"
Write-Output "provided UK SPNS are $($UKSPNs1)"

Write-Output "Starting PSSodium module installation... " -Verbose
Load-Module 'PSSodium'
Write-Output " PSSodium Module Installation completed.  " -Verbose

$KeyVaultName = 'ng-prd-eus2-kv-01'
$PATSecretName = 'GBL-SVC-GITServiceAccount-PAT'

Set-AzContext -Subscription "US-HUB-Prod-01"
    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecretName `
        -ErrorAction SilentlyContinue;
    Write-Output "getting PAT  from KV " -Verbose
    $PATValue = $PAT.SecretValue
    Write-Output "$PATValue " -Verbose
    if($PATValue)
    {
    $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
    $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
    #$PATSecretText
    }

    else {
        {Write-Output "PAT is not found. please check the PAT Secret Value"}
    }




try {
#US SPN Update
    if (($USSPNs1) -and ($Step -eq "US")) {
        foreach ($USSPN in $USSPNs1) {
            #$USSPNs1 = "US-225063-DEV-01-SPN" 
            $splitUSSPN = $USSPN.split('-')
            $Region =$splitUSSPN[0]
            $Environment = $splitUSSPN[2].tolower()
            $RepoName= $splitUSSPN[0] +"-"+ $splitUSSPN[1]
            $OrgList= Get-AllOrgs
            $OrgNames = $OrgList.login
            $OrgNames
                foreach ($OrgName in $OrgNames) {
                    Write-Output "Checking repo $RepoName in $OrgName" -Verbose
                    $Repodetails = Get-Repository -OrgName $OrgName -RepoName $RepoName
                    $Repodetails
                    if ($Repodetails) {
                        $RepoID = $Repodetails.id
                        $RepoID
                        Write-Output "$RepoName found, invoking secret check & update... " -Verbose
                        Update-Secret -OrgName $OrgName -SPN $USSPN -RepoName $RepoName -RepoID $RepoID -Region $Region -Environment $Environment
                        Write-Output "Secret Update Completed... " -Verbose

                    }
                    else {
                        Write-Output "$RepoName does not exists... " -Verbose
                    }
                    

                }
            }
        }


#UK SPN update
    if (($UKSPNs1) -and ($Step -eq "UK")) {
        foreach ($UKSPN in $UKSPNs1) {
            Write-Output "Provided SPN is $UKSPN"
            #$USSPNs1 = "US-225063-DEV-01-SPN" 
            $splitUKSPN = $UKSPN.split('-')
            $Region =$splitUKSPN[0]
            $Environment = $splitUKSPN[2].tolower()
            if ($splitUKSPN[3] -eq "01")
            {
                $RepoName= $splitUKSPN[0] +"-"+ $splitUKSPN[1]
            }
            else {
                $RepoName= $splitUKSPN[0] +"-"+ $splitUKSPN[1] +"-"+ $splitUKSPN[3]
            }
            
            if ($Environment -eq "fof")
            {
                $Environment ="uat"
            }
            $RepoName= $splitUKSPN[0] +"-"+ $splitUKSPN[1]
            $OrgList= Get-AllOrgs
            $OrgNames = $OrgList.login
            $OrgNames
                foreach ($OrgName in $OrgNames) {
                    Write-Output "Checking repo $RepoName in $OrgName" -Verbose
                    $Repodetails = Get-Repository -OrgName $OrgName -RepoName $RepoName
                    $Repodetails
                    if ($Repodetails) {
                        $RepoID = $Repodetails.id
                        $RepoID
                        Write-Output "$RepoName found, invoking secret check & update... " -Verbose
                        Update-Secret -OrgName $OrgName -SPN $UKSPN -RepoName $RepoName -RepoID $RepoID -Region $Region -Environment $Environment
                        Write-Output "Secret Update Completed... " -Verbose

                    }
                    else {
                        Write-Output "$RepoName does not exists... " -Verbose
                    }
                    

                }
            }
        }

}

catch {
    throw $_;
    continue;
}