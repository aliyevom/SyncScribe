#App Registration Pattern and Key Vault for US and UK Regions
[CmdletBinding(SupportsShouldProcess)]
Param(
[string]$RegionPattern ,
[string]$RegionKeyVaultName
)
$ErrorActionPreference = 'Stop'

#Get Current Date
$CurrentDate = Get-Date

Write-Verbose "Checking for Azure Entra module..." -Verbose

$AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

if ($AzModule -eq $null) {

    Write-Verbose "Azure Entra PowerShell module not found" -Verbose
    #Logging into Azure Entra
    Install-Module -Name "Microsoft.Entra" -Force
    Import-Module -Name "Microsoft.Entra" -Force
}
else {
    Import-Module -Name "Microsoft.Entra" -Force
}
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken

$secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
Connect-Entra -AccessToken $secureString

#Checks the expiration days of the App registration
$ExpiryDaysNumber =31

#Pulls all the AD Applications
$ALL_AZADApplications = Get-EntraApplication -all:$true | sort-object displayname

$global:ExpiredApps = $null

#Renewal of App Registrations which are about to Expire.
ForEach($AZADApplication in $ALL_AZADApplications){
    $ADDisplayname = $AZADApplication.displayname
    $ADObjectID = $AZADApplication.objectID
    if ($ADDisplayname -like $RegionPattern) {
        $Secrets = $AZADApplication | Select-Object -ExpandProperty passwordcredentials
        foreach ($Secret in $Secrets) {
            $EndDate = $secret.enddate
            $Operation = $EndDate - $CurrentDate
            $ExpiryDays = $Operation.Days
            if (($ExpiryDays -le $ExpiryDaysNumber) -and ($ExpiryDays -ge 0)) {        
                $ExpiredApps =  $ADDisplayname + "," + $ExpiredApps
                Write-Host $ADDisplayname
                $ADKeyID = $Secret.KeyId
                $PasswordCredential = New-EntraApplicationPasswordCredential -ObjectId $ADObjectID -StartDate $CurrentDate -EndDate $CurrentDate.AddYears(2) -CustomKeyIdentifier "RenewedbyAutomation"
                $Password = ConvertTo-SecureString -string $PasswordCredential.Value -AsPlainText -Force
                $KVSecret = Set-AzKeyVaultSecret -VaultName $RegionKeyVaultName -Name "$ADDisplayname-Password" -SecretValue $Password
                Remove-AzADAppCredential -ObjectId $ADObjectID -KeyId $ADKeyID -Confirm:$false

            }
        }
    }
}
Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'appExpiredSecret;issecret=false;isOutput=true', $ExpiredApps)
