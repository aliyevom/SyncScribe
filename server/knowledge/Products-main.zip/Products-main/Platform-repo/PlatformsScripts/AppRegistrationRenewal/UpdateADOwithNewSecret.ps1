[CmdletBinding(SupportsShouldProcess)]
Param(
    [string]$USSPNs,
    [string]$UKSPNs,
    [string]$Step
    )
    $ErrorActionPreference = 'Stop'
    $USSPNs11 = $USSPNs.TrimEnd()
    $USSPNs12 =$USSPNs11.Split(",")
    $USSPNs12.Length
    $USSPNs1= $USSPNs12 | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    $UKSPNs11 = $UKSPNs.TrimEnd()
    $UKSPNs12 =$UKSPNs11.Split(",")
    $UKSPNs12.Length
    $UKSPNs1 = $UKSPNs12 | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    #$USSPNs1 = "US-225063-DEV-01-SPN"
function Update-AzAdoArmServiceConnectionShared {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ServiceConnectionID,
        [Parameter(Mandatory = $false)] [string] $SubscriptionId,
        [Parameter(Mandatory = $false)] [string] $SubscriptionName,
        [Parameter(Mandatory = $false)] [string] $ServiceConnectionName,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalId,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalKey,
        [Parameter(Mandatory = $false)] [string] $ProjectId,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $SCType
    )
    $ErrorActionPreference = "continue";
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Basic $token")
    try {

$body = @"
{
            `"data`": {
                `"subscriptionId`": `"$SubscriptionId`",
                `"subscriptionName`": `"$SubscriptionName`",
                `"environment`": `"AzureCloud`",
                `"scopeLevel`": `"Subscription`",
                `"creationMode`": `"Manual`"
            },
            `"id`": `"$ServiceConnectionID`",
            `"name`": `"$ServiceConnectionName`",
            `"type`": `"AzureRM`",
            `"url`": `"https://management.azure.com/`",
            `"description`": `"$ServiceConnectionName`",
            `"authorization`": {
                `"parameters`": {
                    `"tenantid`": `"f98a6a53-25f3-4212-901c-c7787fcd3495`",
                    `"serviceprincipalid`": `"$ServicePrincipalId`",
                    `"authenticationType`": `"spnKey`",
                    `"serviceprincipalkey`": `"$ServicePrincipalKey`"
                },
                `"scheme`": `"ServicePrincipal`"
            },
            `"isShared`": `"$SCType`",
            `"isReady`": true,
            `"owner`": `"Library`",
            `"serviceEndpointProjectReferences`": [
            ]
        }
"@

Write-Debug $body
$URI = "https://dev.azure.com/" +$OrganizationName+ "/_apis/serviceendpoint/endpoints/" + $ServiceConnectionID + "?api-version=6.1-preview.4"

$params = @{
    Method          = 'PUT'
    Body            = $body
    UseBasicParsing = $true
    Headers         = $headers
    Uri             = $URI
    ContentType     = 'application/json'
};
$response = Invoke-RestMethod @params

$response

    }
    catch {
        throw $_
    }

    return $response.value 
}

function Update-AzAdoArmServiceConnection {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ServiceConnectionID,
        [Parameter(Mandatory = $false)] [string] $SubscriptionId,
        [Parameter(Mandatory = $false)] [string] $SubscriptionName,
        [Parameter(Mandatory = $false)] [string] $ServiceConnectionName,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalId,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalKey,
        [Parameter(Mandatory = $false)] [string] $ProjectId,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $SCType
    )
    $ErrorActionPreference = "continue";
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Basic $token")
    try {

$body = @"
{
            `"data`": {
                `"subscriptionId`": `"$SubscriptionId`",
                `"subscriptionName`": `"$SubscriptionName`",
                `"environment`": `"AzureCloud`",
                `"scopeLevel`": `"Subscription`",
                `"creationMode`": `"Manual`"
            },
            `"id`": `"$ServiceConnectionID`",
            `"name`": `"$ServiceConnectionName`",
            `"type`": `"AzureRM`",
            `"url`": `"https://management.azure.com/`",
            `"description`": `"$ServiceConnectionName`",
            `"authorization`": {
                `"parameters`": {
                    `"tenantid`": `"f98a6a53-25f3-4212-901c-c7787fcd3495`",
                    `"serviceprincipalid`": `"$ServicePrincipalId`",
                    `"authenticationType`": `"spnKey`",
                    `"serviceprincipalkey`": `"$ServicePrincipalKey`"
                },
                `"scheme`": `"ServicePrincipal`"
            },
            `"isShared`": `"$SCType`",
            `"isReady`": true,
            `"owner`": `"Library`",
            `"serviceEndpointProjectReferences`": [
                {
                    `"projectReference`": {
                        `"id`": `"$ProjectId`",
                        `"name`": `"$ProjectName`"
                    },
                    `"name`": `"$ServiceConnectionName`"
                }
            ]
        }
"@

Write-Debug $body
$URI = "https://dev.azure.com/" +$OrganizationName+ "/_apis/serviceendpoint/endpoints/" + $ServiceConnectionID + "?api-version=6.1-preview.4"

$params = @{
    Method          = 'PUT'
    Body            = $body
    UseBasicParsing = $true
    Headers         = $headers
    Uri             = $URI
    ContentType     = 'application/json'
};
$response = Invoke-RestMethod @params

$response

    }
    catch {
        throw $_
    }

    return $response.value 
}

function Get-AzAllAdoProject {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName
    )
    try {
        Write-Verbose "Querying for the Azure DevOps project"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/_apis/projects?api-version=7.0"
            ContentType     = 'application/json'
        }; $output = Invoke-RestMethod @params
    }
    catch {
        throw $_
    }
       
    return $output.value
}
#$OrganizationName ="NGRID"
#$AllProjects =Get-AzAllAdoProject -OrganizationName $OrganizationName
#$AllProjects

function Get-AllAzAdoArmServiceConnection {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName
    )
    $URI = "https://dev.azure.com/" +$OrganizationName +"/" + $ProjectName + "/_apis/serviceendpoint/endpoints?type=AzureRM&?api-version=7.0"
    try {
        Write-Verbose "Querying all the ARM Service EndPoints"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = $URI
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params
    }
    catch {
        throw $_
    }
        
    return $output
}
    
$OrganizationName = "ngrid"
#$ProjectName ="CCOE"
#$ListallSCs= Get-AllAzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $ProjectName
#$ListallSCs
function Get-AzAdoArmServiceConnection {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalName
    )
    $URI ="https://dev.azure.com/"+$OrganizationName +"/"+$ProjectName +"/_apis/serviceendpoint/endpoints?endpointNames="+$ServicePrincipalName +"&api-version=7.0"  
    try {
        Write-Verbose "Querying for the ARM Service EndPoint Existence"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = $URI
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params
    }
    catch {
        throw $_
    }
        
    return $output
}


#$USSPNs = 'US-spoketest-01-SPN', 'US-1234-PROD-07-SPN','US-CCOE-HUBTEST-01-SPN'


$OrganizationName = 'NGRID'
$USKeyVaultName = 'ng-prd-eus2-kv-01'
$UKKeyVaultName = 'ng-prd-uks-kv-01'
$PATSecretName = 'GBL-SVC-ADOServiceAccount-PAT'
Write-Output "provided US SPNS are $($USSPNs1)"
Write-Output "provided UK SPNS are $($UKSPNs1)"
try {
#US SPN Update
    if (($USSPNs1) -and ($Step -eq "US")) {
        Set-AzContext -Subscription "US-HUB-Prod-01"
        $USPAT = `
            Get-AzKeyVaultSecret `
            -VaultName $USKeyVaultName `
            -Name $PATSecretName `
            -ErrorAction SilentlyContinue;
        Write-Output "getting  US PAT  from KV " -Verbose
        $USPATValue = $USPAT.SecretValue
        if($USPATValue)
        {
        $USPATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($USPAT.SecretValue)
        $USPATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($USPATSecret)
        }
        else {
            {Write-Output "PAT is not found. please check the PAT Secret Value"}
        }
        $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($USPATSecretText)"))
        $header = @{authorization = "Basic $token" }
        $AllADOProjectslist = Get-AzAllAdoProject -OrganizationName $OrganizationName

        $AllADOProjectName = $AllADOProjectslist.Name
        $AllADOProjectName
        Set-AzContext -Subscription "US-HUB-Prod-01"
        foreach ($USSPN in $USSPNs1) {
            Set-AzContext -Subscription "US-HUB-Prod-01"
            Write-Output "Provided SPN is $USSPN"
            $USKVAPPIDName = $USSPN + "-appId"
            $USappID = `
                Get-AzKeyVaultSecret `
                -VaultName $USKeyVaultName `
                -Name $USKVAPPIDName `
                #-ErrorAction SilentlyContinue;
            Write-Output "getting APP ID  from KV $USappID " -Verbose
            $USKVAPPPSWDName = $USSPN + "-Password"
            $USspnPassword = `
                Get-AzKeyVaultSecret `
                -VaultName $USKeyVaultName `
                -Name $USKVAPPPSWDName `
                #-ErrorAction SilentlyContinue;
            #$spnPassword = `
            #If (($null -ne $appID) -and ($null -ne $spnPassword)) {
                If ($null -ne $USappID) {
                $USApplicationID = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($USappID.SecretValue)
                $USApplicationIDText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($USApplicationID)
                $USApplicationIDText
                Write-Output "SPN - $USApplicationIDText and Password exists in key vault " -Verbose
                $USServicePrincipalPasswd = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($USspnPassword.SecretValue)
                $USServicePrincipalPasswdText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($USServicePrincipalPasswd)
                #$USServicePrincipalPasswdText
                #$USSPN='US-CCOE-HUBTEST-01-SPN'
                $USServiceConnectionName = $USSPN.Substring(0, $USSPN.lastIndexOf('-'))
                $USServiceConnectionName = $ServiceConnectionName + "-SC"
                #$USServiceConnectionName
            
                foreach ($project in $AllADOProjectName) {
                    Write-Output "executing project loop $project $OrganizationName" -Verbose
                    $ServiceConnectionslist = Get-AllAzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $Project -ErrorAction SilentlyContinue
                    $ServiceConnectionslist
                    $ServiceConnections = $ServiceConnectionslist.value

                    
                    If ($ServiceConnections)  {
                        <#
                    foreach ($ServiceConnection in $ServiceConnections) {
                        $ServiceConnectionID =$ServiceConnection.authorization.parameters.serviceprincipalid
                        Write-Output "SPN ID $ServiceConnectionID"
                        $ServiceConnectionName =$ServiceConnection.Name
                        Write-Output "SPN Name $ServiceConnectionName"
                        if($ServiceConnectionID -eq $ApplicationIDText)
                        {
                        $SCDetails = Get-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $project -ServicePrincipalName $ServiceConnectionName -ErrorAction SilentlyContinue
                        $SCDetails
                    }
                    }
                    #>
                }
                    foreach ($ServiceConnection in $ServiceConnections) {
                        
                        $ServicePrincipalId =$ServiceConnection.authorization.parameters.serviceprincipalid
                        Write-Output "SPN ID $ServicePrincipalId" -Verbose
                        $ServiceConnectionName =$ServiceConnection.Name
                        Write-Output "SPN Name $ServiceConnectionName" -Verbose
                        #If(($ServiceConnectionName -eq $ServicePrincipalName) -or ($ServiceConnectionID -eq $ServicePrincipalId))
                        If ($ServicePrincipalId -eq $USApplicationIDText) {
                            Write-Output "Match found  $ServicePrincipalId $USApplicationIDText" -Verbose
                            #get service connection details
                            $SCDetails = Get-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $project -ServicePrincipalName $ServiceConnectionName -ErrorAction SilentlyContinue
                            Write-Output "SCDetails $SCDetails" -Verbose
                            $SCServiceConnectionID = ($SCDetails.value.Id).ToString()
                            Write-Output "SCServiceConnectionID $SCServiceConnectionID" -Verbose
                            $SCServiceprincipalID = ($SCDetails.value.authorization.parameters.serviceprincipalid).ToString()
                            Write-Output "SCServiceprincipalID $SCServiceprincipalID "
                            $ServiceConnectionName = ($SCDetails.value.name).ToString()
                            Write-Output "ServiceConnectionName   $ServiceConnectionName"
                            $SCSubsID = ($SCDetails.value.data.subscriptionId).ToString()
                            Write-Output "SCSubsID $SCSubsID "
                            $SCSubsName = ($SCDetails.value.data.subscriptionName).ToString()
                            Write-Output "SCSubsName $SCSubsName"
                            $SCProjectName = ($SCDetails.value.serviceEndpointProjectReferences.projectReference.name).ToString()
                            Write-Output "SCProjectName $SCProjectName"
                            $SCProjectId = ($SCDetails.value.serviceEndpointProjectReferences.projectReference.id).ToString()
                            Write-Output "SCProjectId $SCProjectId"
                            $SCOrgName = $OrganizationName
                            Write-Output "SCOrgName $SCOrgName"
                            $SCKey = $USServicePrincipalPasswdText.ToString()
                            #Write-Output "ServicePrincipalPasswdText $ServicePrincipalPasswdText"
                            #Write-Output "SCKey $SCKey"
                            $SCType = $SCDetails.value.isShared
                            Write-Output "SCType $SCType"

                            #$serviceEndpointProjectReferences = $SCDetails.value.serviceEndpointProjectReferences.projectReference[0]

                            #Write-Output "serviceEndpointProjectReferences $serviceEndpointProjectReferences"

                            #Update Service Connection Credential
                            <##>
                            if($SCType -eq "True")
                            {
                                Write-Output "updating Shared Service connection"
                                Update-AzAdoArmServiceConnectionShared -OrganizationName "$SCOrgName"`
                                -ServiceConnectionID "$SCServiceConnectionID"`
                                -SubscriptionId "$SCSubsID"`
                                -SubscriptionName "$SCSubsName"`
                                -ServiceConnectionName "$ServiceConnectionName"`
                                -ServicePrincipalId "$SCServiceprincipalID"`
                                -ServicePrincipalKey "$SCKey"`
                                -ProjectId "$SCProjectId"`
                                -ProjectName "$SCProjectName"`
                                -SCType "$SCType"`
                                -ErrorAction SilentlyContinue
                            }
                            else {
                                <# Action when all if and elseif conditions are false #>
                            Write-Output "updating Service connection"
                            Update-AzAdoArmServiceConnection -OrganizationName "$SCOrgName"`
                            -ServiceConnectionID "$SCServiceConnectionID"`
                            -SubscriptionId "$SCSubsID"`
                            -SubscriptionName "$SCSubsName"`
                            -ServiceConnectionName "$ServiceConnectionName"`
                            -ServicePrincipalId "$SCServiceprincipalID"`
                            -ServicePrincipalKey "$SCKey"`
                            -ProjectId "$SCProjectId"`
                            -ProjectName "$SCProjectName"`
                            -SCType "$SCType"`
                            -ErrorAction SilentlyContinue
                            }
                            <#
                            Update-AzAdoArmServiceConnection -OrganizationName 'NGRID'`
                                 -ServiceConnectionID "dc7fca06-af61-4d5b-a098-15b76a96ff57"`
                                 -SubscriptionId "dc7fca06-af61-4d5b-a098-15b76a96ff57"`
                                 -SubscriptionName "US-CCOE-SPOKETEST-01"`
                                 -ServiceConnectionName "US-CCOE-SPOKETEST-01-SC"`
                                 -ServicePrincipalId "99e684d8-9213-49e2-bc42-c53a3cae8ab0"`
                                 -ServicePrincipalKey "2exff5umn6awt4qzu3epl4iwvamtwzmx4ph7yczfu6izg46g3xma"`
                                 -ProjectId "9f18389c-6ba3-4cb5-b074-a0e925c5a41e"`
                                 -ProjectName "US-CCOE-ADOProject-01"
                                 #>
                            #Update-AzAdoArmServiceConnection -OrganizationName $SCOrgName -ProjectName $SCProjectName -SubscriptionId $SCSubsID -SubscriptionName $SCSubsName -TenantId $SCTenantID -ServicePrincipalName $ServiceConnectionName -ServicePrincipalId $ServiceConnectionID -ServicePrincipalKey $SCKey -ErrorAction SilentlyContinue

                        }

                    }

                }

                #
            }
            else{
                Write-Output "SPN or Password does not exist in Key vault. Please check..."
            }
        }

    }

#UK SPN update
    if (($UKSPNs1) -and ($Step -eq "UK")) {
        Set-AzContext -Subscription "UK-HUB-Prod-01"
        $UKPAT = `
            Get-AzKeyVaultSecret `
            -VaultName $UKKeyVaultName `
            -Name $PATSecretName `
            -ErrorAction SilentlyContinue;
        Write-Output "getting UK PAT  from KV $UKPAT" -Verbose
        $UKPAT
        $UKPATValue = $UKPAT.SecretValue
        if($UKPATValue)
        {
        $UKPATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($UKPAT.SecretValue)
        $UKPATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($UKPATSecret)
        #$UKPATSecretText
        }
        else{

                {Write-Output "PAT is not found. please check the PAT Secret Value"}
        }
        $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($UKPATSecretText)"))
        $header = @{authorization = "Basic $token" }
        $AllADOProjectslist = Get-AzAllAdoProject -OrganizationName $OrganizationName

        $AllADOProjectName = $AllADOProjectslist.Name
        $AllADOProjectName
        #$UKSPNs ="UK-00141A-fof-01-SPN"
        foreach ($UKSPN in $UKSPNs1) {
            Write-Output "Provided SPN is $UKSPN"
            Set-AzContext -Subscription "UK-HUB-Prod-01"
            $UKKVAPPIDName = $UKSPN + "-appId"
            $UKappID = Get-AzKeyVaultSecret -VaultName $UKKeyVaultName -Name $UKKVAPPIDName -ErrorAction SilentlyContinue;
            Write-Output "getting APP ID  from KV $UKappID " -Verbose
            $UKKVSPNPswrd = $UKSPN + "-Password"
            $UKspnPassword = Get-AzKeyVaultSecret -VaultName $UKKeyVaultName -Name $UKKVSPNPswrd -ErrorAction SilentlyContinue;
            #If (($null -ne $appID) -and ($null -ne $spnPassword)) {
                If ($null -ne $UKappID)  {
                $UKApplicationID = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($UKappID.SecretValue)
                $UKApplicationIDText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($UKApplicationID)
                $UKApplicationIDText
                Write-Output "SPN - $UKApplicationIDText and Password exists in key vault " -Verbose
                $UKServicePrincipalPasswd = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($UKspnPassword.SecretValue)
                $UKServicePrincipalPasswdText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($UKServicePrincipalPasswd)
                #$UKServicePrincipalPasswdText
                #$USSPN='US-CCOE-HUBTEST-01-SPN'
                $UKServiceConnectionName = $UKSPN.Substring(0, $UKSPN.lastIndexOf('-'))
                $UKServiceConnectionName = $UKServiceConnectionName + "-SC"
                #$UKServiceConnectionName
            
                foreach ($project in $AllADOProjectName) {
                    Write-Output "executing project loop $project $OrganizationName" -Verbose
                    $ServiceConnectionslist = Get-AllAzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $Project -ErrorAction SilentlyContinue
                    $ServiceConnectionslist
                    $ServiceConnections = $ServiceConnectionslist.value
                    foreach ($ServiceConnection in $ServiceConnections) {
                        
                        $ServicePrincipalId =$ServiceConnection.authorization.parameters.serviceprincipalid
                        Write-Output "SPN ID $ServicePrincipalId" -Verbose
                        $ServiceConnectionName =$ServiceConnection.Name
                        Write-Output "SPN Name $ServiceConnectionName" -Verbose
                        #If(($ServiceConnectionName -eq $ServicePrincipalName) -or ($ServiceConnectionID -eq $ServicePrincipalId))
                        If ($ServicePrincipalId -eq $UKApplicationIDText) {
                            Write-Output "Match found  $ServicePrincipalId $UKApplicationIDText" -Verbose
                            #get service connection details
                            $SCDetails = Get-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $project -ServicePrincipalName $ServiceConnectionName -ErrorAction SilentlyContinue
                            Write-Output "SCDetails $SCDetails" -Verbose
                            $SCServiceConnectionID = ($SCDetails.value.Id).ToString()
                            Write-Output "SCServiceConnectionID $SCServiceConnectionID" -Verbose
                            $SCServiceprincipalID = ($SCDetails.value.authorization.parameters.serviceprincipalid).ToString()
                            Write-Output "SCServiceprincipalID $SCServiceprincipalID "
                            $ServiceConnectionName = ($SCDetails.value.name).ToString()
                            Write-Output "ServiceConnectionName   $ServiceConnectionName"
                            $SCSubsID = ($SCDetails.value.data.subscriptionId).ToString()
                            Write-Output " SCSubsID $SCSubsID "
                            $SCSubsName = ($SCDetails.value.data.subscriptionName).ToString()
                            Write-Output "SCSubsName $SCSubsName"
                            $SCProjectName = ($SCDetails.value.serviceEndpointProjectReferences.projectReference.name).ToString()
                            Write-Output "SCProjectName $SCProjectName"
                            $SCProjectId = ($SCDetails.value.serviceEndpointProjectReferences.projectReference.id).ToString()
                            Write-Output "SCProjectId $SCProjectId"
                            $SCOrgName = $OrganizationName
                            Write-Output "SCOrgName $SCOrgName"
                            $SCKey = $UKServicePrincipalPasswdText
                            #Write-Output "ServicePrincipalPasswdText $UKServicePrincipalPasswdText"
                            #Write-Output "SCKey $SCKey"
                            $SCType = $SCDetails.value.isShared
                            Write-Output "SCType $SCType"
                            Write-Output "updating Service connection"
                            #Update Service Connection Credential
                            <##>
                            if($SCType -eq "True")
                            {
                            Write-Output "updating shared Service connection"
                            Update-AzAdoArmServiceConnectionShared -OrganizationName "$SCOrgName"`
                            -ServiceConnectionID "$SCServiceConnectionID"`
                            -SubscriptionId "$SCSubsID"`
                            -SubscriptionName "$SCSubsName"`
                            -ServiceConnectionName "$ServiceConnectionName"`
                            -ServicePrincipalId "$SCServiceprincipalID"`
                            -ServicePrincipalKey "$SCKey"`
                            -ProjectId "$SCProjectId"`
                            -ProjectName "$SCProjectName"`
                            -SCType "$SCType"`
                            -ErrorAction SilentlyContinue
                            }
                            else {
                                Write-Output "updating Service connection"
                                Update-AzAdoArmServiceConnection -OrganizationName "$SCOrgName"`
                                -ServiceConnectionID "$SCServiceConnectionID"`
                                -SubscriptionId "$SCSubsID"`
                                -SubscriptionName "$SCSubsName"`
                                -ServiceConnectionName "$ServiceConnectionName"`
                                -ServicePrincipalId "$SCServiceprincipalID"`
                                -ServicePrincipalKey "$SCKey"`
                                -ProjectId "$SCProjectId"`
                                -ProjectName "$SCProjectName"`
                                -SCType "$SCType"`
                                -ErrorAction SilentlyContinue
                                }
                            <#
                            Update-AzAdoArmServiceConnection -OrganizationName 'NGRID'`
                                 -ServiceConnectionID "dc7fca06-af61-4d5b-a098-15b76a96ff57"`
                                 -SubscriptionId "dc7fca06-af61-4d5b-a098-15b76a96ff57"`
                                 -SubscriptionName "US-CCOE-SPOKETEST-01"`
                                 -ServiceConnectionName "US-CCOE-SPOKETEST-01-SC"`
                                 -ServicePrincipalId "99e684d8-9213-49e2-bc42-c53a3cae8ab0"`
                                 -ServicePrincipalKey "2exff5umn6awt4qzu3epl4iwvamtwzmx4ph7yczfu6izg46g3xma"`
                                 -ProjectId "9f18389c-6ba3-4cb5-b074-a0e925c5a41e"`
                                 -ProjectName "US-CCOE-ADOProject-01"
                                 #>
                            #Update-AzAdoArmServiceConnection -OrganizationName $SCOrgName -ProjectName $SCProjectName -SubscriptionId $SCSubsID -SubscriptionName $SCSubsName -TenantId $SCTenantID -ServicePrincipalName $ServiceConnectionName -ServicePrincipalId $ServiceConnectionID -ServicePrincipalKey $SCKey -ErrorAction SilentlyContinue

                        }

                    }

                }

                #
            }
            else{
                Write-Output "SPN or Password does not exist in Key vault. Please check..."
            }
        }

    }

}

catch {
    throw $_;
    continue;
}