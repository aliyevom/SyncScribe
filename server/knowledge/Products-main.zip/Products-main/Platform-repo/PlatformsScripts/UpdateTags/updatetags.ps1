[CmdletBinding(SupportsShouldProcess)]
param(
    [String] $ApplicationID,
    [String] $BusinessUnit,
    [String] $BusinessUnit1,
    [String] $CompanyCode,
    [String] $CostCenter,
    [String] $Environment,
    [String] $FinancialOwner,
    [String] $FinancialRTB,
    [String] $InternalOrWorkOrder,
    [String] $OperationsCode,
    [String] $ProjectCode,
    [String] $ProjectManager,
    [String] $ProjectName,
    [String] $RTBSupport,
    [String] $ServiceOwner,
    [String] $WBSCode,
    [String] $subscriptionName,
    [string] $region
)
Write-Output 'Setting the Context to the Subscription ' $subscriptionName
Set-AzContext -Subscription $subscriptionName
$subId = (Get-AzContext).Subscription.id

try {
    if ($region -eq 'UK') {
        Write-Output " It is a UK region"
        $tags = @{ "Application ID"=$ApplicationID ; "Business Unit"= $BusinessUnit ; "Business Unit 1"= $BusinessUnit1 ; "Company Code"=$CompanyCode ; "Cost Center"= $CostCenter;  "Environment"=$Environment; "Financial Owner"=$FinancialOwner ; "Financial RTB"=$FinancialRTB ; "WBS Code"=$WBSCode ; "Project Code"=$ProjectCode ; "Project Manager"=$ProjectManager ; "Project Name"= $ProjectName; "RTB Support"=$RTBSupport ; "Service Owner"= $ServiceOwner; }
    }
    else{
        Write-Output " It is not for UK region"
        $tags = @{ "Application ID"=$ApplicationID ; "Business Unit"= $BusinessUnit ; "Business Unit 1"= $BusinessUnit1 ; "Company Code"=$CompanyCode ; "Cost Center"= $CostCenter;  "Environment"=$Environment; "Financial Owner"=$FinancialOwner ; "Financial RTB"=$FinancialRTB ; "Internal or Work Order"=$InternalOrWorkOrder ; "Operations Code (WO)"=$OperationsCode ; "Project Code"=$ProjectCode ; "Project Manager"=$ProjectManager ; "Project Name"= $ProjectName; "RTB Support"=$RTBSupport ; "Service Owner"= $ServiceOwner; }
    }
    Write-Output " Updating the Sub " $subscriptionName " with the tags " $tags
    Update-AzTag -ResourceId /subscriptions/$subId -Tag $tags -Operation Replace
    Write-Output "Tags Updated successfully for the Subscription " $subscriptionName

}
catch {
    Write-Output " Got an Error while updating the tags"
    throw $_
}
