<#
.SYNOPSIS
Send Pipeline Execution Errors to Log Analytics

.DESCRIPTION
The script below uses a rest api call to send custom log data to Log Analytics with the HTTP Data Collector API

.PARAMETER lawsSubscriptionId
Log Analytics Subscription ID

.PARAMETER payload
Payload in the format below
              [{  "category": "AzureBastion",
                  "details": "$(details)",
                  "buildDefinitionName" :"$(Build.DefinitionName)",
                  "buildDefinitionId" : "$(System.DefinitionId)",
                  "buildId" : "$(Build.BuildId)",
                  "agentJobStatus": "Failed"
              }]
              "@
.PARAMETER keyVaultName
Keyvault to get LAW secrets 

.PARAMETER workspaceID
LAW ID secret name

.PARAMETER workSpacePrimaryKey
LAW Primary key secret name

.PARAMETER logTable
Allows us to specify the name of the message/log table name that is being submitted. 
It does not support numerics or special characters

.EXAMPLE

#>
# Main Function
Function Set-PipelineLogs {
    Param(
        [Parameter(Mandatory = $false)][string]$lawsSubscriptionId = "74d15849-ba7b-4be6-8ba1-330a178ba88d",
        [parameter(Mandatory = $true)]$payLoad,
        [Parameter(Mandatory = $false)][string]$keyVaultName = "ng-prd-eus2-kv-01",
        [Parameter(Mandatory = $false)][string]$workspaceID = "LaWorkspaceId",
        [Parameter(Mandatory = $false)][string]$workSpacePrimaryKey = "LaWorkSpacePrimaryKey",
        [Parameter(Mandatory = $false)][string]$logTable = "PipelineExecutionLogs"
    
    )
    try {

        Set-AzContext -Subscription $lawsSubscriptionId
        $ID = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $workspaceID
        $PrimaryKey = Get-AzKeyVaultSecret -VaultName  $keyVaultName -Name $workSpacePrimaryKey

        $workspaceIDSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ID.SecretValue)
        $workspaceIDSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($workspaceIDSecret)
        
        $workSpacePrimaryKeySecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PrimaryKey.SecretValue)
        $workSpacePrimaryKeySecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($workSpacePrimaryKeySecret)

        Write-Verbose "Post to log analytics workspace with data:$payLoad" -Verbose
        PostLogAnalyticsData -customerId $workspaceIDSecretText -sharedKey $workSpacePrimaryKeySecretText -body ([System.Text.Encoding]::UTF8.GetBytes($payLoad)) -logType $logTable -Verbose

    }
    catch {
        throw $_
    
    }
}

# Create authorization signature
Function BuildSignature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource) {
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId, $encodedHash
    return $authorization
}


# Function to post the request
Function PostLogAnalyticsData($customerId, $sharedKey, $body, $logType) {
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = BuildSignature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"
    $headers = @{
        "Authorization"        = $signature;
        "Log-Type"             = $logType;
        "x-ms-date"            = $rfc1123date;
        "time-generated-field" = $rfc1123date;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response

}

