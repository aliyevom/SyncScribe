<#
.SYNOPSIS
Add requestor to appropriate security group for Bastion Host access.

.DESCRIPTION
Add requestor to appropriate security group for Bastion Host access.
User is added to US or UK Bastion Reader Secruity Groups which provide them reader access on US/UK Bastion Hosts

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be added to group

.PARAMETER geo
Mandatory. US/UK regions

.EXAMPLE

#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ownerEmailAddress,
    [string]$geo
)
$ErrorActionPreference = 'Stop'
try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose

    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable
    
    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString

    if ($ownerEmailAddress -like "*us.nationalgrid.com") {
        $userPrincipal = $ownerEmailAddress
        $userDetails = Get-EntraUser -Filter "userPrincipalName eq '$userPrincipal'"
        $userObjectID = $userDetails.ObjectId 
    }
    elseif ($ownerEmailAddress -like "*uk.nationalgrid.com") {
        $userPrincipal = $ownerEmailAddress
        $userDetails = Get-EntraUser -Filter "userPrincipalName eq '$userPrincipal'"
        $userObjectID = $userDetails.ObjectId 
    }
    else {
        $upn = Get-EntraUser -Filter "mail eq '$ownerEmailAddress'"
        $userPrincipal = $upn.UserPrincipalName
        $userObjectID = $upn.ObjectId 
    }
    Write-Verbose "UPN is $userPrincipal" -Verbose
    Write-Verbose "User ObjectID is $userObjectID" -Verbose

    if ($geo -eq "US") {
        $bastionGroup = Get-EntraGroup -SearchString "US-BASTION-Reader"
        $bastionGroupObjectID = (Get-EntraGroup -SearchString "US-BASTION-Reader").ObjectId
        $Members = $bastionGroup | Get-EntraGroupMember -All $true
        $IsUserInGroup = $Members.ObjectID -contains $userObjectID
        Write-Verbose "Bastion Group ObjectID is $bastionGroupObjectID" -Verbose
        if (-not $IsUserInGroup) {
            Write-Verbose "Adding to US Bastion Reader Group" -Verbose
            Add-EntraGroupMember -ObjectId $bastionGroupObjectID  -RefObjectId $userObjectID -Verbose
        }
        else {
            Write-Warning "User is already part of US Bastion Reader Group" -Verbose
        }
    }

    if ($geo -eq "UK") {
        $bastionGroup = Get-Entra Group -SearchString "UK-BASTION-Reader"
        $bastionGroupObjectID = (Get-EntraGroup -SearchString "UK-BASTION-Reader").ObjectId
        $Members = $bastionGroup | Get-EntraGroupMember -All $true
        $IsUserInGroup = $Members.ObjectID -contains $userObjectID
        Write-Verbose "Bastion Group ObjectID is $bastionGroupObjectID" -Verbose
        if (-not $IsUserInGroup) {
            Write-Verbose "Adding to UK Bastion Reader Group" -Verbose
            Add-EntraGroupMember -ObjectId $bastionGroupObjectID  -RefObjectId $userObjectID -Verbose
        }
        else {
            Write-Warning "User is already part of UK Bastion Reader Group" -Verbose
        }
    }
   

}
catch {
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'details', $Error[0])
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'details;issecret=false;isOutput=true', $Error[0])
    throw $_
}


