<#
.SYNOPSIS
Enable Just In Time VM access.
.DESCRIPTION
Automate Just in time VM request access with PowerShell.

Request-JIT VM Access -VMName [VMName] -Port [PortNumber] -AddressPrefix [AllowedSourceIP] -Time [Hours] -Verbose
This Pipeline will enable Just in Time VM Access for a particular Azure VM including the management port, source IP, and number of hours.
If Just in Time VM Access is not enabled, the tool will enable the policy for the VM, ADT need to provide the maximum requested time in hours.
If the specified management port is not set by the policy previously, the script will enable that port, and then request VM access.
If the time specified is greater than the time set by the policy, the script will force ADT to enter the valid time, and then request VM access.
#>

Function Invoke-JitRequest {
    param(
      [Parameter(Mandatory = $true)] [string] $geo,
      [Parameter(Mandatory = $true)] [string] $region,
      [Parameter(Mandatory = $true)] [string] $subscriptionId,
      [Parameter(Mandatory = $true)] [string] $resourceGroupName,
      [Parameter(Mandatory = $true)] [string] $VMName,
      [Parameter(Mandatory = $true)] [string] $Port,
      [Parameter(Mandatory = $true)] [string] $AddressPrefix,
      [Parameter(Mandatory = $true)] [string] $Time
    ) 

    Install-Module -Name Az.Security -Force
    
    # Get Current Date and Time
    $Date = (Get-Date).ToUniversalTime().AddHours($Time) 
    $endTimeUtc = Get-Date -Date $Date -Format o
    
      Set-AzContext -SubscriptionId $subscriptionId
      Write-Verbose "$subscriptionId" -Verbose      
      
      #! Enable Access to the VM including management Port, and Time Range in Hours
      $JitPolicy = (@{
        id = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Compute/virtualMachines/$VMName";
        ports=(@{
             number = $Port;
             protocol = "TCP";
             allowedSourceAddressPrefix = @("$AddressPrefix");
             maxRequestAccessDuration = "PT$($Time)H"
            })
        })
        $JitPolicyArr = @($JitPolicy)
        
        Write-Verbose "Enabling Just in Time VM Access Policy for ($VMName) on port number $Port for maximum $time hours..."
        Set-AzJitNetworkAccessPolicy -Kind "Basic" -Location $region -Name "default" -ResourceGroupName $resourceGroupName -VirtualMachine $JitPolicyArr
        $VMAccessPolicy = (Get-AzJitNetworkAccessPolicy).VirtualMachines | Where-Object {$_.Id -like "*$VMName*"} | Select-Object -ExpandProperty Ports
        $VMAccessPolicy

        #! Request Access to the VM including management Port, and Time Range in Hours
        $JitPolicyVm = (@{
            id="/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Compute/virtualMachines/$VMName";
            ports=(@{
               number = $Port;
               endTimeUtc = "$endTimeUtc";
               allowedSourceAddressPrefix = @("$AddressPrefix")
            })
        })

        $JitPolicyArr=@($JitPolicyVm)
        Start-AzJitNetworkAccessPolicy -ResourceId "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Security/locations/$region/jitNetworkAccessPolicies/default" -VirtualMachine $JitPolicyArr
        Write-Verbose "Enabling VM Request access for ($VMName) from IP Range $AddressPrefix on port number $Port for $Time hours..."

    }