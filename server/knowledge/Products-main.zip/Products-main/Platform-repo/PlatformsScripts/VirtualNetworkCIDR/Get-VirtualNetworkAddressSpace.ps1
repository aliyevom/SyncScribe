<#
.SYNOPSIS
Collection of functions to pull next available virtual Network and split into designated subnets

.DESCRIPTION
Collection of functions to pull next available virtual Network and split into designated subnets
It also checks if a address space has already been taken by a Subscription. If so it returns the already taken address space.
Allocated Virtual networks stored in Azure table designated by Geo-region and location. next available Virtual network for selected geo region and 
subnet size will be pulled.
The function will  to take an IP Address block and then breaks the Network into designated subnets. 
The address space must be in its CIDR format.

.PARAMETER IpAddress
Mandatory. The landing zone/vnet region (US or UK) .

.PARAMETER CIDR
Mandatory. The subnet CIDR for the selected Virtual network address space.

.EXAMPLE
Get-Subnet -IpAddress "192.168.0.0/24" -CIDR 26 


#>
Function Get-Subnet {

    param(
        [IPAddress]$IpAddress,
        [Int32]$CIDR
    )
    
    try { 
        
        $CIDRAddress = [System.Net.IPAddress]::Parse([System.Convert]::ToUInt64(("1" * $CIDR).PadRight(32, "0"), 2))
        $networkIdBinary = $IpAddress.Address -band $CIDRAddress.Address
        $networkId = [System.Net.IPAddress]::Parse([System.BitConverter]::GetBytes([UInt32]$networkIdBinary) -join ("."))
        $hostBits = ('1' * (32 - $CIDR)).padLeft(32, "0")       

        ###########################
        ## Convert Bits to Int64 ##
        ###########################
        $availableIPs = [Convert]::ToInt64($hostBits, 2) + 1
            
        $result = [pscustomobject] @{
            NetworkID = $networkId
            IPs       = $AvailableIPs
        }
    }
    catch {
        throw $_
    }

    Return  $result
    
}
<#
# Function Convert IpAddressToBase64
#   This function converts an IP address into its base 64 format to use for computing hosts and other computations
# 
# Input:
#   IpAddress:
#       The IP address to be converted
# 
# Output:
#   IP Address string
#>
Function Convert-IpAddressToBase64 {
    PARAM(
        [IPAddress]$IpAddress
    ) 

    $Octets = $IpAddress.ToString().Split(".")    
    $Int64 = [long]([long]$Octets[0] * 16777216 + [long]$Octets[1] * 65536 + [long]$Octets[2] * 256 + [long]$Octets[3]) 

    Return $Int64
}
<#
# Function Convert IpAddressToDot
#   This function converts an IP address into its dot format string
# 
# Input:
#   IpAddress:
#       The IP address to be converted
#
# Output:
#   IP Address string
#>
Function Convert-IpAddressToDot {
    PARAM(
        [long]$Int64
    ) 

    $ipAddress = [IPAddress](([System.Math]::Truncate($Int64 / 16777216)).ToString() + "." + `
        ([System.Math]::Truncate(($Int64 % 16777216) / 65536)).ToString() + "." + `
        ([System.Math]::Truncate(($Int64 % 65536) / 256)).ToString() + "." + `
        ([System.Math]::Truncate($Int64 % 256)).ToString())
     
    Return  $ipAddress 
}
<#
# Function Split VirtualNetwork 
# purpose to take an IP Address block and then breaks the Network into designated subnets
#
# Inputs:
#   addressPrefix:
#       This is an Azure vNet IP address space .
#   subnetCIDR:
#       The Subnets CIRD to break the Virtual Network IP block 
#
# Output:
#   Subnets List or Exception
#
#>
Function Split-VirtualNetwork {
    
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$addressPrefix,

        [Parameter(Mandatory)]
        [Int32]$subnetCIDR        
    )
      
    begin {
        Write-Debug ("{0} entered" -f $MyInvocation.MyCommand) 
    }
    
    process {

        try {
            $subnets = @{}
            [IPAddress]$IpAddress = ($addressPrefix -split '/')[0]
            [Int32]$vNetCIDR = ($addressPrefix -split '/')[1]
    
            if ($vNetCIDR -gt $subnetCIDR -or $vNetCIDR -le 0) {
                throw "Erorr | Subnet CIDR (/$subnetCIDR) can't be greater or equal than Virtual Network CIDR (/$vNetCIDR)"
            }
            else {
                ##################################
                ## Calculate the current Subnet ##
                ##################################

                $subnet = Get-Subnet -IpAddress $IpAddress -CIDR $vNetCIDR
    
                $NewHostBits = ('1' * (32 - $subnetCIDR)).PadLeft(32, "0")
                $NewAvailableIPs = ([Convert]::ToInt64($NewHostBits, 2) + 1)
                $networkId_Int64 = Convert-IpAddressToBase64 -IpAddress $Subnet.NetworkID

                ########################################
                ## Build and return a list of subnets ##
                ########################################
                $subnets = @()
                for ($i = 0; $i -lt $Subnet.IPs; $i += $NewAvailableIPs) {
                    $ipcidr = "{0}/{1}" -f (Get-Subnet -IpAddress (Convert-IpAddressToDot -Int64 ($NetworkID_Int64 + $i)) -CIDR $subnetCIDR).NetworkID.ToString(), $subnetCIDR
                    $subnets += $ipcidr

                }               
    
            }
            Return $subnets 
        }
        catch {
            throw $_
        }
    }
    
    end {
        Write-Debug ("{0} exited" -f $MyInvocation.MyCommand) 
    }
} 


<#
# Function Get AssignedPrefix 
# purpose to pull out an IP Address block from Nautobot assigned to a particular VNet
#
#>

function Get-AssignedPrefix {
    PARAM(
        [Parameter(Mandatory = $true)] [int] $VNetSize,
        [Parameter(Mandatory = $true)] [string] $RegionalLocationID,
        [Parameter(Mandatory = $true)] [string] $TenantID,
        [Parameter(Mandatory = $true)] [string] $TagID
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?locations=21c5eba0-8fa6-4605-91db-5d3aa64c30f5&prefix_length=27&tags=6cb68b63-e9fb-46b7-bc2d-f7cafad1b939&tenant=5c0de647-703b-461a-ae07-0ac7041f54d4&depth=1
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?locations=" + $RegionalLocationID + "&prefix_length=" + $VNetSize + "&tags=" + $TagID + "&tenant=" + $TenantID + "&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
#Get-AssignedPrefix -VNetSize 27 -RegionalLocationID "21c5eba0-8fa6-4605-91db-5d3aa64c30f5" -TenantID "5c0de647-703b-461a-ae07-0ac7041f54d4" -TagID "6cb68b63-e9fb-46b7-bc2d-f7cafad1b939"

<#
#Pull out the existing Geo Location Names from the Nautobot
#>

function Get-Location {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $Location
    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/dcim/locations/?name=2.0&depth=1
        $URI = "https://nautobot.dpit.nationalgrid.com/api/dcim/locations/?name=" + $Location + "&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Location -Location "eastus2" 

<#
#Pull out the existing VNETName Name Tag from the Nautobot
#>
function Get-Tag {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETName
    )
    $ErrorActionPreference = "Stop";
    $VNETName =$VNETName.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/extras/tags/?name=" + $VNETName + "&depth=1"

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Tag -VNETName $VNETName

<#
#VNET NAme is the Tag in Nautobot
#PAdd VNETName as Tag if it does not exists in the Nautobot
#>
function Add-Tag {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $VNETName
    )
    $VNETName = $VNETName.ToLower()
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
   {
    "name": `"$VNETName`",
    "object_type": "extras.tag",
    "content_types": [
        "ipam.prefix"
    ]
}
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/extras/tags/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}
#Add-Tag -VNETName "US-5874-QA-VNET-01"

<#
#Subscription Name is Tenant Name in Nautobot
#Pull out the existing Subscription Name from the Nautobot
#>
function Get-Tenant {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $SubscriptionName
    )
    $ErrorActionPreference = "Stop";
    $SubscriptionName =$SubscriptionName.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/?name=" + $SubscriptionName + "&depth=1"


        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#get-Tenant -SubscriptionName "US-5874-DEV-01" 
<#
#Add Subscription name in the Tenants if it does not exist in the Nautobot
#>
function Add-Tenant {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $SubscriptionName
    )
    $SubscriptionName =$SubscriptionName.ToLower()
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

    try {
        $body = @"
   {
     "name": `"$SubscriptionName`",
     "description": ""
   }
"@
        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?prefix=10.57.128.0/24&type=network
        $URI = "https://nautobot.dpit.nationalgrid.com/api/tenancy/tenants/"

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        throw $_
    }
    return $response.value
}
#Add-Tenant -SubscriptionName "US-5874-QA-01"

<#
#Pull out the existing /17 Address prefix from the Nautobot
#>
function Get-ParentPrefixes {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $RegionLocationID

    )
    $ErrorActionPreference = "Stop";
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")

   try {
#https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?locations=21c5eba0-8fa6-4605-91db-5d3aa64c30f5&locations=7238da28-d537-4664-9325-c1452e67e0b9&parent__isnull=false&prefix_length=17&status=5612ea68-1c4a-428a-8185-b31afa62869d&tags__isnull=true&tenant__isnull=true&type=container&depth=1
$URI ="https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/?locations=" + $RegionLocationID  + "&tags=Azure2&type=container&depth=1"

$params = @{
    Method          = 'GET'
    UseBasicParsing = $true
    Headers         = $headers
    Uri             = $URI
    ContentType     = 'application/json'
};
$response = Invoke-RestMethod @params

$response 
    }
    catch{
        #throw $_
    }
    return $response.value
}

#Get-ParentPrefixes

<#
#Pull out the Available IP block from the Nautobot for allocation
#>
function Allocate-Prefix {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $ParentPrefixID,
        [Parameter(Mandatory = $true)] [int] $SubnetSize,
        [Parameter(Mandatory = $true)] [string] $TenantID,
        [Parameter(Mandatory = $true)] [string] $LocationID,
        [Parameter(Mandatory = $true)] [string] $VNetName
    )

    $ErrorActionPreference = "Stop";
    $VNetName =$VNetName.ToLower()
    #$NBTPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    #$headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token $PATSecretText")
    $headers.Add("Accept", "application/json")

    try {
        $body = @"
        {
            `"prefix_length`": $SubnetSize,
            `"status`": `"Active`",
            `"tenant`": `"$TenantID`",
            `"location`" : `"$LocationID`",
            `"tags`" : [ `"$VNetName`" ]
        
        }
"@

        Write-Debug $body
        #https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/c7a98df5-6ae8-4e0d-abdf-77874fc73348/available-prefixes/?limit=200&depth=1
        $URI = "https://nautobot.dpit.nationalgrid.com/api/ipam/prefixes/" + $ParentPrefixID + "/available-prefixes/?limit=200&depth=1"

        $params = @{
            Method          = 'Post'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params

        $response 
    }
    catch {
        #throw $_
    }
    return $response.value
}

#$allocateIPs =Allocate-Prefix -ParentPrefixID "c7a98df5-6ae8-4e0d-abdf-77874fc73348" -SubnetSize 18 -TenantID "fa35c06d-675a-4aa2-8d40-c0d18f504532" -LocationID "21c5eba0-8fa6-4605-91db-5d3aa64c30f5" -VNetName "5874-dev-eus2-vnet-01"
#$allocateIPs

<#
# Function Get-VirtualNetworkAddressSpace 
# purpose to pull Next available virtual Network Address space from NautoBot by Geo-region, Location and Virtual Network Size.
# Each Virtual Network pulled, network CIDR along with desired subnet allocations returned. NautoBot reserves the Address Space in Nautobot for the respective Tenant and Tag.
#
# Inputs:
#   subscriptionName:
#       Subscription Virtual networked pulled assigned to.
#   region:
#       Geographic region (US or UK)
#   location:
#       Azure region location desired.
#   vNetSize:
#        Virtual Network Size requested (small, medium, large, xlarge)
#
# Output:
#   Subnets List or Exception
#
#>


function Get-VirtualNetworkAddressSpace {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory)]
        [string] $subscriptionName,

        [Parameter(Mandatory)]
        [string] $region,

        [Parameter(Mandatory)]
        [string] $location,

        [Parameter(Mandatory)]
        [string] $vNetSize 
    )
    
    begin {
        #Write-Debug ("{0} entered" -f $MyInvocation.MyCommand) 
    }
    
    process {


        #################################
        ##   Get Address Prefix List   ##
        #################################
        try {

            $KeyVaultName = 'ng-prd-eus2-kv-01'
            $PATSecretName = 'GBL-SVC-NAUTOBOT-PAT'
        
            Set-AzContext -Subscription "US-HUB-Prod-01" |Out-Null
            $PAT = `
                Get-AzKeyVaultSecret `
                -VaultName $KeyVaultName `
                -Name $PATSecretName `
                -ErrorAction Stop;
            Write-Host "getting PAT  from KV " -Verbose
            $PATValue = $PAT.SecretValue
            Write-Host "$PATValue " -Verbose
            if ($PATValue) {
                $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
                $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
                #$PATSecretText
            }
            else {
                { Write-Host "PAT is not found. please check the PAT Secret Value" }
            }
        
            #location ID procesing for Nautobot
            If($location -eq "eus2")
            {
            $Nautobotloc ="eastus2"
            }
             #location ID procesing for Nautobot
            If($location -eq "cus")
            {
            $Nautobotloc ="centralus"
            }
             #location ID procesing for Nautobot
            If($location -eq "uks")
            {
            $Nautobotloc ="uksouth"
            }
             #location ID procesing for Nautobot
            If($location -eq "ukw")
            {
            $Nautobotloc ="ukwest"
            }

            $TenantLocationresults = Get-Location -Location "2.0"
            $TenantLocation =$TenantLocationresults.results
            $TenantLocationID = $TenantLocation.id
            #$TenantLocationID

            $RegionLocationresults = Get-Location -Location $Nautobotloc
            $RegionLocation = $RegionLocationresults.results
            $RegionLocationID = $RegionLocation.id
            #$RegionLocationID
            $subscriptionName = $subscriptionName.ToLower()
            $VNetName = $subscriptionName.Split("-")[1].ToLower() + "-"+ $subscriptionName.Split("-")[2].ToLower() + "-"+ $location.ToLower() + "-vnet-" + $subscriptionName.Split("-")[3]
            #$VNetName
            $getTag = Get-Tag -VNetName $VNetName
            $CheckTag =$getTag.results
            if($CheckTag)
            {
                Write-Host " VNET Name Exists in Nautobot as Tag"

            }
            else
            {
                Write-Host " Adding VNET Name as Tag in Nautobot"
             $AddTag =Add-Tag -VNETName $VNetName
             #$AddTag
            }


            $getTenant = Get-Tenant -SubscriptionName $SubscriptionName
            $CheckTenant =$getTenant.results
            if($CheckTenant)
            {
                Write-Host " Subscription Name Exists in Nautobot as Tenant"
            $TenantID = $CheckTenant.id

            }
            else
            {
                Write-Host " Adding Subscription Name as Tenant in Nautobot"
             $AddTenant =Add-Tenant -SubscriptionName $SubscriptionName
             #$AddTenant
             $TenantID = $AddTenant.id
            }

            If([int]$vNetSize -gt 26)
            {
            $SubnetsSize =[int]$vNetSize + 1
            Write-Host "Subnet Size is $SubnetsSize"
            }
            else 
            {
            $SubnetsSize =[int]$vNetSize + 2
            Write-Host "Subnet Size is $SubnetsSize"
            }

            
        
            $ParentPrefixes1 = Get-ParentPrefixes -RegionLocationID $RegionLocationID
            $ParentPrefixes = $ParentPrefixes1.results
            foreach ($ParentPrefix in $ParentPrefixes)
            {
                Write-Host "checking in Address Prefix  $($ParentPrefix.prefix) " -Verbose
            $ParentPrefixID =$ParentPrefix.id
            #$ParentPrefixID
            $AllocatePrefixes = Allocate-Prefix -ParentPrefixID $ParentPrefixID -SubnetSize $vNetSize -TenantID $TenantID -LocationID $RegionLocationID -VNetName $VNetName
            $Allocatedprefix = $AllocatePrefixes.prefix
            #$Allocatedprefix
            if($Allocatedprefix)
            {
                Write-Host "Allocated ADDRESS prefix $Allocatedprefix " -Verbose
            break;
            }
            else
            {
                Write-Host "Allocation did not happen from $($ParentPrefix.prefix), checking next Parent Prefix.."
            }
            }

            if (!($Allocatedprefix))
            {
            Write-Error "Prefix Allocation failed, Please check the available IP Addresses in Nautobot" -Verbose
            }

        }

        catch {
            
            $_.Exception
               
            if($_.Exception | Select-String "The server committed a protocol violation"){
                Write-Warning "Most Likely the Address Space is not available, request timed out or this is an invalid request"
            }
             elseif($_.Exception | Select-String "Prefix Allocation failed, Please check the availabile IP Addresses"){
                Write-Warning "No Address Space available for allocation"
            }
            else{
                throw $_
            }   
        }   
        Write-Host "Printing 1 $Allocatedprefix " -Verbose
        Write-Host "Printing 2 $subnetsSize " -Verbose
        Write-Host "Printing 3 $subscriptionName" -Verbose
        Return $Allocatedprefix , $subnetsSize , $subscriptionName  
        if ($null -ne $Allocatedprefix) {
            Return $Allocatedprefix , $subnetsSize , $SubscriptionName 
        }
        else {
            Return $null,$null,$null
        }
    }   
    end {
        #Write-Debug ("{0} exited" -f $MyInvocation.MyCommand) 
    }
}

<#
# Function Get-ExistingVirtualNetworkAddressSpace 
# purpose to pull available virtual Network Address space from the Nautobot filtered by Geo-region, Location and Virtual Network Size, Tenant and Tag.
# Each Virtual Network pulled, network CIDR along with desired subnet allocations returned. 
# Inputs:
#   subscriptionName:
#       Subscription Virtual networked pulled assigned to.
#   region:
#       Geographic region (US or UK)
#   location:
#       Azure region location desired.
#   vNetSize:
#        Virtual Network Size requested (small, medium, large, xlarge)
#
# Output:
#   Subnets List or Exception
#
#>

function Get-ExistingNetworkAddressSpace {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory)]
        [string] $subscriptionName,

        [Parameter(Mandatory)]
        [string] $region,

        [Parameter(Mandatory)]
        [string] $location,

        [Parameter(Mandatory)]
        [int] $vNetSize     
    )

    begin {
        #Write-Debug ("{0} entered" -f $MyInvocation.MyCommand) 
    }
   

    process {


        #################################
        ##   Get Address Prefix List   ##
        #################################
        try {


            $KeyVaultName = 'ng-prd-eus2-kv-01'
            $PATSecretName = 'GBL-SVC-NAUTOBOT-PAT'
        
            Set-AzContext -Subscription "US-HUB-Prod-01" |Out-Null
            $PAT = `
                Get-AzKeyVaultSecret `
                -VaultName $KeyVaultName `
                -Name $PATSecretName `
                -ErrorAction Stop;
            Write-Host "getting PAT  from KV " -Verbose
            $PATValue = $PAT.SecretValue
            Write-Host "$PATValue " -Verbose
            if ($PATValue) {
                $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
                $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
                #$PATSecretText
            }
            else {
                { Write-Host "PAT is not found. please check the PAT Secret Value" }
            }


            #5874-dev-eus2-VNET-01
            #$subscriptionName ="US-5874-DEV-01"
            #$location ="eus2"

            #location ID procesing for Nautobot
            If($location -eq "eus2")
            {
            $Nautobotloc ="eastus2"
            }
             #location ID procesing for Nautobot
            If($location -eq "cus")
            {
            $Nautobotloc ="centralus"
            }
             #location ID procesing for Nautobot
            If($location -eq "uks")
            {
            $Nautobotloc ="uksouth"
            }
             #location ID procesing for Nautobot
            If($location -eq "ukw")
            {
            $Nautobotloc ="ukwest"
            }

            $TenantLocationresults = Get-Location -Location "2.0"
            $TenantLocation =$TenantLocationresults.results
            $TenantLocationID = $TenantLocation.id
            #$TenantLocationID

            $RegionLocationresults = Get-Location -Location $Nautobotloc
            $RegionLocation = $RegionLocationresults.results
            $RegionLocationID = $RegionLocation.id
            #$RegionLocationID
            $subscriptionName = $subscriptionName.ToLower()
            $VNetName = $subscriptionName.Split("-")[1].ToLower() + "-"+ $subscriptionName.Split("-")[2].ToLower() + "-"+ $location.ToLower() + "-vnet-" + $subscriptionName.Split("-")[3]
            #$VNetName
            $getTag = Get-Tag -VNetName $VNetName
            $CheckTag =$getTag.results
            if($CheckTag)
            {
            Write-Host " VNET Name Exists in Nautobot as Tag"
            $TagID = $CheckTag.id

            }
            else
            {
             Write-Host "VNET Name does not exists as Tag in Nautobot"
            }

            If($vNetSize -gt 26)
            {
            $SubnetsSize =$vNetSize + 1
            Write-Host "Subnet Size is $SubnetsSize"
            }
            else 
            {
            $SubnetsSize =$vNetSize + 2
            Write-Host "Subnet Size is $SubnetsSize"
            }

            $getTenant = Get-Tenant -SubscriptionName $SubscriptionName
            $CheckTenant =$getTenant.results
            if($CheckTenant)
            {
            Write-Host " Subscription Name Exists in Nautobot as Tenant"
            $TenantID = $CheckTenant.id
            if ($TagID)
            {

            $GetAssignedPrefix = Get-AssignedPrefix -VNetSize $vNetSize -RegionalLocationID $RegionLocationID -TenantID $TenantID -TagID $TagID
            $AssignedPrefixresults =$GetAssignedPrefix.results
            $addressPrefix = $AssignedPrefixresults.prefix
            }
            }
            else
            {
             Write-Host " Subscription Name does not exist as Tenant in Nautobot"
            }

            if ($addressPrefix)
            {
            #$addressPrefix
            }
            
            else
            {
                Write-Host "Prefix is not allocated to $SubscriptionName " -Verbose
            }

        }

        catch {
        
               $_.Exception
               
            if($_.Exception | Select-String "The server committed a protocol violation"){
                Write-Warning "Most Likely the Address Space is not available, request timed out or this is an invalid request"
            }
             elseif($_.Exception | Select-String "Prefix Allocation failed, Please check the availabile IP Addresses"){
                Write-Warning "No Address Space available for allocation"
            }
            else{
                throw $_
            }
        
        }

 
    if ($null -ne $addressPrefix) {
            Return $addressPrefix , $subnetsSize , $SubscriptionName 
        }
        else {
            Return $null,$null,$null
        }
        }
    end {
        #Write-Debug ("{0} exited" -f $MyInvocation.MyCommand) 
    }
    }
    