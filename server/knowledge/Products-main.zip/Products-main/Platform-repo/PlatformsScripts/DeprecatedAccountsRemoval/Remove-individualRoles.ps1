<#
.SYNOPSIS
 This script will remove all Role Assignement in your Azure Subscriptions

.NOTES
  Version:        1.0

.PARAMETER OutPutPath
Remove Role Assignments from entire Tenant or selected Subscription

.PARAMETER SelectCurrentSubscription
Will only Remove Role Assignments from the current subscription you have selected.
    
.EXAMPLE
Remove Role assignments for all subscriptions: .\Remove-RoleAssignments.ps1 
Only Remove Role assignments for current subscription: .\Remove-RoleAssignments.ps1 -SelectCurrentSubscription
  
#>
#connect-azaccount
#Parameters
[CmdletBinding(SupportsShouldProcess)]
param(
  [string]$selectCurrentSubscription,
  [string]$signInUsers
)
#$signInUsers='Hans.Rony@nationalgrid.com'
$Userslist = $signInUsers.Split(",")
Write-Verbose "Below are the params values" -Verbose
$Userslist
$selectCurrentSubscription
#$SelectCurrentSubscription = 'd004487f-755f-432f-981b-63d14a835b16'
#$Userslist = $signInUsers.Split(",")
#$selectCurrentSubscription = $selectCurrentSubscription
#Get Current Context
#$CurrentContext = Get-AzContext

#$Userslist = 'AZADM_MohammedTousif@nationalgridplc.onmicrosoft.com','AZADM_ANUSHA.SHETTY1@nationalgridplc.onmicrosoft.com'
#$SelectCurrentSubscription =''

#Get Azure Subscriptions
if ($selectCurrentSubscription -ne 'Default') {
  #Only selection current subscription
  Write-Verbose "setting context to root tenant f98a6a53-25f3-4212-901c-c7787fcd3495 " -Verbose
  $CurrentTenant= Set-AzContext -TenantId 'f98a6a53-25f3-4212-901c-c7787fcd3495'
  $CurrentTenant
  Write-Verbose "Current Subs is..." -Verbose
  $CurrentSubs = Get-AzSubscription -SubscriptionName $selectCurrentSubscription
  $CurrentSubs
  Write-Verbose "Only selecting provided subscription" -Verbose
  $Context = Set-AzContext -SubscriptionId $selectCurrentSubscription -TenantId 'f98a6a53-25f3-4212-901c-c7787fcd3495' -Force
  $Context
  Write-Verbose "Below are the Currentcontext values" -Verbose
  $CurrentContext = set-AzContext -Subscription $selectCurrentSubscription
  $CurrentContext
  Write-Verbose "Only running for selected subscription $($CurrentContext.Subscription.Name)" -Verbose
  $Subscriptions = $CurrentContext.Subscription.SubscriptionId
  $Subscriptions
}
else {
  Write-Verbose "Running for all subscriptions in Tenant" -Verbose
  #$Subscriptions = Get-AzSubscription -TenantId $CurrentContext.Tenant.Id
  $Cmanagementgrps = 'Global-UK-NonProd', 'Global-UK-Prod', 'Global-US-NonProd', 'Global-US-Prod', 'UKAzure-Cloud1.0-Dev', 'UKAzure-Cloud1.0-Prod', 'USAzure-Cloud1.0-Dev', 'USAzure-Cloud1.0-Prod'
  [System.Collections.ArrayList]$Subscriptions = @()
  foreach ($Cmanagementgrp in $Cmanagementgrps) {
    $CMGSubscriptions = Get-AzManagementGroup -GroupID $CManagementGrp -Expand -Recurse
    $CMGsubscriptionlist = $CMGSubscriptions | foreach-object -MemberName Children

    $CMGsubscriptionlist | ForEach-Object {
      $subs = $_.Name
      $Subscriptions.Add("$subs")
    }
  }
}
Write-Verbose "Removing permissions from" -Verbose
$Subscriptions

foreach ($Subscription in $Subscriptions) {
  #Choose subscription
  $Subscription
  Write-Verbose "Changing to Subscription $($Subscription)" -Verbose
  $CurrentSubs = Get-AzSubscription -SubscriptionId $Subscription
  $CurrentSubs
  $Context = Set-AzContext -SubscriptionId $Subscription -Force
  $Context
  $subsName = $CurrentSubs.Name
  $Name
  $TenantId = $CurrentSubs.TenantId
  $TenantId
  $SubId = $CurrentSubs.SubscriptionId
  $SubId
  $Userslist[0]
  #Getting information about Role Assignments for choosen subscription
  Write-Verbose "Getting information about Role Assignments..." -Verbose
  foreach ($signInUser in $Userslist) {
    $signInUser
    $roles = Get-AzRoleAssignment -SignInName $signInUser -ErrorAction SilentlyContinue
    #removing Role Assignments from choosen subscription
    Write-Verbose "Removing Role Assignments..." -Verbose
    if ($roles) {
      try {
        $removeroles = $roles | Remove-AzRoleAssignment 
        Write-Verbose "Role Assignments removed $($removeroles) from Subscrption $($subsName)..." -Verbose
      }
      catch {
        Write-Verbose "caught Error in removing individual role $($_) " -Verbose
      }

    }
    else {
      Write-Verbose "No Role Assignment found for $($signInUser) in Subscrption $($subsName)..." -Verbose
    }
  }

}