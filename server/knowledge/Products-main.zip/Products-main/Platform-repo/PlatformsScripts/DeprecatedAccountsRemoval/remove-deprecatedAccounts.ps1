#Parameters
[CmdletBinding(SupportsShouldProcess)]
Param (
    [string]$signInUsers
)

$Userslist = $signInUsers.Split(",")
#$signInUsers = 'milinm@nationalgridplc.onmicrosoft.com'
Write-Verbose "Checking for Azure Entra module..." -Verbose

$AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

if ($AzModule -eq $null) {
    Write-Verbose "Azure Entra PowerShell module not found" -Verbose
    #Logging into Azure Entra
    Install-Module -Name "Microsoft.Entra" -Force
    Import-Module -Name "Microsoft.Entra" -Force
}
else {
    Import-Module -Name "Microsoft.Entra" -Force
}
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken

$secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
Connect-Entra -AccessToken $secureString

Write-Verbose "Getting User details..." -Verbose
foreach ($User in $Userslist) {
    $user = $user.Trim()
    $user

    if (Get-EntraUser -Filter "mail eq '$user'") {
        $adUser = Get-EntraUser -Filter "mail eq '$user'"
        $SPNAppId = $adUser.UserPrincipalName
        $AzureMember = get-Entrauser -UserId $SPNAppId

        $AzureMember | Get-EntraUserMembership | Where-Object { ($_.'@odata.type' -eq "#microsoft.graph.group") } | ForEach-Object {
            $_.ObjectId
            $_.DisplayName
            #if(($_.GroupType -eq "Security") -and ($_.MembershipType -eq "Assigned"))
            #{
            $CheckGroup = Get-EntraGroup -GroupId $_.ObjectId
            $CheckSecEnabled = $CheckGroup.SecurityEnabled
            $CheckmailEnabled = $CheckGroup.MailEnabled
            $CheckGrouptype = $CheckGroup.GroupTypes
            if ($CheckSecEnabled -eq $false) {
                $GroupType = "Distribution Group"
            }
            else {
                $GroupType = $CheckGrouptype
            }

            if (([string]::IsNullOrEmpty($Grouptype)) -and ($CheckSecEnabled -eq $True) -and ($CheckmailEnabled -eq $false)) {
                Write-Verbose "Starting User removal from the group- $($_.DisplayName) :Group Type: $($GroupType), SecurityEnabled: $($CheckSecEnabled) " -Verbose
                try {
                    Remove-EntraGroupMember -ObjectId $_.ObjectId -MemberId $AzureMember.ObjectId -ErrorAction SilentlyContinue
                }
                catch {
                    Write-Verbose "caught Error in removing group $($_) " -Verbose
                }
        
            }
            else {
                Write-Verbose "USer can not be removed from the group- $($_.DisplayName) :Group Type: $($GroupType), SecurityEnabled: $($CheckSecEnabled) " -Verbose
            }
        }
        Continue;
    }
    elseif (Get-EntraUser -Filter "userPrincipalName eq '$user'") {
        $adUser = Get-EntraUser -Filter "userPrincipalName eq '$user'"
        $SPNAppId = $adUser.UserPrincipalName
        $AzureMember = get-EntraUser -UserId $SPNAppId

        $AzureMember | Get-EntraUserMembership | Where-Object { ($_.'@odata.type' -eq "#microsoft.graph.group") } | ForEach-Object {
            $_.ObjectId
            $_.DisplayName
            #if(($_.GroupType -eq "Security") -and ($_.MembershipType -eq "Assigned"))
            #{
            $CheckGroup = Get-EntraGroup -GroupId $_.ObjectId
            Write-Verbose "Group Name- $($CheckGroup)" -Verbose
            $CheckSecEnabled = $CheckGroup.SecurityEnabled
            $CheckGrouptype = $CheckGroup.GroupTypes    
            if ($CheckSecEnabled -eq $false) {
                $GroupType = "Distribution Group"
            }
            else {
                $GroupType = $CheckGrouptype
            }

            if (([string]::IsNullOrEmpty($Grouptype)) -and ($CheckSecEnabled -eq $True)) {
                Write-Verbose "Starting User removal from the group- $($_.DisplayName) :Group Type: $($GroupType), SecurityEnabled: $($CheckSecEnabled) " -Verbose
                try {
                    Remove-EntraGroupMember -ObjectId $_.ObjectId -MemberId $AzureMember.ObjectId -ErrorAction SilentlyContinue
                }
                catch {
                    Write-Verbose "caught Error in removing group $($_) " -Verbose
                }
            }
            else {
                Write-Verbose "USer can not be removed from the group- $($_.DisplayName) :Group Type: $($GroupType), SecurityEnabled: $($CheckSecEnabled) " -Verbose
            }
        }
        Continue;
    }
    else {
        Write-Error "Could not recognize the User $user . Please check if the provided user exists... "
    }
    
}
Write-Verbose "Removed deperecated users from all Groups" -Verbose