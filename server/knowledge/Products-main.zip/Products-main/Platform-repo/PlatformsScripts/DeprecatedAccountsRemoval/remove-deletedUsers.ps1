#AuthN
#Connect-AzAccount

#Set Your Subscription ID
#SelectCurrentSubscriptionSet-AzContext -SubscriptionId ""

#Parameters
Param ( 
    [string]$signInUser,  
    [string]$SelectCurrentSubscription
	
)
#$signInUsers = 'AZADM_MohammedTousif@nationalgridplc.onmicrosoft.com','AZADM_ANUSHA.SHETTY1@nationalgridplc.onmicrosoft.com'
#$SelectCurrentSubscription =''

#$signInUser=$signInUser

#Get Current Context
$CurrentContext = Get-AzContext

#Get Azure Subscriptions
if ($SelectCurrentSubscription -ne 'Default') {
  #Only selection current subscription
  Write-Verbose "Only running for selected subscription $($CurrentContext.Subscription.Name)" -Verbose
  $Subscriptions = Get-AzSubscription -SubscriptionId $CurrentContext.Subscription.Id -TenantId $CurrentContext.Tenant.Id

}
else 
{
  Write-Verbose "Running for all subscriptions in Tenant" -Verbose
  $Subscriptions = Get-AzSubscription -TenantId $CurrentContext.Tenant.Id
}


foreach ($Subscription in $Subscriptions) 
{
#Common Variables
$FILEPATH = "C:\Temp"
$FILENAME = "AzureRoleAssignmentsToRemove.csv"
$SUBNAME = $Subscription
$OBJTYPE = "Unknown"

#Find and Export-to-CSV Azure RBAC Role Assignments of 'Unknown' Type
$unknownUsers = Get-AzRoleAssignment | Where-Object {$_.ObjectType.Equals($OBJTYPE)} | Export-Csv "$FILEPATH\$SUBNAME-$FILENAME" -NoTypeInformation
$unknownUsers
#Import-from-CSV and Remove each Azure Role Assignment
$RASTOREMOVE = Import-CSV "$FILEPATH\$SUBNAME-$FILENAME"
$RASTOREMOVE|ForEach-Object {
$object = $_.ObjectId
$roledef = $_.RoleDefinitionName
$rolescope = $_.Scope
#Remove-AzRoleAssignment -ObjectId $object -RoleDefinitionName $roledef -Scope $rolescope
}
}