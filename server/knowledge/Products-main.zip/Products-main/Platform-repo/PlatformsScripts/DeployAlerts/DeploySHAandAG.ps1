function Invoke-Alerts {
    param (
        [Parameter(Mandatory = $true)] [string] $sub
    )

    $parts = $sub -split '-'
    $region = $parts[0]  
    $subscriptionId = $parts[1] 
    $environment = $parts[2].ToLower()
    $increment = $parts[3] 
    $location = "Global"
    $scope = "/subscriptions/" + (Get-AzContext).Subscription.ID
    $id = (Get-AzContext).Subscription.ID

    $actionGroupName = "$subscriptionId-$environment-eus2-ag-$increment"
    $alertRuleName = "$subscriptionId-$environment-eus2-serviceAlert-$increment"
    $actionGroupShortName = "$subscriptionId-ag"
    $resourceGroupName = "ng-prd-eus2-centralmon-rg"

    if ($environment -eq "prod") {
        $roleid = "43d0d8ad-25c7-4714-9337-8ba259a9fe05"
        $rolename = "Alert All Monitoring Readers"
        
    } else {
        $roleid = "b24988ac-6180-42a0-ab88-20f7382dd24c"
        $rolename = "Alert All Contributors"
    }

    if ($region -eq "US") {
        $condition2 = New-AzActivityLogAlertAlertRuleLeafConditionObject -Field properties.impactedServices[*].ImpactedRegions[*].RegionName -ContainsAny "East US, East US 2, Central US, Global"
    } elseif ($region -eq "UK") {
        $condition2 = New-AzActivityLogAlertAlertRuleLeafConditionObject -Field properties.impactedServices[*].ImpactedRegions[*].RegionName -ContainsAny "UK South, UK West, Global"
    }

    try {
        $emailReciever = New-AzActionGroupArmRoleReceiverObject -Name $rolename -RoleId $roleid
        New-AzActionGroup -ResourceGroupName $resourceGroupName -Name $actionGroupName -ShortName $actionGroupShortName -Location $location -ArmRoleReceiver $emailReciever -Enabled

        $agID = "/subscriptions/" + $id + "/resourceGroups/" + $resourceGroupName + "/providers/Microsoft.Insights/actiongroups/" + $actionGroupName
        $actiongroup = New-AzActivityLogAlertActionGroupObject -Id $agID
        $condition1 = New-AzActivityLogAlertAlertRuleAnyOfOrLeafConditionObject -Equal "ServiceHealth" -Field category
        $condition3 = New-AzActivityLogAlertAlertRuleLeafConditionObject -Field properties.eventTypes -ContainsAny "Planned Maintenance", "Security Advisory", "Health Advisories", "Service Issue"
        New-AzActivityLogAlert -Name $alertRuleName -Scope $scope -ResourceGroupName $resourceGroupName -Action $actiongroup -Location $location -Condition @($condition1, $condition3, $condition2) -Enabled $true

    } catch {
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
        throw $_
    }
}
