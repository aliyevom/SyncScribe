Function Update-SpokeDNSIPs {
    param(
      [Parameter(Mandatory = $true)] [string] $subscriptionId,
      [Parameter(Mandatory = $true)] [string] $vNetName,
      [Parameter(Mandatory = $true)] [string] $vnetrgName
    ) 

    $dnsIPs = @{
        eastus2   = @("10.82.2.100", "10.82.194.68", "10.127.0.5")
        centralus = @("10.82.194.68", "10.82.2.100", "10.127.0.5")
        uksouth   = @("10.83.2.68", "10.83.194.68", "10.127.0.1")
        ukwest    = @("10.83.194.68", "10.83.2.68", "10.127.0.1")
    }


    Set-AzContext -Subscription $subscriptionId    
    $vnet = Get-AzVirtualNetwork -Name $vNetName -ResourceGroupName $vnetrgName    
    $vnet.DhcpOptions.DnsServers = $null     
    $vnet.DhcpOptions.DnsServers = $dnsIPs[$($vnet.Location)]
    
    Set-AzVirtualNetwork -VirtualNetwork $vnet
}

$csv=import-csv C:\Temp\usdevhub.csv

foreach($rule in $csv){
Update-SpokeDNSIPs -subscriptionId $rule.subscriptionId -vnetrgName $rule.vnetrgName -vnetName $rule.vnetName

}  