#Remove the releasever file
sudo rm -f /etc/yum/vars/releasever

#Disable EUS repos
sudo yum -y --disablerepo='*' remove 'rhui-azure-rhel8-eus'

#Get the regular repos config file
sudo wget https://rhelimage.blob.core.windows.net/repositories/rhui-microsoft-azure-rhel8.config

#Add EUS repos
sudo yum -y --config=rhui-microsoft-azure-rhel8.config install rhui-azure-rhel8

#Update RHEL VM
sudo dnf update -y --skip-broken --nobest

#Upgrade RHEL VM
dnf upgrade -y

#Reboot the VM
sudo reboot

