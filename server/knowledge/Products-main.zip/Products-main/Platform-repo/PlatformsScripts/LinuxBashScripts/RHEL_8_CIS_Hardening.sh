#!/bin/bash
#Grub files

sudo echo "Ensure permissions on bootloader config are configured"
chown root:root /boot/grub2/grub.cfg
chmod og-rwx /boot/grub2/grub.cfg
touch /boot/grub2/user.cfg
chown root:root /boot/grub2/user.cfg
chmod og-rwx /boot/grub2/user.cfg


#Cron files
rm /etc/cron.deny;rm /etc/at.deny
touch /etc/cron.allow;touch /etc/at.allow
chmod og-rwx /etc/cron.allow;chmod og-rwx /etc/at.allow
chown root:root /etc/cron.allow;chown root:root /etc/at.allow

#Log files
find /var/log -type f -exec chmod g-wx,o-rwx {} +

#User management
useradd -D -f 30
chage --maxdays 90 superazure
chage --mindays 7 superazure

#package removal
yum -y remove openldap-clients

#services modifications
systemctl disable nfs;systemctl disable nfs-server;systemctl disable rpcbind

#updating Kernel parameters

#Ensure address space layout randomization (ASLR) is enabled
sudo echo "Ensure address space layout randomization (ASLR) is enabled"

sudo echo -e "kernel.randomize_va_space = 2\nnet.ipv4.ip_forward = 0\nnet.ipv4.conf.all.accept_source_route = 0\nnet.ipv4.conf.default.accept
_source_route = 0\nnet.ipv4.icmp_sudo echo_ignore_broadcasts = 1\nnet.ipv4.icmp_ignore_bogus_error_responses = 1\nnet.ipv4.conf.all.rp_filter
 = 1\nnet.ipv4.conf.default.rp_filter = 1\nnet.ipv4.tcp_syncookies = 1\nnet.ipv6.conf.all.accept_redirects = 0\nnet.ipv6.conf.default.ac
cept_redirects = 0" >> /etc/sysctl.conf
sysctl -p

#File permission & Ownership
sudo echo "Ensure sticky bit is set on all world-writable directories"
df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null | xargs -I '{}' chmod a+t '{}'

#Mount Disable

sudo echo "Ensure mounting of cramfs filesystems is disabled"
sudo echo "install cramfs /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure mounting of freevxfs filesystems is disabled"
sudo echo "install freevxfs /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure mounting of jffs2 filesystems is disabled"
sudo echo "install jffs2 /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure mounting of hfs filesystems is disabled"
sudo echo "install hfs /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure mounting of hfs filesystems is disabled"
sudo echo "install hfsplus /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure  mounting of squashfs filesystems is disabled"
sudo echo "install squashfs /bin/true" >>/etc/modprobe.d/CIS.conf

sudo echo "Ensure  mounting of udf filesystems is disabled"
sudo echo "install udf /bin/true" >>/etc/modprobe.d/CIS.conf

mount -o remount,noexec /dev/shm

#Ensure local login warning banner is configured properly
sudo echo "local login warning banner is configured properly"
sudo echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue
sudo echo "Ensure remote login warning banner is configured properly"
sudo echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue.net
sudo echo -e "Banner /etc/issue.net" >> /etc/ssh/sshd_config

#Password complexity
sed -i "s/minlen = 6/minlen = 14/"  /etc/security/pwquality.conf
sed -i "s/dcredit = 0/dcredit = -1/" /etc/security/pwquality.conf
sed -i "s/ucredit = 0/ucredit = -1/" /etc/security/pwquality.conf
sed -i "s/ocredit = 0/ocredit = -1/" /etc/security/pwquality.conf
sed -i "s/lcredit = 0/lcredit = -1/" /etc/security/pwquality.conf
sed -i "s/PASS_MAX_DAYS   9999/PASS_MAX_DAYS   90/" /etc/login.defs
sed -i "s/PASS_MIN_DAYS   0/PASS_MIN_DAYS   7/" /etc/login.defs

#PAM
sudo echo -e "password requisite pam_pwquality.so try_first_pass retry=3\npassword sufficient pam_unix.so remember=5" >> /etc/pam.d/password-auth

sudo echo -e "password requisite pam_pwquality.so try_first_pass retry=3\npassword sufficient pam_unix.so remember=5" >> /etc/pam.d/system-auth


# check for the /tmp directory
mount | grep /tmp


if [ $? -ne 0 ]; then
  sudo echo "tmp directory not present"
    
else
sudo echo "[Mount]
Options=mode=1777,strictatime,noexec,nodev,nosuid" >> /etc/systemd/system/local-fs.target.wants/tmp.mount

# creating the file
    sudo echo "tmp directory present"
    sudo echo "Ensure nodev option set on /tmp partition"
    mount -o remount,nodev /tmp
    sudo echo "Ensure nosuid option set on /tmp partition"
    mount -o remount,nosuid /tmp
    sudo echo "Ensure  noexec option set on /tmp partition"
    mount -o remount,noexec /tmp
fi

## checking for var tmp
mount | grep /var/tmp

if [ $? -ne 0 ]; then
  sudo echo "/var/tmp directory not present"
    
else

    sudo echo "/var/tmp directory present"
    sudo echo "Ensure nodev option set on /tmp partition"
    mount -o remount,nodev /var/tmp
    sudo echo "Ensure nosuid option set on /tmp partition"
    mount -o remount,nosuid /var/tmp
    sudo echo "noexec option set on /var/tmp partition  "
    mount -o remount,noexec /var/tmp
fi

# Ensure AIDE is installed
  sudo echo
  sudo echo \*\*\*\* Ensure\ AIDE\ is\ installed
  rpm -q aide || yum -y install aide

  # Ensure filesystem integrity is regularly checked
  sudo echo
  sudo echo \*\*\*\* Ensure\ filesystem\ integrity\ is\ regularly\ checked
  (crontab -u root -l; crontab -u root -l | egrep -q "^0 5 \* \* \* /usr/sbin/aide --check$" || sudo echo "0 5 * * * /usr/sbin/aide --check" ) | crontab -u root -


  # Ensure gpgcheck is globally activated
  sudo echo
  sudo echo \*\*\*\* Ensure\ gpgcheck\ is\ globally\ activated
  egrep -q "^(\s*)gpgcheck\s*=\s*\S+(\s*#.*)?\s*$" /etc/yum.conf && sed -ri "s/^(\s*)gpgcheck\s*=\s*\S+(\s*#.*)?\s*$/\1gpgcheck=1\2/" /etc/yum.conf || sudo echo "gpgcheck=1" >> /etc/yum.conf
  for file in /etc/yum.repos.d/*; do
    egrep -q "^(\s*)gpgcheck\s*=\s*\S+(\s*#.*)?\s*$" $file && sed -ri "s/^(\s*)gpgcheck\s*=\s*\S+(\s*#.*)?\s*$/\1gpgcheck=1\2/" $file || sudo echo "gpgcheck=1" >> $file
  done
  
  
# Ensure permissions on bootloader config are configured
  sudo echo
  sudo echo -e "${RED}1.3.2${NC} Ensure permissions on bootloader config are configured\n"
  rhel_1_4_1="$(chmod g-r-w-x,o-r-w-x /boot/grub2/grub.cfg)"
  rhel_1_4_1=$?
if [[ "$rhel_1_4_1" -eq 0 ]]; then
  sudo echo -e "${GREEN}Remediated:${NC} Ensure permissions on bootloader config are configured"
  success=$((success + 1))
else
  sudo echo -e "${RED}UnableToRemediate:${NC} Ensure permissions on bootloader config are configured"
  fail=$((fail + 1))
fi

# Ensure sudo log file exists sudo can use a custom log file
  sudo echo 'Defaults logfile="/var/log/sudo.log"' >> /etc/sudoers

# Ensure sudo commands use pty
  sudo echo 'Defaults use_pty' >> /etc/sudoers

# Ensure telnet client is not installed
  sudo dnf remove telnet -y  

# Ensure password creation requirements are configured (Scored)
  sudo echo 'minlen = 14' >> /etc/security/pwquality.conf
  sudo echo 'minclass = 4' >> /etc/security/pwquality.conf

  CP=$(authselect current | awk 'NR == 1 {print $3}' | grep custom/) 
  for FN in system-auth password-auth; 
  do [[ -n $CP ]] && PTF=/etc/authselect/$CP/$FN || PTF=/etc/authselect/$FN [[ -z $(grep -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*enforce-for-root\s*.*$' $PTF) ]] && sed -ri 's/^\s*(password\s+requisite\s+pam_pwquality.so\s+)(.*)$/\1\2 enforce-for-root/' $PTF [[ -n $(grep -E '^\s*password\s+requisite\s+pam_pwquality.so\s+.*\s+retry=\S+\s*.*$' $PTF) ]] && sed -ri '/pwquality/s/retry=\S+/retry=3/' $PTF || sed -ri 's/^\s*(password\s+requisite\s+pam_pwquality.so\s+)(.*)$/\1\2 retry=3/' $PTF 
  done authselect apply-changes

# Ensure password hashing algorithm is SHA-512
  CP=$(authselect current | awk 'NR == 1 {print $3}' | grep custom/) 
  for FN in system-auth password-auth; 
  do [[ -z $(grep -E '^\s*password\s+sufficient\s+pam_unix.so\s+.*sha512\s*.*$' $PTF) ]] && sed -ri 's/^\s*(password\s+sufficient\s+pam_unix.so\s+)(.*)$/\1\2 sha512/' $PTF 
  done authselect apply-changes

# Ensure iptables is not enabled
  sudo systemctl --now mask iptables  

# Ensure remote rsyslog messages are only accepted on designated log hosts
  sudo echo '# $ModLoad imtcp' >> /etc/rsyslog.conf
  sudo echo '# $InputTCPServerRun 514' >> /etc/rsyslog.conf
  sudo systemctl restart rsyslog

# Ensure permissions on all logfiles are configured
  find /var/log -type f -exec chmod g-wx,o-rwx "{}" + -o -type d -exec chmod g-w,o-rwx "{}" +  

# Ensure permissions on /etc/crontab are configured
  sudo chown root:root /etc/crontab 
  sudo chmod og-rwx /etc/crontab 

# Ensure permissions on /etc/cron.hourly are configured
  sudo chown root:root /etc/cron.hourly
  sudo chmod og-rwx /etc/cron.hourly

# Ensure permissions on /etc/cron.daily are configured
  sudo chown root:root /etc/cron.daily
  sudo chmod og-rwx /etc/cron.daily

# Ensure permissions on /etc/cron.weekly are configured
  sudo chown root:root /etc/cron.weekly
  sudo chmod og-rwx /etc/cron.weekly

# Ensure permissions on /etc/cron.monthly are configured
  sudo chown root:root /etc/cron.monthly
  sudo chmod og-rwx /etc/cron.monthly    

# Ensure SSH access is limited
  sudo echo 'AllowUsers vmadmin' >> /etc/ssh/sshd_config      

# Ensure SSH LogLevel is appropriate
  sudo echo 'LogLevel VERBOSE' >> /etc/ssh/sshd_config
  sudo echo 'LogLevel INFO' >> /etc/ssh/sshd_config

# Ensure SSH IgnoreRhosts is enabled
  sudo echo 'IgnoreRhosts yes' >> /etc/ssh/sshd_config

# Ensure SSH HostbasedAuthentication is disabled
  sudo echo 'HostbasedAuthentication' >> /etc/ssh/sshd_config

# Ensure SSH PermitEmptyPasswords is disabled
  sudo echo 'PermitEmptyPasswords no' >> /etc/ssh/sshd_config

# Ensure SSH PermitUserEnvironment is disabled
  sudo echo 'PermitUserEnvironment no' >> /etc/ssh/sshd_config
  