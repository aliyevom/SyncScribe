Function Invoke-AddT1AdminAccount {
    param(
      [Parameter(Mandatory = $true)] [string] $subscriptionId,
      [Parameter(Mandatory = $true)] [string] $resourceGroupName,
      [Parameter(Mandatory = $true)] [string] $VMName,
      [Parameter(Mandatory = $true)] [string] $geo,
      [Parameter(Mandatory = $true)] [string] $T1AdminAccount
    ) 
    
    $subId = $subscriptionId
    $rGName = $resourceGroupName
    $VM = $VMName
    $T1Adm = $T1AdminAccount


    Set-AzContext -SubscriptionId $subId
    Write-Verbose "$subId" -Verbose

    $params = [ordered]@{"param1"=$T1Adm}

 [System.String]$ScriptBlock = {
    sudo realm permit $1
    sudo systemctl stop sssd
    sudo rm -f /var/lib/sss/db/*
    sudo systemctl start sssd
    }
    $ScriptName = "addt1admin.sh"
    Out-File -FilePath $ScriptName -InputObject $ScriptBlock -NoNewline

 Invoke-AzVMRunCommand -ResourceGroupName $rGName -Name $VM -CommandId 'RunShellScript' -ScriptPath $ScriptName -Parameter $params
 Remove-Item -Path $ScriptName -Force -ErrorAction SilentlyContinue
}

    

