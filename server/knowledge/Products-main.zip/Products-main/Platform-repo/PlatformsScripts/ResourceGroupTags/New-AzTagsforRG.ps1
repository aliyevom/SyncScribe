param
(
    [parameter(Mandatory = $true)] [String] $ApplicationID,
    [parameter(Mandatory = $true)] [String] $BusinessUnit,
    [parameter(Mandatory = $true)] [String] $CompanyCode,
    [parameter(Mandatory = $true)] [String] $CostCenter,
    [parameter(Mandatory = $true)] [String] $Environment,
    [parameter(Mandatory = $true)] [String] $FinancialOwner,
    [parameter(Mandatory = $true)] [String] $FinancialRTB,
    [parameter(Mandatory = $true)] [String] $InternalOrWorkOrder,
    [parameter(Mandatory = $true)] [String] $OperationsCode,
    [parameter(Mandatory = $true)] [String] $ProjectCode,
    [parameter(Mandatory = $true)] [String] $ProjectManager,
    [parameter(Mandatory = $true)] [String] $ProjectName,
    [parameter(Mandatory = $true)] [String] $RTBSupport,
    [parameter(Mandatory = $true)] [String] $ServiceOwner,
    [parameter(Mandatory = $true)] [String] $WBSCode,
    [parameter(Mandatory = $true)] [String] $subscriptionName,
    [parameter(Mandatory = $true)] [String] $resourceGroupName,
    [parameter(Mandatory = $true)] [String] $geo
)

$ErrorActionPreference = 'Stop'
Set-AzContext -Subscription $subscriptionName 
$resource = Get-AzResourceGroup -Name $resourceGroupName
try {
    if ($geo -eq 'UK') {
        $tags = @{ "Application ID"=$ApplicationID ; "Business Unit"= $BusinessUnit ; "Company Code"=$CompanyCode ; "Cost Center"= $CostCenter;  "Environment"=$Environment; "Financial Owner"=$FinancialOwner ; "Financial RTB"=$FinancialRTB ; "WBS Code"=$WBSCode ; "Project Code"=$ProjectCode ; "Project Manager"=$ProjectManager ; "Project Name"= $ProjectName; "RTB Support"=$RTBSupport ; "Service Owner"= $ServiceOwner; }
    }
    else{
        $tags = @{ "Application ID"=$ApplicationID ; "Business Unit"= $BusinessUnit ; "Company Code"=$CompanyCode ; "Cost Center"= $CostCenter;  "Environment"=$Environment; "Financial Owner"=$FinancialOwner ; "Financial RTB"=$FinancialRTB ; "Internal or Work Order"=$InternalOrWorkOrder ; "Operations Code (WO)"=$OperationsCode ; "Project Code"=$ProjectCode ; "Project Manager"=$ProjectManager ; "Project Name"= $ProjectName; "RTB Support"=$RTBSupport ; "Service Owner"= $ServiceOwner; }
    }

    New-AzTag -ResourceId $resource.ResourceId -Tag $tags

    Write-Verbose $tags

}
catch {
    throw $_
}
