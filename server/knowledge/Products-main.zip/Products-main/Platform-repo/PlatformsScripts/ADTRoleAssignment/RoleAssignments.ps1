[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$adtSubscriptionID,
    [string]$adtEmailAddress,
    [string]$azureRole,
    [string]$region
)

$scope = "/subscriptions/" + $adtSubscriptionID
Write-Verbose "Checking for Azure Entra module..." -Verbose

$AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

if ($AzModule -eq $null) {
    Write-Verbose "Azure Entra PowerShell module not found" -Verbose
    #Logging into Azure Entra
    Install-Module -Name "Microsoft.Entra" -Force
    Import-Module -Name "Microsoft.Entra" -Force
}
else {
    Import-Module -Name "Microsoft.Entra" -Force
}
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
$secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
Connect-Entra -AccessToken $secureString

$users_value = $adtEmailAddress
$users = $users_value.split(",")
foreach ($user in $users) {
    $user = $user.Trim()
    $user
    try {

        if (Get-EntraUser -Filter "mail eq '$user'") {
            $adUser = Get-EntraUser -Filter "mail eq '$user'"
            $SPNAppId = $adUser.ObjectId
            New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope" -Verbose
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT USER" -Verbose
                New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
            Continue;
        }
    }
    catch {
        if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
            Write-Warning  "Duplicate role assignment detected. <$SPNAppId> is already a <$azureRole> at scope $scope"
            Continue;
        }
        else {
            throw  $_
        } 
    }

    try {
        
        if (Get-EntraGroup -Filter "DisplayName eq '$user'") {
            $adGroup = Get-EntraGroup -Filter "DisplayName eq '$user'";
            $SPNAppId = $adGroup.ObjectId
            New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope"
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT GROUP" -Verbose
                New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
            Continue;
        }
    }
    catch {
        if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
            Write-Warning  "Duplicate role assignment to group detected. <$SPNAppId> is already a <$azureRole> at scope $scope"
            Continue;
        }
        else {
            throw  $_
        } 
    }

    try {

        if (Get-AzADServicePrincipal -Filter "DisplayName eq '$user'") {
            $adSPN = Get-AzADServicePrincipal -Filter "DisplayName eq '$user'";
            $SPNAppId = $adSPN.AppId
            New-AzRoleAssignment -ApplicationId $SPNAppId -RoleDefinitionName $azureRole -Scope $scope
            Write-verbose  "Role assignment <$azureRole> for <$SPNAppId> created at scope $scope"
            if ($azureRole -eq 'Reader') {
                Write-Verbose "TEST JIT SPN" -Verbose
                New-AzRoleAssignment -ApplicationId $SPNAppId -RoleDefinitionName 'JIT VM Access Role' -Scope $scope
                Write-verbose  "Role assignment <JIT VM Access Role> for <$SPNAppId> created at scope $scope" -Verbose
            }
        }
        else { 
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "No users, AD Groups, or SPNs could be found with this name: $user")
            throw "No users, AD Groups, or SPNs could be found with this name: $user" }
    }
    
    catch {
        if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
            Write-Warning  "Duplicate role assignment to group detected. <$SPNAppId> is already a <$azureRole> at scope $scope"
        }
        else {
            throw  $_
        } 
    }


    

}
