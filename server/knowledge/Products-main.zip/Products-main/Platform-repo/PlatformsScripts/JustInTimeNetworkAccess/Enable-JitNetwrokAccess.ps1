﻿<#
.SYNOPSIS
    Add a Virtual Machine to Azure Defender Just In Time Access with pre-set Access configuration policy.

.DESCRIPTION
    When ADT provisions their Virtual Machine, this assoicated script will check and enable Azure Security center Srtandrd Tier
    Then create a Policy with following configuration and enable associated Virtual Machine

        Source Address : Bastion Hosts
        Max Hours : 8 hours
        port/protocol  22,3389/TCP

.PARAMETER VMName
    Virtual Machine in scope for configuration

.PARAMETER SubscriptionId
    Subscription Id Virtual Machine in scope

.PARAMETER ResourceGroup
    Virtual Machine and Configuation policy Resource group Location

.PARAMETER maxDuration
    Configuation policy Maximum hours allowed to enable network access

.EXAMPLE

#>
param(

    [string]$vmName ,
    [string]$SubscriptionId ,
    [string]$ResourceGroup ,
    [int]$maxDuration 
    
)

$ErrorActionPreference = 'Stop'


$sourceIP =  @{
    "eastus2" = [System.Collections.Generic.List[string]]("10.82.3.192/27","10.82.195.192/27")
    "centralus" = [System.Collections.Generic.List[string]]("10.82.3.192/27","10.82.195.192/27")
    "uksouth" = [System.Collections.Generic.List[string]]("10.83.3.192/27","10.83.195.192/27")
    "ukwest" = [System.Collections.Generic.List[string]]("10.83.3.192/27","10.83.195.192/27")
    }

try {

    Set-AzContext -SubscriptionId $SubscriptionId

    $vm = Get-AzVM -ResourceGroupName $resourceGroup -Name $vmName


    $jitPolicy = (@{
            Id    = $vm.Id
            ports = (
                @{
                    number                     = 22;
                    protocol                   = "TCP";
                    AllowedSourceAddressPrefixes = $sourceIP[$vm.Location];
                    maxRequestAccessDuration   = "PT$($maxDuration)H"
                },
                @{
                    number                     = 3389;
                    protocol                   = "TCP";
                    AllowedSourceAddressPrefixes=  $sourceIP[$vm.Location];
                    maxRequestAccessDuration   = "PT$($maxDuration)H"
                })
        }
    )


    if ( -not (Get-Module -ListAvailable | Where-Object { $_.Name -eq 'Az.Security' })) {
        Install-Module -Name Az.Security -Scope CurrentUser -Force -AllowClobber
    }

    if ((Get-AzSecurityPricing -Name 'VirtualMachines').PricingTier -eq 'Free') {
        set-AzSecurityPricing -PricingTier standard -Name 'VirtualMachines'
    }
    
    $vmJitStatus = Get-AzJitNetworkAccessPolicy -ResourceGroupName $resourceGroup | Where-Object { $_.Name -eq $vmName -and $_.ProvisioningState -eq "Succeeded" } 
    Write-Output $vmJitStatus 

    if (-not $vmJitStatus) {
        $networkAccessPolicyParam = @{
            Name              = $vm.Name 
            ResourceGroupName = $vm.ResourceGroupName 
            Location          = $vm.Location
            Kind              = "Basic"
            VirtualMachine    = @($JitPolicy)
        }
        $status = Set-AzJitNetworkAccessPolicy -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Location $vm.Location -VirtualMachine @($JitPolicy) -Kind "Basic"

        if (-not $err) {
            while ($status.ProvisioningState -eq 'Updating') {
                Start-Sleep 10
                $networkAccessPolicyParam = @{
                    Name              = $vm.Name 
                    ResourceGroupName = $vm.ResourceGroupName 
                    Location          = $vm.Location
                }
                $status = Get-AzJitNetworkAccessPolicy @networkAccessPolicyParam 
            }
        }
        Write-output $status       
    }                  
}
catch {
    throw "Error | Exception `n$_"
}
