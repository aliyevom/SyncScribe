﻿<#
.SYNOPSIS
    Setup Network access to a Virtual Machine .

.DESCRIPTION
    When ADT requires network access to their Virtual Machine, this script will enable Azure Security center associated
    configuration Policy and enables network access accordingly.


.PARAMETER VMName
    Virtual Machine in scope for configuration

.PARAMETER SubscriptionId
    Subscription Id Virtual Machine in scope

.PARAMETER ResourceGroup
    Virtual Machine and Configuation policy Resource group Location

.PARAMETER accessDuration
    Configuation Requested Access hours

.EXAMPLE

#>
Param(
    [int]$accessDuration,
    [string]$SubscriptionId,
    [string]$ResourceGroup,
    [string]$vmName
)

$ErrorActionPreference = 'Stop'

$sourceIP =  @{
    "eastus2" = [System.Collections.Generic.List[string]]("10.82.3.192/27","10.82.195.192/27")
    "centralus" = [System.Collections.Generic.List[string]]("10.82.3.192/27","10.82.195.192/27")
    "uksouth" = [System.Collections.Generic.List[string]]("10.83.3.192/27","10.83.195.192/27")
    "ukwest" = [System.Collections.Generic.List[string]]("10.83.3.192/27","10.83.195.192/27")
    }

try {

    Set-AzContext -SubscriptionId $SubscriptionId
    #
    # Install Security Prerequisits
    #
    if ( -not (Get-Module -ListAvailable | Where-Object { $_.Name -eq 'Az.Security' })) {
        Install-Module -Name Az.Security -Scope CurrentUser -Force -AllowClobber
    }

    $vm = Get-AzVM -ResourceGroupName $resourceGroup -Name $vmName

    $endTime = (Get-Date).AddHours($accessDuration).ToUniversalTime()
    $servicePort = 3389

    $osProfile = $vm.OSProfile.WindowsConfiguration
    if ($null -eq $osProfile) {
        $servicePort = 22
    }
    #
    #   requesting access and selecting VM's bastion host region source IPs
    #


    $JitVmPolicy = (@{
            id    = $vm.Id
            ports = (@{
                    number                     = $servicePort;
                    allowedSourceAddressPrefix = $sourceIP[$vm.Location];
                    endTimeUtc                 = $endTime
                })
        })

    $networkAccessParam = @{
        ResourceGroupName = $resourceGroup
        Location          = $vm.location 
        Name              = $vm.Name
        VirtualMachine    = @($JitVmPolicy) 
    } 
    Start-AzJitNetworkAccessPolicy @networkAccessParam 
}
catch {
    throw "Error | `n$_"
}
      




