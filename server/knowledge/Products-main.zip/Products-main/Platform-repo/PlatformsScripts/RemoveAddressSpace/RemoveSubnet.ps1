param(
    [string]$subnetname,
    [string]$resourcename,
    [string]$resourcegroupname,
    [string]$vnetname
)

$vnet = Get-AzVirtualNetwork -Name $vnetname -ResourceGroupName $resourcegroupname

Write-Output $vnet

Remove-AzVirtualNetworkSubnetConfig -Name $subnetname -VirtualNetwork $vnet

$vnet | Set-AzVirtualNetwork

