param(
    [string]$removeaddress,
    [string]$vnetname,
    [string]$resourcegroupname,
    [string]$hubvnetname,
    [string]$hubresourcegroupname
)



# Get the virtual network object 
$vnet = Get-AzVirtualNetwork -Name $vnetname -ResourceGroupName $resourcegroupname

#  Remove the specified address space
$vnet.AddressSpace.AddressPrefixes = $vnet.AddressSpace.AddressPrefixes | Where-Object { $_ -ne $removeaddress }

#  Update the virtual network
Set-AzVirtualNetwork -VirtualNetwork $vnet

Write-Output "Removed address space: $removeaddress"
Write-Output "Updated address prefixes: $($vnet.AddressSpace.AddressPrefixes)"


<#

# Resync only local peerings that are not connected
$peerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname
foreach ($peering in $peerings) {
    if ($peering.PeeringState -ne "Connected") {
        Sync-AzVirtualNetworkPeering -Name $peering.Name -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname
        Write-Output "Resynced peering: $($peering.Name)"
    }
}



# Resync only remote peerings that are not connected
$hubpeerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $hubvnetname -ResourceGroupName $hubresourcegroupname
foreach ($hubpeering in $hubpeerings) {
    if ($hubpeering.PeeringState -ne "Connected") {
        Sync-AzVirtualNetworkPeering -Name $hubpeering.Name -VirtualNetworkName $hubvnetname -ResourceGroupName $hubresourcegroupname
        Write-Output "Resynced peering: $($hubpeering.Name)"
    }
}



#Test remote peering sync automation: 



$hubvnets = Get-AzVirtualNetworkPeering -VirtualNetworkName 5874-dev-cus-vnet-01 -ResourceGroupName 5874-DEV-cus-spokenetwork-rg | ForEach-Object { ($_.RemoteVirtualNetwork.Id -split "/")[-1] }
    foreach ($hubvnet in $hubvnets) {
        $subscriptionname = (get-Azvirtualnetwork -Name $hubvnet).$subscriptionname
        $hubresourcegroupname = (get-Azvirtualnetwork -Name $hubvnet).ResourceGroupName
        $hubpeerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $hubvnet -ResourceGroupName $hubresourcegroupname
        foreach ($hubpeering in $hubpeerings) {
            if ($hubpeering.PeeringState -ne "Connected") {
                Sync-AzVirtualNetworkPeering -Name $hubpeering.Name -VirtualNetworkName $hubvnet -ResourceGroupName $hubresourcegroupname
                Write-Output "Resynced peering: $($hubpeering.Name)"
    }
}
}







#old resync all: 



# Resync all local peerings  in a virtual network
$peerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname

foreach ($peering in $peerings) {
    Sync-AzVirtualNetworkPeering -Name $peering.Name -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname
    Write-Output "Resynced peering: $($peering.Name)"   
}

# Resync all remote peerings in a virtual network

$hubpeerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $hubvnetname -ResourceGroupName $hubresourcegroupname

foreach ($hubpeering in $hubpeerings) {
    Sync-AzVirtualNetworkPeering -Name $hubpeering.Name -VirtualNetworkName $hubvnetname -ResourceGroupName $hubresourcegroupname
    Write-Output "Resynced peering: $($hubpeering.Name)"   
}

#>








