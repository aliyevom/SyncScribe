param(
    [string]$lockname,
    [string]$vnetname,
    [string]$resourcegroupname
)


$lockid = (get-AzResourceLock -LockName $lockname -ResourceName $vnetname -ResourceType "Microsoft.Network/virtualNetworks" -ResourceGroupName $resourcegroupname | Select-Object -ExpandProperty ResourceId)


Remove-AzResourceLock -LockId $lockid





#Remove-AzResourceLock -LockName $lockname -ResourceGroupName $resour cegroupname -ResourceName $vnetID 

#-ResourceType 'Microsoft.Network/virtualNetworks'


#Remove-AzResourceLock -LockName xTestLock' -ResourceGroupName '5874-DEV-cus-spokenetwork-rg' -ResourceName '/subscriptions/605/resourceGroups/5874-DEV-cus-spokenetwork-rg/providers/Microsoft.Network/virtualNetworks/5874-dev-cus-vnet-01/providers/Microsoft.Authorization/locks/TestLock' -ResourceType 'Microsoft.Network/virtualNetworks' 