
param(
    [string]$vnetname,
    [string]$resourcegroupname
)



# Resync only local peerings that are not connected
$peerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname
foreach ($peering in $peerings) {
    if ($peering.Peeringsynclevel -ne "FullyInSync") {
        Sync-AzVirtualNetworkPeering -Name $peering.Name -VirtualNetworkName $vnetname -ResourceGroupName $resourcegroupname
        Write-Output "Resynced peering: $($peering.Name)"
    }
}
