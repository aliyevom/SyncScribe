
param(
    [string]$lockname,
    [string]$vnetname,  
    [string]$resourcegroupname
)


New-AzResourceLock -LockLevel CanNotDelete -LockNotes "CanNotDelete" -LockName $lockname -ResourceName $vnetname -ResourceType "Microsoft.Network/virtualNetworks" -ResourceGroupName $resourcegroupname