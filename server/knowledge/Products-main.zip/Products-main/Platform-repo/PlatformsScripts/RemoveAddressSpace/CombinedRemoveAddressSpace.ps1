
param(
    [string]$removeaddress,
    [string]$vnetname,
    [string]$resourcegroupname, 
    [string]$hubvnetname,
    [string]$hubresourcegroupname,
    [string]$lockname,
    [string]$subnetname

)

# Run scripts in order:


& "PlatformsScripts/Dev/removelock.ps1" -lockname $lockname -resourcegroupname $resourcegroupname -vnetname $vnetname
& "PlatformsScripts/Dev/RemoveSubnet.ps1" -subnetname $subnetname -vnetname $vnetname -resourcegroupname $resourcegroupname
& "PlatformsScripts/Dev/Removeaddressspace.ps1" -removeaddress $removeaddress -vnetname $vnetname -resourcegroupname $resourcegroupname -hubvnetname $hubvnetname -hubresourcegroupname $hubresourcegroupname
& "PlatformsScripts/Dev/ResyncRemotePeers.ps1" -vnetname $vnetname -resourcegroupname $resourcegroupname -hubvnetname $hubvnetname -hubresourcegroupname $hubresourcegroupname
& "PlatformsScripts/Dev/addlock.ps1" -lockname $lockname -vnetname $vnetname
