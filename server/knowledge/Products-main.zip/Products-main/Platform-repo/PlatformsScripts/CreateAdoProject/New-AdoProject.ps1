<#
.SYNOPSIS
    Creates a new Azure DevOps project and ARM Service Connection for the Application Team

.DESCRIPTION
    Creates a new Azure DevOps project and ARM Service Connection for the Application Team

.PARAMETER OrganizationName
    Specifies the name of the Azure DevOps organization where the project has to be created
    https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/organization-management?view=azure-devops

.PARAMETER ProjectName
    Specifies the name of the Azure DevOps project to create
    https://docs.microsoft.com/en-us/azure/devops/organizations/projects/about-projects?view=azure-devops

.PARAMETER ProcessTemplate
    Specifies the process template type of the Azure DevOps project to create (Agile / Basic / CMMI / Scrum)
    https://docs.microsoft.com/en-us/azure/devops/boards/work-items/guidance/choose-process?view=azure-devops

.PARAMETER SourceControlType
    Specifies the source control type of the Azure DevOps project to create (Git / TFVC)
    https://docs.microsoft.com/en-us/azure/devops/repos/tfvc/comparison-git-tfvc?view=azure-devops

.PARAMETER PrincipalName
   The user who has to be provided Access(Project Administrator) on the Azure DevOps Project

.PARAMETER SubscriptionId
   The subscription ID for which ARM Service Connection should be scoped to

.PARAMETER SubscriptionName
   The subscription name for which ARM Service Connection should be scoped to

.PARAMETER TenantId
   The Tenant ID for which ARM Service Connection should be scoped to

.PARAMETER KeyVaultName
   The Tenant ID for which ARM Service Connection should be scoped to

.PARAMETER ServicePrincipalName
   Service Principal Name for Service Connection

.EXAMPLE

.NOTES
	Version      : 1.0.0
	Last Updated : 2/4/2021
#>

[CmdletBinding(SupportsShouldProcess = $false)]
PARAM(
    [Parameter(Mandatory = $true, Position = 0,
        HelpMessage = 'The name of the Azure DevOps organization to create')]
    [ValidateNotNullOrEmpty()]
    [Alias('Company')]
    [string] $OrganizationName,

    [Parameter(Mandatory = $true, Position = 1,
        HelpMessage = 'The name of the project to create')]
    [string] $ProjectName,

    [Parameter(Mandatory = $false, Position = 2,
        HelpMessage = 'The process template for the project (Agile)')]
    [ValidateSet('Agile', 'Basic', 'CMMI', 'Scrum')]
    [Alias('Template')]
    [string] $ProcessTemplate = 'Agile',

    [Parameter(Mandatory = $false, Position = 3,
        HelpMessage = 'The version control system type for the project (Git)')]
    [ValidateSet('Git', 'TFVC')]
    [Alias('VersionControlType')]
    [string] $SourceControlType = 'Git',

    [Parameter(Mandatory = $true, Position = 4,
        HelpMessage = 'User who has to be made Project Admin')]
    [string] $PrincipalName,

    [Parameter(Mandatory = $true, Position = 5,
        HelpMessage = 'PAT Token Secret Name in keyvault')]
    [string] $PATSecret,

    [Parameter(Mandatory = $true, Position = 6,
        HelpMessage = 'The subscription ID for which ARM Service Connection should be scoped to')]
    [ValidatePattern('[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}')]
    [string] $SubscriptionId,
    
    [Parameter(Mandatory = $true, Position = 7,
        HelpMessage = 'The subscription name for which ARM Service Connection should be scoped to')]
    [string] $SubscriptionName, 

    [Parameter(Mandatory = $true, Position = 8,
        HelpMessage = 'The Tenant ID for which ARM Service Connection should be scoped to')]
    [string] $TenantId,

    [Parameter(Mandatory = $true, Position = 9,
        HelpMessage = 'Key Vault Name to get PAT secrets')]
    [string] $KeyVaultName,

    [Parameter(Mandatory = $true, Position = 10,
        HelpMessage = 'Service Principal Name for Service Connection')]
    [string] $ServicePrincipalName

    
)

$UpperSubscriptionName = $SubscriptionName.ToUpper()
# Get Keyvault Secrets
try {

    $appID = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $($ServicePrincipalName.ToUpper() + "-appId") `
        -ErrorAction SilentlyContinue;

    $spnPassword = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $($ServicePrincipalName.ToUpper() + "-Password") `
        -ErrorAction SilentlyContinue;

    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecret `
        -ErrorAction SilentlyContinue;

    $ApplicationID = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($appID.SecretValue)
    $ApplicationIDText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ApplicationID)

   
    $ServicePrincipalPasswd = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($spnPassword.SecretValue)
    $ServicePrincipalPasswdText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ServicePrincipalPasswd)

    $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
    $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)

}
catch {
    throw $_;
}
# Create header with PAT
$token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
$header = @{authorization = "Basic $token" }

function Get-AzAdoProcessTemplate {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName
    )
    try {
        Write-Verbose "Querying for the Azure DevOps project process template identifiers"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/_apis/process/processes?api-version=6.0"
            ContentType     = 'application/json'
        }; $output = Invoke-RestMethod @params -SkipHttpErrorCheck
    }
    catch {
        throw $_
    }
   
    return $output.value
}

function Get-AzAdoProject {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName
    )

    try {
        Write-Verbose "Querying for the Azure DevOps project existence"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/_apis/projects/$ProjectName ?api-version=6.0"
            ContentType     = 'application/json'
        }; $output = Invoke-RestMethod @params -SkipHttpErrorCheck 
    }
    catch {
        throw $_
    }
    
    return $output
}
 
function New-AzAdoProject {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $ProcessTemplateId,
        [Parameter(Mandatory = $true)] [string] $SourceControlType
    )

    try {
      
        Write-Verbose "Creating a new Azure DevOps project named '$ProjectName'"
        $body = @"
   {
       "name": "$ProjectName",
       "description": "$ProjectName",
       "capabilities": {
           "versioncontrol": {
               "sourceControlType": "$SourceControlType"
           },
           "processTemplate": {
               "templateTypeId": "$ProcessTemplateId"
           }
       }
   }
"@
        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/_apis/projects?api-version=6.0"
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params

        $checkStatusUrl = $output.url
        $iMaxTimesToWait = 2
        do {
            Start-Sleep -Seconds 10
            $iMaxTimesToWait--
            $params = @{
                Method          = 'GET'
                UseBasicParsing = $true
                Headers         = $header
                Uri             = $checkStatusUrl
            }; $output = Invoke-RestMethod @params
        } while (-not (($output.status -eq 'succeeded') -or ($iMaxTimesToWait -eq 0)))

        if ($output.status -eq 'succeeded') {
            $params = @{
                Method          = 'GET'
                UseBasicParsing = $true
                Headers         = $header
                Uri             = "https://dev.azure.com/$OrganizationName/_apis/projects?`$top=999"
            }; 
            $output = Invoke-RestMethod @params
            $project = $output.value | Where-Object { $_.name -eq $ProjectName }

            [PSCustomObject] @{
                OrganizationName  = $OrganizationName
                ProjectName       = $project.name
                ProjectId         = $project.id
                ProjectUri        = "https://dev.azure.com/$OrganizationName/$ProjectName"
                ProcessTemplateId = $ProcessTemplateId
                SourceControlType = $SourceControlType
                State             = $project.state
            }
        }
        else {
            $null
        }
    

    }
    catch {
        throw $_
    }


}

function Set-AzAdoProjectFeatures {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectId
    )

    try {
      
        # Disable Azure Boards, Azure Test Plans and Azure Artifacts in the Project
        $body = @"
{
    "featureId":"ms.vss-work.agile",
    "scope":{"userScoped":false,"settingScope":"project"},
    "state":"disabled"
}


"@
        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/_apis/FeatureManagement/FeatureStates/host/project/$ProjectId/ms.vss-work.agile?api-version=6.0-preview.1" -ContentType 'application/json' -Body $body -SkipHttpErrorCheck

        $body = @"
{
"featureId":"ms.vss-test-web.test",
"scope":{"userScoped":false,"settingScope":"project"},
"state":"disabled"
}
"@

        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/_apis/FeatureManagement/FeatureStates/host/project/$ProjectId/ms.vss-test-web.test?api-version=6.0-preview.1" -ContentType 'application/json' -Body $body -SkipHttpErrorCheck


        $body = @"
{
"featureId":"ms.feed.feed",
"scope":{"userScoped":false,"settingScope":"project"},
"state":"disabled"
}
"@

        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/_apis/FeatureManagement/FeatureStates/host/project/$ProjectId/ms.feed.feed?api-version=6.0-preview.1" -ContentType 'application/json' -Body $body -SkipHttpErrorCheck
    }
    catch {
        throw $_
    }

    return $output
}


function New-AzAdoProjectAddUser {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $ProjectId,
        [Parameter(Mandatory = $true)] [string] $PrincipalName
    )

    try {
      
        Write-Verbose "Make $PrinicipalName Project administrator in '$ProjectName'"
        $body = @"
   {
       "accessLevel": {
         "accountLicenseType": "express"
       },
       "extensions": [
         {
           "id": "ms.feed"
         }
       ],
       "user": {
         "principalName": "$PrincipalName",
         "subjectKind": "user"
       },
       "projectEntitlements": [
         {
           "group": {
             "groupType": "projectAdministrator"
           },
           "projectRef": {
             "id": "$ProjectId"
           }
         }
       ]
     }
"@
        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://vsaex.dev.azure.com/$OrganizationName/_apis/userentitlements?api-version=6.0-preview.3"
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params
    }
    catch {
        throw $_
    }

    return $output
}

function Get-AzAdoArmServiceConnection {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName
    )

    try {
        Write-Verbose "Querying for the ARM Service EndPoint Existence"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/serviceendpoint/endpoints?type=AzureRM&?api-version=6.1-preview.4"
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params -SkipHttpErrorCheck
    }
    catch {
        throw $_
    }
    
    return $output
}
function New-AzAdoArmServiceConnection {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $ProjectId,
        [Parameter(Mandatory = $false)] [string] $PrincipalName,
        [Parameter(Mandatory = $false)] [string] $SubscriptionId,
        [Parameter(Mandatory = $false)] [string] $SubscriptionName,
        [Parameter(Mandatory = $false)] [string] $TenantId,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalId,
        [Parameter(Mandatory = $false)] [string] $ServicePrincipalKey
    )

    try {
        Write-Verbose "Create a ARM Service Connection in $ProjectName"

        $ServiceConnectionName = $SubscriptionName.Replace("'", "")

        $body = @"
   {
      "data": {
        "subscriptionId": "$SubscriptionId",
        "subscriptionName": "$SubscriptionName",
        "environment": "AzureCloud",
        "scopeLevel": "Subscription",
        "creationMode": "Manual"
      },
      "name": "$ServiceConnectionName-SC",
      "type": "AzureRM",
      "url": "https://management.azure.com/",
      "authorization": {
        "parameters": {
          "tenantid": "$TenantId",
          "serviceprincipalid": "$ServicePrincipalId",
          "authenticationType": "spnKey",
          "serviceprincipalkey": "$ServicePrincipalKey"
        },
        "scheme": "ServicePrincipal"
      },
      "isShared": false,
      "isReady": true,
      "serviceEndpointProjectReferences": [
        {
          "projectReference": {
            "name": "$ProjectId"
          },
          "name": "$ServiceConnectionName-SC"
        }
      ]
    }    
"@

        Write-Debug $body

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/serviceendpoint/endpoints?api-version=5.1-preview.2"
            ContentType     = "application/json"
        }; $output = Invoke-RestMethod @params
 
        $output

        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/serviceendpoint/endpoints?api-version=5.1-preview.2"
        }; 
        $output = Invoke-RestMethod @params
    }
    catch {
        throw $_
    }

    return $output.value 
}

function Get-JobAuthScope {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName
    )
    try {
        Write-Verbose "Querying for the Azure DevOps Build General Settings - enforceJobAuthScope"
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/build/generalsettings?api-version=6.0-preview.1"
            ContentType     = 'application/json'
        }; $output = Invoke-RestMethod @params 
    }
    catch {
        throw $_
    }
   
    return $output.enforceJobAuthScope
}

function Set-JobAuthScope {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName
    )

    try {
      
        # Disable enforceJobAuthScope
        $body = @"
{
    "enforceJobAuthScope":"False",

}

"@
        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/build/generalsettings?api-version=6.0-preview.1" -ContentType 'application/json' -Body $body -SkipHttpErrorCheck

    }
    catch {
        throw $_
    }

    return $output
}

$params = @{
    OrganizationName  = $OrganizationName
    SubscriptionId    = $SubscriptionId
    ResourceGroupName = $ResourceGroupName
    Location          = $Location
}; 

# Get the selected process template id
$templates = Get-AzAdoProcessTemplate -OrganizationName $OrganizationName
$processTemplateId = ($templates | Where-Object { $_.name -eq $ProcessTemplate }).id
if ($null -eq $processTemplateId) {
    Write-Warning "There was an error selecting the process template type"
    exit 7
}

$adoProjectExist = Get-AzAdoProject -ProjectName $ProjectName -OrganizationName $OrganizationName

if ( $adoProjectExist.typeKey -eq 'ProjectDoesNotExistWithNameException' ) {

    # Create the ADO Project
    $params = @{
        OrganizationName  = $OrganizationName
        ProjectName       = $ProjectName
        ProcessTemplateId = $ProcessTemplateId
        SourceControlType = $SourceControlType
    }; $adoProject = New-AzAdoProject @params
    if ($null -eq $adoProject) {
        Write-Warning "There was an error creating the Azure DevOps project"
        exit 8
    }
    else {
        $adoProject
    }

    # Disable Features
    $params = @{
        OrganizationName = $OrganizationName
        ProjectId        = $adoProject.ProjectId
    }; $adoProjectFeatures = Set-AzAdoProjectFeatures @params
    if ($null -eq $adoProjectFeatures) {
        Write-Host "There was an error disabling features in the Azure DevOps project"
        exit 9
    }
    else {
        $adoProjectFeatures
    }

    # Disable enforceJobAuthScope Pipeline Setting

    $enforceJobAuthScopeValue = Get-JobAuthScope -OrganizationName $OrganizationName -ProjectName $ProjectName

    if ($enforceJobAuthScopeValue -eq "False") {

        $params = @{
            OrganizationName = $OrganizationName
            ProjectName      = $ProjectName
        }; $adoProjectJobAuth = Set-JobAuthScope @params

        if ($null -eq $adoProjectJobAuth) {
            Write-Verbose "There was an error disabling enforceJobAuthScope in the Azure DevOps project" -Verbose
            exit 9
        }
        else {
            $adoProjectJobAuth
        }

    }

    # Make user Project Administrator
    $params = @{
        OrganizationName = $OrganizationName
        ProjectName      = $ProjectName
        ProjectId        = $adoProject.ProjectId 
        PrincipalName    = $PrincipalName
    }; $adoProjectUser = New-AzAdoProjectAddUser @params
    if ($null -eq $adoProjectUser) {
        Write-Warning "There was an error adding user to the Azure DevOps project"
        exit 10
    }
    else {
        $adoProjectUser
    }
    
}

else {

    $adoProjectName = $adoProjectExist.name
    Write-Warning "ADO Project '$adoProjectName' already exists"
}



$adoARMServiceConnectionExists = Get-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $ProjectName

$armServiceConnectionName = $($UpperSubscriptionName + "-SC")
if ( $adoARMServiceConnectionExists.value.name -eq $armServiceConnectionName ) {
    
    $armSCName = $adoARMServiceConnectionExists.value.name
    Write-Warning "ARM Service Connection '$armSCName' already exists"
}

else {
    
    if ($adoProject) {
        #Create ARM Service Connection for new ADO Project
        $adoProjectSC = New-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $adoProject.ProjectName -ProjectId $adoProject.ProjectId -PrincipalName $PrincipalName -SubscriptionId $SubscriptionId -SubscriptionName $UpperSubscriptionName -TenantId $TenantId -ServicePrincipalId $ApplicationIDText -ServicePrincipalKey $ServicePrincipalPasswdText

    }
    else {
        #Create ARM Service Connection for existing ADO Project
        $adoProjectSC = New-AzAdoArmServiceConnection -OrganizationName $OrganizationName -ProjectName $adoProjectExist.name -ProjectId $adoProjectExist.id -PrincipalName $PrincipalName -SubscriptionId $SubscriptionId -SubscriptionName $UpperSubscriptionName -TenantId $TenantId -ServicePrincipalId $ApplicationIDText -ServicePrincipalKey $ServicePrincipalPasswdText

    }
    
    if ($null -eq $adoProjectSC) {
        Write-Warning "There was an error creating the Service Connection"
        exit 11
    }
    else {
        $adoProjectSC
    }

}


#endregion

