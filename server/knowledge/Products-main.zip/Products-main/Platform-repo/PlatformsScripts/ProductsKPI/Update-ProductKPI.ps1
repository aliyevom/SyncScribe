<#
.SYNOPSIS
    Update Product Work Item with Package Download and Unique User Metrics

.DESCRIPTION
    Update Product Work Item with Package Download and Unique User Metrics

.PARAMETER OrganizationName
    Specifies the name of the Azure DevOps organization where the project has to be created
    https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/organization-management?view=azure-devops

.PARAMETER ProjectName
    Specifies the name of the Azure DevOps project to create
          
.PARAMETER PATSecret
    PAT Token Secret Name in keyvault

.PARAMETER KeyVaultName
   Key Vault Name to get PAT secrets

.PARAMETER SubscriptionId
   Subscription ID where keyvault exists

.EXAMPLE

.NOTES
	Version      : 1.0.0
	Last Updated : 4/5/2021
#>

[CmdletBinding(SupportsShouldProcess = $false)]
PARAM(
    [Parameter(Mandatory = $true, Position = 0,
        HelpMessage = 'The name of the Azure DevOps organization')]
    [ValidateNotNullOrEmpty()]
    [Alias('Company')]
    [string] $OrganizationName = "NGRID",

    [Parameter(Mandatory = $true, Position = 1,
        HelpMessage = 'The name of the project')]
    [string] $ProjectName = "CCOE",

    [Parameter(Mandatory = $true, Position = 2,
        HelpMessage = 'PAT Token Secret Name in keyvault')]
    [string] $PATSecret,

    [Parameter(Mandatory = $true, Position = 3,
        HelpMessage = 'Key Vault Name to get PAT secrets')]
    [string] $KeyVaultName,
    
    [Parameter(Mandatory = $true, Position = 4,
        HelpMessage = 'Sub ID')]
    [string] $SubscriptionId
    
)


# Below function retuns the Package ID
function Get-PackageIdFromName {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $PackageName
    )
    try {
        Write-Verbose "Querying to get Azure Artifact Package ID for $PackageName" -Verbose
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://feeds.dev.azure.com/$OrganizationName/$ProjectName/_apis/packaging/Feeds/Products/packages?packageNameQuery=$PackageName&api-version=6.0-preview.1"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params 

        $output.value
    }
    catch {
        throw $_
    }
   
    return $output
}

# Function Returns Package metrics by accessing $output.value.downloadCount and $output.value.downloadUniqueUsers 
function Get-PackageMetrics {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $PackageName,
        [Parameter(Mandatory = $false)] [array] $PackageId
    )
    try {
        Write-Verbose "Querying to fetch Package Metrics for $PackageName with PackageID $PackageId" -Verbose
        $body = @"
        {
            "packageIds": ["$PackageId"]
          }          
"@

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://feeds.dev.azure.com/$OrganizationName/$ProjectName/_apis/packaging/Feeds/Products/packagemetricsbatch?api-version=6.0-preview.1"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params

        $output.value
    }
    catch {
        throw $_
    }
    
    return $output
}

# Function Prints Work Item details
function Get-WorkItemDetails {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $false)] [string] $ProductWorkItemId
    )

    try {
        Write-Verbose "Querying to fetch Work Item details for Work Item number: $ProductWorkItemId" -Verbose
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/wit/workitems/$ProductWorkItemId ?expand=fields&api-version=6.0"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params

        Write-Verbose "$output" -Verbose
        
    }
    catch {
        throw $_
    }
    
    return $output
}

# Function to set Product Metrics in Product Epic
function Set-ProductMetrics {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrganizationName,
        [Parameter(Mandatory = $true)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $ProductWorkItemId,
        [Parameter(Mandatory = $true)] [string] $DownloadCount,
        [Parameter(Mandatory = $true)] [string] $UniqueUserCount,
        [Parameter(Mandatory = $true)] [string] $PackageName
    )

    try {
      
        $body = @"
        [
            {
                "op": "add",
                "path": "/fields/Custom.DownloadCount",
                "value": "$DownloadCount"
            },
            {
                "op": "add",
                "path": "/fields/Custom.UniqueUserCount",
                "value": "$UniqueUserCount"
            }
            ]
"@
        Write-Verbose "Updating Product Metrics for $PackageName" -Verbose

        Invoke-RestMethod -Method Patch -UseBasicParsing -Headers $header -Uri "https://dev.azure.com/$OrganizationName/$ProjectName/_apis/wit/workitems/$ProductWorkItemId ?api-version=6.0" -ContentType "application/json-patch+json" -Body $body 

        Write-Verbose "Updated Product Metrics for $PackageName" -Verbose

    }
    catch {
        throw $_
    }

}

# Function to get Work item ID for each Product ($output.workItems.id)
function Get-ProductsWorkItemId {
    PARAM(
        [Parameter(Mandatory = $false)] [string] $OrganizationName,
        [Parameter(Mandatory = $false)] [string] $ProjectName,
        [Parameter(Mandatory = $true)] [string] $TeamName
    )
    try {
        Write-Verbose "Querying to get Product List with WIQL Query" -Verbose
        $body = @"
        {
            "query": "Select [System.Id], [System.Title], [System.State] From WorkItems Where [System.WorkItemType] = 'Product'"
          }          
"@

        $params = @{
            Method          = 'POST'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $header
            Uri             = "https://dev.azure.com/$OrganizationName/$ProjectName/$TeamName/_apis/wit/wiql?api-version=6.0"
            ContentType     = "application/json"
        }; 
        
        $output = Invoke-RestMethod @params

        $output.workItems.id
    }
    catch {
        throw $_
    }
    
    return $output
}




try {

    # Get Keyvault Secrets
    
    Set-AzContext -Subscription $SubscriptionId   

    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecret

    $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
    try {
        $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($PATSecret)
    }

    # Create header with PAT
    $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $header = @{authorization = "Basic $token" }

    # Get Work item ID for each Product

    $productWorkItems = Get-ProductsWorkItemId -OrganizationName $OrganizationName -ProjectName $ProjectName -TeamName "Product Team"

    $workItemsIds = $productWorkItems.workItems.id

    Write-Verbose "List of Product Epic WorkItem Ids: $workItemsIds" -Verbose

    foreach ($id in $workItemsIds) {

        # Get Product Epic WI details

        $workItem = Get-WorkItemDetails -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id

        $artifactMoniker = $workItem.fields.PSObject.Properties["Custom.ArtifactMoniker"].value

        if ($artifactMoniker) {
            # Get Package ID
            $Package = Get-PackageIdFromName -OrganizationName $OrganizationName -ProjectName $ProjectName -PackageName $artifactMoniker
            $PackageId = $Package.value.id
            if ($null -eq $PackageId) {
                Write-Warning "There was an error getting the Package ID. The package:$artifactMoniker may not exist in the feed" -Verbose

            }
            else {
                Write-Verbose "Package ID for $artifactMoniker is $PackageId" -Verbose
            }

            # Get Package Metrics
            $PackageMetrics = Get-PackageMetrics -OrganizationName $OrganizationName -ProjectName $ProjectName -PackageName $artifactMoniker -PackageId $PackageId
            if ($null -eq $PackageMetrics) {
                Write-Warning "There was an error getting the Package Metrics" -Verbose

            }

            # Set Product Metrics
            if ($PackageMetrics.count -eq 0) {

                Write-Warning "There has been no downloads/unique users for $artifactMoniker"-Verbose 
                Write-Verbose "Setting Download Count and Unique User Count as 0" -Verbose
                $DownloadCount = 0
                $UniqueUserCount = 0
                Set-ProductMetrics -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id -DownloadCount $DownloadCount.ToString() -UniqueUserCount $UniqueUserCount.ToString() -PackageName $artifactMoniker
            }

            else {

                $DownloadCount = $PackageMetrics.value.downloadCount[0]
                $UniqueUserCount = $PackageMetrics.value.downloadUniqueUsers[0]
                Write-Verbose "Download Count for $artifactMoniker is: $DownloadCount" -Verbose
                Write-Verbose "Unique User Count for $artifactMoniker is: $UniqueUserCount" -Verbose
                Set-ProductMetrics -OrganizationName $OrganizationName -ProjectName $ProjectName -ProductWorkItemId $id -DownloadCount $DownloadCount.ToString() -UniqueUserCount $UniqueUserCount.ToString() -PackageName $artifactMoniker
            }

        }

        else {
            
            Write-Warning "Artifact Moniker for Work Item ID $id does not exist" -Verbose
        }
        
    }



}

catch {
    throw $_;   
}


