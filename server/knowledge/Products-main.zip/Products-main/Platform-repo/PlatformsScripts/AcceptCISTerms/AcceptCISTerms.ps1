<#
.SYNOPSIS
Accept terms of use for CIS 1 RHEL image

.DESCRIPTION
RHEL 8 CIS level 1 images require terms of use acceptance prior to deployments.

.PARAMETER SubscriptionID
Mandatory

#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$SubscriptionID
)


$ErrorActionPreference = 'Stop'

try {
    # Accept RHEL CIS Image terms of use for this new subscription
    Set-AzContext -Subscription $SubscriptionID
    Get-AzMarketplaceTerms -Publisher center-for-internet-security-inc -Product cis-rhel-8-l1 -Name cis-rhel8-l1 -OfferType 'virtualmachine' | Set-AzMarketplaceTerms -Accept
    #Get-AzMarketplaceTerms -Publisher center-for-internet-security-inc -Product cis-rhel-8-l1 -Name cis-rhel8-l1 | Set-AzMarketplaceTerms -Accept
}
catch {
    throw  $_
}


