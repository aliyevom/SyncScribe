Param(
    [string]$ScopeType,
    [string]$ManagementGroup,
    [string]$Subscriptions,
    [string]$NSGName,
    [string]$RuleName,
    [string]$Description,
    [string]$AccessType,
    [string]$Protocol,
    [string]$Direction,
    [string]$SourceAddressPrefix,
    [string]$SourcePortRange,
    [string]$DestinationAddressPrefix,
    [string]$DestinationPortRange,
    [string]$updateexistingrule
)

function Add-NsgRule {
    param (
        [string]$RuleName,
        [string]$NSGName,
        [string]$resourceGroupName,
        [string]$Description,
        [string]$AccessType,
        [string]$Protocol,
        [string]$Direction,
        [string]$SourceAddressPrefix,
        [string]$SourcePortRange,
        [string]$DestinationAddressPrefix,
        [string]$DestinationPortRange,
        [string]$updateexistingrule
    )

<#
Pending Fixes:
1. Multiple IPs format needs to be fixed. not working with comma seprated source/destinition
2. Update existing rule is not working yet, needs to be fixed. updateexistingrule condition is not working

#>

#Format SourceIPAddressPrefixes & DestinitionIPAddressPrefixes if multiple values are supplied

    # Regular expression to check for comma-separated values
    if ($SourceAddressPrefix -match '^[^,]+(,[^,]+)*$') {
        Write-Output "The string contains comma-separated values."

        # Split the string into an array
        #$SAipArray = $SourceAddressPrefix -split ','
        # Format the array into the desired output
        #$SourceAddressPrefixformatted = '@("' + ($SAipArray -join '","') + '")'
        $SourceAddressPrefixformatted = New-Object System.Collections.Generic.List[System.Object]
        $SourceAddressPrefix -split ',' | ForEach-Object {
        $SourceAddressPrefixformatted.Add("$_")
        }
         $SourceAddressPrefixformatted.ToArray()


        # Output the formatted IP addresses
        Write-Output $SourceAddressPrefixformatted

    }
else 
{
    $SourceAddressPrefixformatted = $DestinationAddressPrefix
}

    if ($DestinationAddressPrefix -match '^[^,]+(,[^,]+)*$') {
        Write-Output "The string contains comma-separated values. $DestinationAddressPrefix"

        # Split the string into an array
        #$DAipArray = $DestinationAddressPrefix -split ','
        # Format the array into the desired output
        #$DestinationAddressPrefixformatted = '@("' + ($DAipArray -join '","') + '")'
        $DestinationAddressPrefixformatted = New-Object System.Collections.Generic.List[System.Object]
        $DestinationAddressPrefix -split ',' | ForEach-Object {
        $DestinationAddressPrefixformatted.Add("$_")
        }
         $DestinationAddressPrefixformatted.ToArray()


        # Output the formatted IP addresses
        Write-Output $DestinationAddressPrefixformatted

    }
    else 
    {
        $DestinationAddressPrefixformatted = $DestinationAddressPrefix
    }


    # Get the NSG
    $nsg = Get-AzNetworkSecurityGroup -ResourceGroupName $resourceGroupName -Name $nsgName

    # Get existing rules and their priorities
    $existingRules = $nsg.SecurityRules
    Write-Output "Existing rules"
    $existingZPARule = $existingRules.Name | Where-Object { $_ -eq $RuleName }
    $existingZPARule
    # Create a list of used priorities
    $usedPriorities = @()
    foreach ($rule in $existingRules) {
        $usedPriorities += $rule.Priority
        if($rule.Name -eq $existingZPARule)
        {
        $existingrulepriority = $rule.Priority

        }
    }

    # Define the range of possible priorities (113-65000)
    $allPriorities = 112..65000

    # Find available priorities after 112
    $availablePriorities = $allPriorities | Where-Object { $_ -notin $usedPriorities }

    # Get the first available priority
    $firstAvailablePriority = $availablePriorities | Select-Object -First 1

    # Output the first available priority
    if ($firstAvailablePriority) {
        Write-Output "The first available priority after 112 is: $firstAvailablePriority"
    }
    else {
        Write-Output "No available priorities found after 112."
    }

    #skip the rule if it exists
    if ($existingZPARule -ne $RuleName) {       
        Write-Output "Rule not found , proceeding with the rule creation" -Verbose
        # Add the rule to the NSG
        $nsg | Add-AzNetworkSecurityRuleConfig -Name $RuleName -Description $Description -Access $AccessType -Protocol $Protocol -Direction $Direction -Priority $firstAvailablePriority -SourceAddressPrefix $SourceAddressPrefixformatted -SourcePortRange $SourcePortRange -DestinationAddressPrefix $DestinationAddressPrefixformatted -DestinationPortRange $DestinationPortRange

        # Update the NSG
        $nsg | Set-AzNetworkSecurityGroup
    } 
    elseif($true -eq $updateexistingrule) {
        Write-Output "Rule found with the same name, updating the rule..." -Verbose
        Write-Output "Existing rule priority is $existingrulepriority " -Verbose
        $nsg | Set-AzNetworkSecurityRuleConfig -Name $RuleName -Description $Description -Access $AccessType -Protocol $Protocol -Direction $Direction -Priority $existingrulepriority -SourceAddressPrefix $SourceAddressPrefixformatted -SourcePortRange $SourcePortRange -DestinationAddressPrefix $DestinationAddressPrefixformatted -DestinationPortRange $DestinationPortRange

    }
    else {
        $updateexistingrule
        Write-Output "Rule found with the same name, skipping the rule creation and update" -Verbose
    }

}

$subs = @()
if ($ScopeType -eq "ManagementGroup") {
    #$managementgrp='Global-UK-NonProd'
    Write-output "Management Group Scope"
    $Cmanagementgrp = $managementgrp
    $MGSubscriptions = Get-AzManagementGroup -GroupID $CManagementGrp -Expand -Recurse
    $subscriptionlist = $MGSubscriptions | foreach-object -MemberName Children
    $subs = $subscriptionlist.displayName
    $subs
}

elseif ($ScopeType -eq "Subscriptions") {
    $Subscriptions = $Subscriptions -replace '\s', ''  #removing empty spaces (if any)
    $subsArray = $Subscriptions -split ","
    foreach ($subsArrayElement in $subsArray) {
        $subs += $subsArrayElement
        $subs
    }
}

elseif ($ScopeType -eq "NSG")
{

    Write-output "NSG Scope"
    Set-AzContext -Subscription $Subscriptions
    if ($SourceAddressPrefix -ceq "SubnetIPs") {

        Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $AddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $DestinationAddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule

    }
    elseif ($DestinationAddressPrefix -ceq "SubnetIPs") {
        Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $SourceAddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $AddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule

    }
    else {
        Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $SourceAddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $SourceAddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule

    }
    break;
}

else {
    Write-Output " Inavlid Scope" -Verbose
    break;
}

ForEach ($sub in $subs) {
    Write-Output "Setting up the context to the Subscription $($Sub)"
    Set-AzContext -Subscription $sub | Out-Null
    
    # Get all Virtual Networks in the subscription
    $vnets = Get-AzVirtualNetwork
    # Loop through each VNET and get subnet details
    foreach ($vnet in $vnets) {
        foreach ($subnet in $vnet.Subnets) {
            # Create a custom object to store subnet information
            $VNetName = $vnet.Name
            $SubnetName = $subnet.Name
            $AddressPrefix = $subnet.AddressPrefix
            $NSGName = if ($subnet.NetworkSecurityGroup) { $subnet.NetworkSecurityGroup.Id.Split('/')[-1] } else { "None" }
            $ResourceGroupName = $vnet.ResourceGroupName
            $VNetName
            $SubnetName
            $AddressPrefix
            $NSGName
            $ResourceGroupName
            Write-Output "Checking if the NSG is attached to the Subnet $SubnetName"
            if ($NSGName -ne "None") {
            
                if ($SourceAddressPrefix -ceq "SubnetIPs") {
                    Write-Output "SourceAddressPrefix will be selected from SubnetIPs - $AddressPrefix "

                    Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $AddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $DestinationAddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule
        
                }
                elseif ($DestinationAddressPrefix -ceq "SubnetIPs") {
                    Write-Output "DestinationAddressPrefix will be selected from SubnetIPs - $AddressPrefix "
                    Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $SourceAddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $AddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule
            
                }
                else {
                    Write-Output "Using all Provided resource level Parameters "
                    Add-NsgRule -RuleName $RuleName -NSGName $NSGName -resourceGroupName $ResourceGroupName -Description $Description -AccessType $AccessType -Protocol $Protocol -Direction $Direction -SourceAddressPrefix $SourceAddressPrefix -SourcePortRange $SourcePortRange -DestinationAddressPrefix $SourceAddressPrefix -DestinationPortRange $DestinationPortRange -updateexistingrule $updateexistingrule
            
                }
            }

        }
    }

}


