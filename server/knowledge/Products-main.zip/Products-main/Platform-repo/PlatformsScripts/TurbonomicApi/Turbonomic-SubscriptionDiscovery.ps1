<#
.SYNOPSIS
    Add Newly provisioned subcription into Turbonomic Data Collector

.DESCRIPTION
    Update torbonomic runs periodically and adds newly provisioned Azure subscriptions. subscriptions retrieved from registrations
    table. Azure tables is a place holder for newly added subscriptions. Turbonomice discovers run on a schedule every 10 minutes. 

    Azure tables is used to maintian the subscriptions state wether newly provisioned or devomissioned.
    Azure registration table sets "OptimizationStatus" field to 

    Add       when get Subscription provisioned
    Remove    when subscription gets decomissioned
    Complete  Subscription sucessfuly added to Turbonomic group.

.PARAMETER ccoeGroup
    Specifies the name of the turbonomic group 

.PARAMETER ngturboInstance
    Specifies the name of the turbonomic endpoint

.PARAMETER userName
    Specifies the name of the turbono9mic user that maintains subscription managements
  
.PARAMETER SubscriptionId
   Subscription ID where keyvault exists

.PARAMETER KeyVaultName
   Key Vault Name to get api secret

.PARAMETER apiSecret
    Specifies the name of the api secret place holder

.PARAMETER storageAccountName
    Specifies the name of the Azure storage account that hosts the registration table
 
.PARAMETER storageAccountNameResourceGroup
    Specifies the name of the Azure resource gorup

.PARAMETER tableName
    Specifies the name of Azue table for subscription registration status

.EXAMPLE

.NOTES

#>


param(
    [string]$ccoeGroup,
    [string]$ngturboInstance,
    [string]$userName,
    [string]$subscriptionId,
    [string]$keyVaultName,
    [string]$apiSecret,
    [string]$storageAccountName,
    [string]$storageAccountNameResourceGroup,
    [string]$tableName

)
#
#   Login to Turbonomic and get a session Token'
#
# API Call to Login to Turbonomic | Check Out | Anything outside of a "Status Code: 200' is a login failure.... check instance
# 
Install-Module AzTable -Force -Scope CurrentUser
$loginURI = "https://" + $ngturboInstance + "/api/v3/login"
$apiBaseUri = "https://" + $ngturboInstance + "/api/v3"
#
#   Login and get Websession Key
#      
# Get Password from Keyvault Secrets

try {    
    Set-AzContext -Subscription $subscriptionId   

    #
    #  Get Newly provisioned subscriptions from registration table
    #
    $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountNameResourceGroup
    $ctx = $sta.Context
    $cloudTable = (Get-AzStorageTable -Name $tableName -Context $ctx).CloudTable

    [string]$add = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("OptimizationStatus", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, "Add")
    [string]$remove = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("OptimizationStatus", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, "Remove")

    $addedSubscriptions = Get-AzTableRow -table $cloudTable -CustomFilter $add 
    $removedSubscriptions = Get-AzTableRow -table $cloudTable -CustomFilter $remove 

    if ((-not $addedSubscriptions) -and (-not $removedSubscriptions)) {
        write-verbose "`n`nThere are no updates to perform`n`n" -Verbose
        Return
    }
    #
    #  Login to Tubonomic API 
    #
    $passwordObject = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $apiSecret
    $PasswordHash = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($passwordObject.SecretValue)

    [string]$Password = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PasswordHash)

    $securePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force

    $Auth_Rest = New-Object PSCredential $userName, $securePassword
    $Auth_Rest_Header = @{
        username = $Auth_Rest.userName
        password = $Auth_Rest.GetNetworkCredential().Password
    } 


    $InitAuth = Invoke-WebRequest -Method "POST" -Body $Auth_Rest_Header -SessionVariable session -Uri $loginURI

}
catch {
    throw "Password extraction exception `n$_"
}
#
#   Get Gorup Account/Subscriptions members and list on onboarded subscriptions
#
try {

    $Group_Chk_DTO = @{
        criteriaList    = @(
            @{
                expType       = "RXEQ"
                expVal        = $ccoeGroup
                filterType    = "groupsByName"
                caseSensitive = $false
            }
        )
        logicalOperator = "AND"
        className       = "Group"
        scope           = $null
    } | ConvertTo-Json

    $response = Invoke-RestMethod -WebSession $session  $apiBaseUri'/search/?ascending=true&disable_hateoas=true&limit=20&order_by=name&q=' -Method 'POST' -Body $Group_Chk_DTO -ContentType application/json  
    $groupUUID = $response.uuid
    $expVal = ($response.criteriaList | Where-Object { $_.filterType -eq 'vmsByBusinessAccountUuid' }).expVal
    Write-Verbose "Monitored Gorup UUID`n$groupUUID" -Verbose
    Write-Verbose "Monitored accounts`n$expVal" -Verbose
    #
    #   get discovered Azure accounts uuid and match from Azure tables recently onboarded VMs
    #
    $accountsParam = @{
        Method      = 'get'
        WebSession  = $session
        Uri         = $($apiBaseUri + "/businessunits?type=DISCOVERED&cloud_type=AZURE")
        ContentType = "application/json"

    }
    $accounts = Invoke-RestMethod  @accountsParam

    @($accounts.displayName)
    #
    #  Remove decomissioned subscriptions from ccoe group.
    #  
    $uuids = [System.Collections.ArrayList]($expVal.split('|'))
    $temp = [STRING]::Empty
    write-verbose "Start updating -" -Verbose
    foreach ($toBeRemoved in $removedSubscriptions) {

        if (($temp = $($accounts | where-object { $_.displayName -eq $toBeRemoved.SubscriptionName }).uuid)) {

            $uuids.remove($temp)
            

        }  
        $toBeRemoved.OptimizationStatus = "Complete"
    }
    #
    #  Add Newely Provisioned subscriptions to CCoE Discovery group.
    # 
    foreach ($toBeAdded in $addedSubscriptions) {
        if (($temp = $($accounts | where-object { $_.displayName -eq $toBeAdded.SubscriptionName }).uuid )) {

            $uuids.add($temp)
            $toBeAdded.OptimizationStatus = "Complete"
        
        }
    }
    $expVal = [STRING]::Empty
    foreach ($uuid in $uuids) {

        $expVal = [string]::Concat($expVal, '|', $uuid)

    }
    $expVal = $expVal.SubString(1, $expVal.length - 1)
    Write-Verbose "Updated Monitored accounts list`n$expVal" -Verbose
    #
    # Add new accounts to Group
    #
    $body = @{
        isStatic       = $false
        displayName    = $ccoeGroup 
        memberUuidList = @()
        criteriaList   = @(
            @{
                expType       = 'EQ'
                expVal        = 'AZURE'
                filterType    = 'vmsByCloudProvider'
                caseSensitive = $false
            },
            @{
                expType       = 'EQ'
                expVal        = $expVal 
                filterType    = 'vmsByBusinessAccountUuid'
                caseSensitive = $false
            }
        )
        groupType      = 'VirtualMachine'
    } | ConvertTo-Json

    $addUri = $apiBaseUri + "/groups/" + $groupUUID
    $appendParams = @{
        Method      = 'PUT'
        WebSession  = $session
        Uri         = $addUri
        Body        = $body 
        ContentType = "application/json"
    }

    Invoke-RestMethod @appendParams
    Write-Verbose "`nTurbonomic group $ccoeGroup UUID: $groupUUID  updated sucessfully" -Verbose
    #
    #  update Registration Table
    #
    if ($removedSubscriptions) {
        Write-Verbose "Updating decomissioned subscriptions registragtion Table" -verbose
        $removedSubscriptions
        $removedSubscriptions | ForEach-Object { Update-AzTableRow -table $cloudTable -entity $_ | Out-Null }
    
    }
    if ($addedSubscriptions) {
        Write-Verbose "Updating added subscriptions registragtion Table" -verbose
        $addedSubscriptions
        $addedSubscriptions | ForEach-Object { Update-AzTableRow -table $cloudTable -entity $_ | Out-Null }
    
    }
}
catch {
    throw $_
} 
