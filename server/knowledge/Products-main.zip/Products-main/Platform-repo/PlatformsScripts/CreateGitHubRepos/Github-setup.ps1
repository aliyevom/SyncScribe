[CmdletBinding(SupportsShouldProcess)]
Param(
    [string]$subscriptionName,    
    [string]$OrgName,
    [string]$RepoName,
    [string]$ProductOrg,
    [string]$ProductRepoName,
    [string]$TeamName,
    [string]$UserName,
    [string]$requesterEmailAddress
    )
    $ErrorActionPreference = 'Stop'
    #Install-Module -Name Az.KeyVault -RequiredVersion 5.2.2
#>
function fork-Githubrepos {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrgName,
        [Parameter(Mandatory = $true)] [string] $RepoName,
        [Parameter(Mandatory = $true)] [string]$ProductOrg,
        [Parameter(Mandatory = $true)] [string]$ProductRepoName
    )
    $ErrorActionPreference = "Stop";
    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Basic $GITPat")

    try {
$body = @"
        {
        `"organization`": `"$OrgName`",    
        `"name`": `"$RepoName`",
        `"default_branch_only`": true
        }
"@

Write-Debug $body
$URI ="https://api.github.com/repos/"+ $ProductOrg +"/" +$ProductRepoName +"/forks"

$params = @{
    Method          = 'POST'
    Body            = $body
    UseBasicParsing = $true
    Headers         = $headers
    Uri             = $URI
    ContentType     = 'application/json'
};
$response = Invoke-RestMethod @params

$response
    }
    catch{
        #throw $_
    }
    return $response.value
}

$KeyVaultName = 'ng-prd-eus2-kv-01'
$PATSecretName = 'GBL-SVC-GITServiceAccount-PAT'

Set-AzContext -Subscription "US-HUB-Prod-01"
    $PAT = `
        Get-AzKeyVaultSecret `
        -VaultName $KeyVaultName `
        -Name $PATSecretName `
        -ErrorAction Stop;
    Write-Output "getting PAT  from KV " -Verbose
    $PATValue = $PAT.SecretValue
    Write-Output "$PATValue " -Verbose
    if($PATValue)
    {
    $PATSecret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PAT.SecretValue)
    $PATSecretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($PATSecret)
    #$PATSecretText
    }
    else {
        {Write-Output "PAT is not found. please check the PAT Secret Value"}
    }

    function Get-Team {
        PARAM(
            [Parameter(Mandatory = $true)] [string]$OrgName,
            [Parameter(Mandatory = $true)] [string]$TeamName
        )
        $ErrorActionPreference = "Stop";
        $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $headers.Add("Content-Type", "application/json")
        $headers.Add("Authorization", "Basic $GITPat")
        try {
        
        #Write-Debug $body
        #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
        #   https://api.github.com/orgs/nationalgrid-cloud-team/teams/US-5125-Team
        $URI ="https://api.github.com/orgs/"+ $OrgName +"/teams/"+ $TeamName
        
        $params = @{
            Method          = 'GET'
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params
        
        $response
            }
            catch{
                #throw $_
            }
            return $response.value
        }

function Add-Teams {
PARAM(
    [Parameter(Mandatory = $true)] [string] $OrgName,
    [Parameter(Mandatory = $true)] [string] $RepoName,
    [Parameter(Mandatory = $true)] [string] $TeamName,
    [Parameter(Mandatory = $true)] [string] $Permission
)
$ErrorActionPreference = "Continue";
$GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Content-Type", "application/json")
$headers.Add("Authorization", "Basic $GITPat")
$Repo = $OrgName +"/"+$RepoName
try {
$body = @"
{
    `"name`": `"$TeamName`",    
    `"description`": `"$TeamName`",
    `"repo_names`": [`"$Repo`"],
    `"permission`": `"$Permission`",
    `"notification_setting`": `"notifications_enabled`",
    `"privacy`":`"closed`" 
}
"@

Write-Debug $body
$URI ="https://api.github.com/orgs/"+ $OrgName +"/teams"

$params = @{
    Method          = 'POST'
    Body            = $body
    UseBasicParsing = $true
    Headers         = $headers
    Uri             = $URI
    ContentType     = 'application/json'
};
$response = Invoke-RestMethod @params

$response
    }
    catch{
        #throw $_
    }
    return $response.value
}

function Add-TeamPermission {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrgName,
        [Parameter(Mandatory = $true)] [string] $RepoName,
        [Parameter(Mandatory = $true)] [string] $TeamName,
        [Parameter(Mandatory = $true)] [string] $Permission
    )
    $ErrorActionPreference = "Continue";
    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Basic $GITPat")
    $Repo = $OrgName +"/"+$RepoName
    try {
    $body = @"
    {
        `"permission`": `"$Permission`"
 
    }
"@
    
    Write-Debug $body
    $URI ="https://api.github.com/orgs/"+ $OrgName +"/teams/"+ $TeamName+"/repos/"+ $Repo
    
    $params = @{
        Method          = 'PUT'
        Body            = $body
        UseBasicParsing = $true
        Headers         = $headers
        Uri             = $URI
        ContentType     = 'application/json'
    };
    $response = Invoke-RestMethod @params
    
    $response
        }
        catch{
            #throw $_
        }
        return $response.value
    }

function Add-Teammember {
    PARAM(
        [Parameter(Mandatory = $true)] [string] $OrgName,
        [Parameter(Mandatory = $true)] [string]$TeamName,
        [Parameter(Mandatory = $true)] [string]$UserName
    )
    $ErrorActionPreference = "Stop";
    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Basic $GITPat")
    try {
    $body = @"
    {
        `"role`": `"maintainer`"
    }
"@
    
    Write-Debug $body
    #https://api.github.com/orgs/ORG/teams/TEAM_SLUG/memberships/USERNAME
    $URI ="https://api.github.com/orgs/"+ $OrgName +"/teams/" + $TeamName + "/memberships/"+$UserName
    
    $params = @{
        Method          = 'PUT'
        Body            = $body
        UseBasicParsing = $true
        Headers         = $headers
        Uri             = $URI
        ContentType     = 'application/json'
    };
    $response = Invoke-RestMethod @params
    
    $response
        }
        catch{
            #throw $_
        }
        return $response.value
    }



function Add-Environment {
        PARAM(
            [Parameter(Mandatory = $true)] [string] $OrgName,
            [Parameter(Mandatory = $true)] [string]$RepoName,
            [Parameter(Mandatory = $true)] [string]$Environment
        )
        $ErrorActionPreference = "Stop";
        $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $headers.Add("Content-Type", "application/json")
        $headers.Add("Authorization", "Basic $GITPat")
        try {
 $body = @"
 {
     `"deployment_branch_policy`":{`"protected_branches`":false,`"custom_branch_policies`":true},
     `"can_admins_bypass`": true
     }
"@
        
        Write-Debug $body
        #'https://api.github.com/repos/nationalgrid-engineering/Hello-World/environments/Prod'
        $URI ="https://api.github.com/repos/"+ $OrgName +"/" + $RepoName + "/environments/"+ $Environment
        
        $params = @{
            Method          = 'PUT'
            Body            = $body
            UseBasicParsing = $true
            Headers         = $headers
            Uri             = $URI
            ContentType     = 'application/json'
        };
        $response = Invoke-RestMethod @params
        
        $response
            }
            catch{
                throw $_
            }
            return $response.value
        }
function Get-Environment {
            PARAM(
                [Parameter(Mandatory = $true)] [string]$OrgName,
                [Parameter(Mandatory = $true)] [string]$RepoName,
                [Parameter(Mandatory = $true)] [string]$Environment
            )
            $ErrorActionPreference = "Stop";
            $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/json")
            $headers.Add("Authorization", "Basic $GITPat")
            try {
            
            #Write-Debug $body
            #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
            #  https://api.github.com/repos/nationalgrid-cloud-team/US-5125/environments/dev
            $URI ="https://api.github.com/repos/"+ $OrgName +"/"+ $RepoName + "/environments/" + $Environment
            
            $params = @{
                Method          = 'GET'
                UseBasicParsing = $true
                Headers         = $headers
                Uri             = $URI
                ContentType     = 'application/json'
            };
            $response = Invoke-RestMethod @params
            
            $response
                }
                catch{
                    #throw $_
                }
                return $response.value
            }

    function Get-EnvSecret {
                PARAM(
                    [Parameter(Mandatory = $true)] [string]$OrgName,
                    [Parameter(Mandatory = $true)] [string]$RepoName,
                    [Parameter(Mandatory = $true)] [string]$Environment,
                    [Parameter(Mandatory = $true)] [string]$SecretName
                )
                $ErrorActionPreference = "Stop";
                $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $headers.Add("Content-Type", "application/json")
                $headers.Add("Authorization", "Basic $GITPat")
                try {
                
                #Write-Debug $body
                #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
                #  https://api.github.com/repos/nationalgrid-cloud-team/US-5125/environments/dev/secrets/AZURE_CLIENT_ID
                $URI ="https://api.github.com/repos/"+ $OrgName +"/"+ $RepoName + "/environments/" + $Environment +"/secrets/"+ $SecretName
                
                $params = @{
                    Method          = 'GET'
                    UseBasicParsing = $true
                    Headers         = $headers
                    Uri             = $URI
                    ContentType     = 'application/json'
                };
                $response = Invoke-RestMethod @params
                
                $response
                    }
                    catch{
                        #throw $_
                    }
                    return $response.value
                }
function Get-EnvPublicKey {
            PARAM(
                [Parameter(Mandatory = $true)] [string]$OrgName,
                [Parameter(Mandatory = $true)] [string]$RepoName,
                [Parameter(Mandatory = $true)] [string]$Environment
            )
            $ErrorActionPreference = "Stop";
            $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/json")
            $headers.Add("Authorization", "Basic $GITPat")
            try {
            
            #Write-Debug $body
            #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
            #https://api.github.com/repositories/REPOSITORY_ID/environments/ENVIRONMENT_NAME/secrets/public-key
            $URI ="https://api.github.com/repos/"+ $OrgName +"/"+ $RepoName +"/environments/" + $Environment + "/secrets/public-key"
            
            $params = @{
                Method          = 'GET'
                UseBasicParsing = $true
                Headers         = $headers
                Uri             = $URI
                ContentType     = 'application/json'
            };
            $response = Invoke-RestMethod @params
            
            $response
                }
                catch{
                    throw $_
                }
                return $response.value
            }

function Get-Repository {
                PARAM(
                    [Parameter(Mandatory = $true)] [string] $OrgName,
                    [Parameter(Mandatory = $true)] [string]$RepoName
                )
                $ErrorActionPreference = "Stop";
                $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $headers.Add("Content-Type", "application/json")
                $headers.Add("Authorization", "Basic $GITPat")
                try {
                
                #Write-Debug $body
                #https://api.github.com/repos/nationalgrid-engineering/Hello-World/actions/secrets/public-key'
                $URI ="https://api.github.com/repos/"+ $OrgName +"/" + $RepoName
                
                $params = @{
                    Method          = 'GET'
                    UseBasicParsing = $true
                    Headers         = $headers
                    Uri             = $URI
                    ContentType     = 'application/json'
                };
                $response = Invoke-RestMethod @params
                
                $response
                    }
                    catch{

                        #throw $_
                    
                    }
                    return $response.value
                }

function Add-EnvSecret {
                    PARAM(
                        [Parameter(Mandatory = $true)] [string] $RepoID,
                        [Parameter(Mandatory = $true)] [string]$Environment,
                        [Parameter(Mandatory = $true)] [string]$SecretName,
                        [Parameter(Mandatory = $true)] [string]$EncryptedSecret,
                        [Parameter(Mandatory = $true)] [string]$KeyID
                    )
                    $ErrorActionPreference = "Stop";
                    $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                    $headers.Add("Content-Type", "application/json")
                    $headers.Add("Authorization", "Basic $GITPat")
                    try {
             $body = @"
             {
                 `"encrypted_value`": `"$EncryptedSecret`",
                 `"key_id`":  `"$KeyID`"
                 }
"@
                    
                    Write-Debug $body
                    #'https://api.github.com/repositories/REPOSITORY_ID/environments/ENVIRONMENT_NAME/secrets/SECRET_NAME
                    $URI ="https://api.github.com/repositories/"+ $RepoID +"/environments/" + $Environment + "/secrets/"+ $SecretName
                    
                    $params = @{
                        Method          = 'PUT'
                        Body            = $body
                        UseBasicParsing = $true
                        Headers         = $headers
                        Uri             = $URI
                        ContentType     = 'application/json'
                    };
                    $response = Invoke-RestMethod @params
                    
                    $response
                        }
                        catch{
                            throw $_
                        }
                        return $response.value
                    }
function Get-OrgMember {
                        PARAM(
                            [Parameter(Mandatory = $true)] [string] $OrgName,
                            [Parameter(Mandatory = $true)] [string]$UserName
                        )
                        $ErrorActionPreference = "Stop";
                        $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                        $headers.Add("Content-Type", "application/json")
                        $headers.Add("Authorization", "Basic $GITPat")
                        try {
                        
                        #Write-Debug $body
                        #https://api.github.com/orgs/nationalgrid-cloud-team/members
                        $URI ="https://api.github.com/orgs/"+ $OrgName +"/members/" + $UserName
                        
                        $params = @{
                            Method          = 'GET'
                            UseBasicParsing = $true
                            Headers         = $headers
                            Uri             = $URI
                            ContentType     = 'application/json'
                        };
                        $response = Invoke-RestMethod @params
                        
                        $response
                            }
                            catch{
        
                                #throw $_
                            
                            }
                            return $response.value
                        }


    function Get-Org {
                            PARAM(
                                [Parameter(Mandatory = $true)] [string] $OrgName
                            )
                            $ErrorActionPreference = "Stop";
                            $GITPat = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($PATSecretText)"))
                            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                            $headers.Add("Content-Type", "application/json")
                            $headers.Add("Authorization", "Basic $GITPat")
                            try {
                            
                            #Write-Debug $body
                            # https://api.github.com/orgs/ORG
                            $URI ="https://api.github.com/orgs/"+ $OrgName
                            
                            $params = @{
                                Method          = 'GET'
                                UseBasicParsing = $true
                                Headers         = $headers
                                Uri             = $URI
                                ContentType     = 'application/json'
                            };
                            $response = Invoke-RestMethod @params
                            
                            $response
                                }
                                catch{
            
                                    #throw $_
                                
                                }
                                return $response.value
                            }
#$CheckRepo =Get-Repository -OrgName $OrgName -RepoName $RepoName
#$CheckRepo

<#fix for - https://microsoft.github.io/PSRule/v2/troubleshooting/#windows-powershell-is-in-noninteractive-mode
if ($Null -eq (Get-PackageProvider -Name NuGet -ErrorAction Ignore)) {
    Install-PackageProvider -Name NuGet -Force -Scope CurrentUser;
}

if ($Null -eq (Get-InstalledModule -Name PowerShellGet -MinimumVersion 2.2.1 -ErrorAction Ignore)) {
    Install-Module PowerShellGet -MinimumVersion 2.2.1 -Scope CurrentUser -Force -AllowClobber;
}

Install-Module -Name PSSodium -RequiredVersion '0.4.2' -Force -ErrorAction Ignore
Import-Module PSSodium
#>
$SuccessfullOperations = New-Object System.Collections.Generic.List[System.Object]
$FailedOperations = New-Object System.Collections.Generic.List[System.Object]
try {
    Write-Output "Initiating GitHub Onboarding... " -Verbose
    if (Get-Org -OrgName $OrgName) {
        Write-Output "Valid Org- $OrgName " -Verbose
        $SuccessfullOperations.Add("Success: $OrgName - GitHub Organizaton Validated")

        if (Get-Repository -OrgName $OrgName -RepoName $RepoName) {
            Write-Output "Repo already exists... " -Verbose
            $FailedOperations.Add("Info: GitHub Repository already Exists")
            Write-Output "Intiating Teams Creation... " -Verbose
            $CheckTeam = Get-Team -OrgName $OrgName -TeamName $TeamName
            if(!($CheckTeam))
            {
            $AddTeams = Add-Teams -OrgName $OrgName -TeamName $TeamName -RepoName $RepoName -Permission 'push'
            $AddTeams
            if ($AddTeams) 
            {
                Write-Output "Team $TeamName has been associated to the Repository $RepoName " -Verbose
                $SuccessfullOperations.Add("Success: $TeamName - GitHub Team Created")
                $AddTeams
                $FailedOperations.Add("Warning: $USerName - User Access is not Granted")
            }
          }
          else {
            Write-Output "Team $TeamName already exists. please validate & assciate it with Repo " -Verbose
            $CheckTeam
            $FailedOperations.Add("Info: $TeamName - Team already exists")
          }

        }
        else {

            Write-Output "Intiating Product Repo fork and repo creation " -Verbose
            #$ProductRepoName ='Products'
            #$ProductOrg ="nationalgrid-cloud-team"
            $forkedRepos = fork-Githubrepos -OrgName $OrgName -RepoName $RepoName -ProductOrg $ProductOrg -ProductRepoName $ProductRepoName
            $forkedRepos
            if ($forkedRepos) {
                Write-Output "Product Repo has been forked as $RepoName .... $forkedRepos " -Verbose
                $SuccessfullOperations.Add("Success: $RepoName - GitHub Repository Created")
            }
            else {
                Write-Output "Product Repo fork retuned error " -Verbose
                $FailedOperations.Add("ERROR: fork Product repo returned an unknown error")
            }
            #ADT Team creation
            $CheckTeam = Get-Team -OrgName $OrgName -TeamName $TeamName
            if(!($CheckTeam))
            {
            Write-Output "Intiating Teams Creation... " -Verbose
            $AddTeams = Add-Teams -OrgName $OrgName -TeamName $TeamName -RepoName $RepoName -Permission 'push'
            $AddTeams
            if ($AddTeams) {
                Write-Output "Team $TeamName has been associated to the Repository $RepoName " -Verbose
                $SuccessfullOperations.Add("Success: $TeamName - GitHub Team Created")
                $AddTeams
                $CheckOrgMembership = Get-OrgMember -OrgName $OrgName -UserName $UserName
                if ($CheckOrgMembership) {
                    Write-Output "Adding $USerName to the Team $TeamName " -Verbose
                    $AddTeamMember = Add-Teammember -OrgName $OrgName -TeamName $TeamName -UserName $UserName
                    $AddTeamMember
                    $SuccessfullOperations.Add("Success: $USerName - User Added to the Team")
                }
                else {
                    Write-Output " $USerName is not part of the Org $OrgName" -Verbose
                    $FailedOperations.Add("Warning: $USerName - User is not a member in the Org $OrgName")
                }

            }
            else {
                Write-Output "Adding Team retuned error " -Verbose
                $FailedOperations.Add("ERROR: Create Team returned an unknown error")
            }
        }
        else {
            Write-Output " Team $TeamName already exists. please validate & assciate it with Repo" -Verbose
            $FailedOperations.Add("Info: $TeamName - Team already exists")
        }

        }

                    #CPET Team Creation and Update
                    $CPETTeamName = "CPET-Team"
                    $CheckCPETTeam = Get-Team -OrgName $OrgName -TeamName $CPETTeamName
                    if(!($CheckCPETTeam))
                    {
                    Write-Output "CPET Team does not exist, contact GitHub Team " -Verbose
                    $FailedOperations.Add("Warning: $CPETTeamName - Team does not exists in the Org $OrgName")

                }
                else {
                    Write-Output " Team $CPETTeamName already exists. associating with the repo" -Verbose
                    $AddCPETTeams = Add-TeamPermission -OrgName $OrgName -TeamName $CPETTeamName -RepoName $RepoName -Permission 'admin'
                    $AddCPETTeams
                    if ($AddCPETTeams) {
                        Write-Output "Team $CPETTeamName has been associated to the Repository $RepoName " -Verbose
                        $SuccessfullOperations.Add("Success: $CPETTeamName - GitHub Team associated")
                        $AddCPETTeams
        
                    }
                    else {
                        Write-Output "Adding CPET Team retuned error " -Verbose
                        $FailedOperations.Add("Warning: Add CPET Team to Repo returned an unknown error")
                    }
                    
                }

        Write-Output "Intiating Environment Creation... " -Verbose

        $CheckDevEnv = Get-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'dev'
        Write-Output "Dev environment... " -Verbose
        $CheckDevEnv
        if (!($CheckDevEnv)) {

            $DevEnv = Add-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'dev'
            if ($DevEnv) {
                $SuccessfullOperations.Add("Success: Dev Environment Created Successfully")
            }
            else {
                $FailedOperations.Add("ERROR: Dev Environment creation returned an unknown error")
            }
            Write-Output "Dev Environment details are... " -Verbose
            $DevEnv
        }
        else {
            $FailedOperations.Add("Info: Dev Environment already exists")
            Write-Output "Dev Environment already exists. Details are... " -Verbose
            $CheckDevEnv
        }

        $CheckQAEnv = Get-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'qa'
        if (!($CheckQAEnv)) {
            $QAEnv = Add-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'qa'
            if ($QAEnv) {
                $SuccessfullOperations.Add("Success: QA Environment Created Successfully")
            }
            else {
                $FailedOperations.Add("ERROR: QA Environment creation returned an unknown error")
            }
            Write-Output "QA Environment details are... " -Verbose
            $QAEnv
        }
        else {
            $FailedOperations.Add("Info: QA Environment already exists")
            Write-Output "QA Environment already exists. Details are... " -Verbose
            $CheckQAEnv
        }
        $CheckUATEnv = Get-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'uat'
        if (!($CheckUATEnv)) {
            $UATEnv = Add-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'uat'
            if ($UATEnv) {
                $SuccessfullOperations.Add("Success: UAT Environment Created Successfully")
            }
            else {
                $FailedOperations.Add("ERROR: UAT Environment creation returned an unknown error")
            }
            Write-Output "UAT Environment details are... " -Verbose
            $UATEnv
        }
        else {
            $FailedOperations.Add("Info: UAT Environment already exists")
            Write-Output "UAT Environment already exists. Details are... " -Verbose
            $CheckUATEnv
        }
        $CheckProdEnv = Get-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'prod'
        if (!($CheckProdEnv)) {
            $ProdEnv = Add-Environment -OrgName $OrgName -RepoName $RepoName -Environment 'prod'
            if ($ProdEnv) {
                $SuccessfullOperations.Add("Success: Prod Environment Created Successfully")
            }
            else {
                $FailedOperations.Add("ERROR: Prod Environment creation returned an unknown error")
            }
            Write-Output "Prod Environment details are... " -Verbose
            $ProdEnv
        }
        else {
            $FailedOperations.Add("Info: Prod Environment already exists")
            Write-Output "Prod Environment already exists. Details are... " -Verbose
            $CheckProdEnv
        }
        #fork-Githubrepos -OrgName "nationalgrid-engineering" -RepoName "Hello-World15" -ProductOrg "nationalgrid-engineering" -ProductRepoName "Hello-World"

        #Start-Sleep 10
        $Region = $subscriptionName.Split("-")[0].ToUpper()
        $Region
        $SubsEnvironment = ($subscriptionName.Split("-")[2]).ToUpper()

        If (($SubsEnvironment -eq "FOF") -and ($Region -eq "UK")) {
            $Environment = "UAT"
        }
        elseIf (($SubsEnvironment -eq "FOF") -and ($Region -eq "US")) {
            Write-Output "FOF Environment is not supported in US region... " -Verbose
            $FailedOperations.Add("ERROR: FOF Environment is not supported in US region")
        }
        else {
            $Environment = $subscriptionName.Split("-")[2]
        }

        $Repodetails = Get-Repository -OrgName $OrgName -RepoName $RepoName
        if ($Repodetails) {
            Write-Output "Initiating Environment secret encryption " -Verbose
        }
        else {
            $FailedOperations.Add("ERROR: Retrieve Repo returned an unknown error")
        }
        #$Repodetails
        $RepoID = $Repodetails.id
        $RepoID
        Write-Output "Retrieved repo ID Is $RepoID " -Verbose
        $EnvPublicKey = Get-EnvPublicKey -OrgName $OrgName -RepoName $RepoName -Environment $Environment
        #$EnvPublicKey
        if ($EnvPublicKey) {
            Write-Output "Successfully retrieved Public Key of the Repository $EnvPublicKey " -Verbose
        }
        else {
            $FailedOperations.Add("ERROR: Retrieve Public Key returned an unknown error")
        }

        $PublicKey = $EnvPublicKey.Key
        $PublicKeyID = $EnvPublicKey.key_Id
        
        #Extracting all Secrets from key Vault
        if ($Region -eq "US") {
            $KeyVaultName = 'ng-prd-eus2-kv-01'
            Write-Output "setting context to...$Region " -Verbose
            Set-AzContext -Subscription "US-HUB-Prod-01"
        }

        else {
            $KeyVaultName = 'ng-prd-uks-kv-01'
            Write-Output "setting context to...$Region " -Verbose
            Set-AzContext -Subscription "UK-HUB-Prod-01"
        }
try{

    Write-Output "Getting App ID & Secret for the KV... " -Verbose
    $ErrorActionPreference ='Stop'
        $APPIDName = $subscriptionName + "-SPN-appId"
        $APPIDName
        $appID = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $APPIDName
        $appID
        Write-Output "getting APP ID  from KV $APPIDName " -Verbose
        $APPPSWDName = $subscriptionName + "-SPN-Password"
        $spnPassword = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $APPPSWDName
        }
        catch {
            Write-Output "Getting App ID & Secret for the KV failed... " -Verbose
            Write-Output $Error[0].Exception.Message
            $Error[0] | Format-List -Force
            throw $_
        }
            #-ErrorAction SilentlyContinue;
            #$spnPassword = `
        #If (($null -ne $appID) -and ($null -ne $spnPassword)) {
        If ($null -ne $appID) {
            $ApplicationID = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($appID.SecretValue)
            $ApplicationIDText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ApplicationID)
            $ApplicationIDText
            Write-Output "SPN - $ApplicationIDText and Password exists in key vault " -Verbose
            $ServicePrincipalPasswd = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($spnPassword.SecretValue)
            $ServicePrincipalPasswdText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ServicePrincipalPasswd)
            #$ServicePrincipalPasswdText

            #check if the Federated Identity exists
            $SPNName =$subscriptionName + "-SPN"
            $environmentName = $Environment.ToLower()
            $LOrgName =$OrgName.ToLower()
            $SPNparts = $SPNName -split "-"
            if ($environmentName -eq "fof") {
            $environmentName = "uat"
            }
    $subjectUri = "repo:$($LOrgName)/$($RepoName):environment:$($environmentName)"
    $subjectUri
    $FederatedIdentityName = $SPNName + "-dfi-" + $SPNparts[3] 
    $FederatedIdentityName
    # Get the Object ID of your application
    $appObjectId = (Get-AzADApplication -DisplayName $SPNName).Id
    $exists = $false;
    # Get all federated identity credentials for the application
    $federatedCredentials = Get-AzADAppFederatedCredential -ApplicationObjectId $appObjectId
    # Format the FI name
    $count = $federatedCredentials.Count
    foreach ($cred in $federatedCredentials) {
        $cred
        Write-Host "Name: $($cred.Name)"
        $FIName = $cred.Name
        $FINSubject = $cred.Subject
                
        if ($FINSubject -eq $subjectUri) {
            Write-Output "Federated Identity is already configured for $($subjectUri)"
            $SuccessfullOperations.Add("Success: Federated Identity $($subjectUri) already exists ")
            $exists = $true;
        }
        else {
            $SPNNumber = [int]$count + 1
            $formattedSPNNumber = "{0:D2}" -f $SPNNumber
            $FederatedIdentityName = $SPNName + "-dfi-" + $formattedSPNNumber #Checked Naming Convention with Hanlon
            $FederatedIdentityName
        }
    }
    if (!($exists)) {
        Write-Output "Federated Identity is being configured"
        $AddFDI = New-AzADAppFederatedCredential -ApplicationObjectId $appObjectId -Name $FederatedIdentityName -Audience @('api://AzureADTokenExchange') -Issuer "https://token.actions.githubusercontent.com" -Subject $subjectUri
        if($AddFDI)
        {
        $SuccessfullOperations.Add("Success: Federated Identity $($subjectUri) Created Successfully ")
         }
    }
            
            Write-Output "Initiating Encryption module... " -Verbose
            #$EncryptedSecret =ConvertTo-SodiumEncryptedString -Text $Secret -PublicKey $PublicKey
            #$EncryptedSecret

        }
        else {
            Write-Error "AppID and Secret not found in Key Vault" -Verbose
            $FailedOperations.Add("ERROR: Retrieve Secret returned an unknown error")
        }
        Write-Output "Starting module installation... " -Verbose
        #Install-Module -Name PSSodium -RequiredVersion '0.4.2' -Force -Scope CurrentUser
        function Load-Module ($m) {

            # If module is imported say that and do nothing
            if (Get-Module | Where-Object { $_.Name -eq $m }) {
                write-host "Module $m is already imported."
            }
            else {

                # If module is not imported, but available on disk then import
                if (Get-Module -ListAvailable | Where-Object { $_.Name -eq $m }) {
                    Import-Module $m -Verbose
                }
                else {

                    # If module is not imported, not available on disk, but is in online gallery then install and import
                    if (Find-Module -Name $m | Where-Object { $_.Name -eq $m }) {
                        Install-Module -Name $m -RequiredVersion '0.4.2' -Force -Verbose -Scope CurrentUser -ErrorAction Stop
                        Import-Module $m -Verbose
                    }
                    else {

                        # If the module is not imported, not available and not in the online gallery then abort
                        write-host "Module $m not imported, not available and not in an online gallery, exiting."
                    }
                }
            }
        }
        #Install-Module -Name PSSodium -RequiredVersion '0.4.2' -Force
        #Import-Module PSSodium
        Load-Module 'PSSodium'

        Write-Output " Module Installation completed. proceeding with the encryption... " -Verbose

        Write-Output " Intiaiting Environment Secrets addition... " -Verbose
        #Add AppID

        $CheckAppIDSecret = Get-EnvSecret -OrgName $OrgName -RepoName $RepoName -Environment $Environment -SecretName "AZURE_CLIENT_ID"
        if (!($CheckAppIDSecret)) {
            $AppIDencrypt = ConvertTo-SodiumEncryptedString -Text $ApplicationIDText -PublicKey $PublicKey
            $AppIDencrypt
            Write-Output " AppID encryption string generated " -Verbose
            if ($AppIDencrypt) {
                Write-Output " Client ID Encryption Succeeded " -Verbose
    
            }
            else {
                Write-Output " SPNID Encryption failed " -Verbose
                $FailedOperations.Add("ERROR: Client ID encryption  for $Environment returned an unknown error")
            }
            $AppIDencrypt

            $AddAppIDSecret = Add-EnvSecret -RepoID $RepoID -Environment $Environment -SecretName "AZURE_CLIENT_ID" -EncryptedSecret $AppIDencrypt -KeyID $PublicKeyID

            if ($AddAppIDSecret) {
                Write-Output " Client ID environment variable added successfully " -Verbose
                $SuccessfullOperations.Add("Success: AZURE_CLIENT_ID Secret for $Environment Created Successfully")
            }
            else {
                Write-Output " Addition of Client Id environment variable failed " -Verbose
                $FailedOperations.Add("ERROR: Client ID addition for $Environment returned an unknown error")
            }
            $AddAppIDSecret
        }

        else {
            Write-Output " AZURE_CLIENT_ID Secret already exists for $Environment ...environment variable will not up updated " -Verbose
            $FailedOperations.Add("Warning: AZURE_CLIENT_ID Secret for $Environment already exists")
        }
        $CheckAppSecret = Get-EnvSecret -OrgName $OrgName -RepoName $RepoName -Environment $Environment -SecretName "AZURE_CLIENT_SECRET"
        if (!($CheckAppSecret)) {

            #Add Secret
            $Appsecretencrypt = ConvertTo-SodiumEncryptedString -Text $ServicePrincipalPasswdText -PublicKey $PublicKey
            if ($Appsecretencrypt) {
                Write-Output " Client ID Secret Encryption Succeeded " -Verbose
            }
            else {
                Write-Output " SPNID Secret Encryption failed " -Verbose
                $FailedOperations.Add("ERROR: ClientID Secret encryption returned an unknown error")
            }
            $Appsecretencrypt
            $AddAppsecretencrypt = Add-EnvSecret -RepoID $RepoID -Environment $Environment -SecretName "AZURE_CLIENT_SECRET" -EncryptedSecret $Appsecretencrypt -KeyID $PublicKeyID
            if ($AddAppsecretencrypt) {
                Write-Output " Client ID Secret environment variable added successfully " -Verbose
                $SuccessfullOperations.Add("Success: AZURE_CLIENT_SECRET Secret for $Environment Created Successfully")
            }
            else {
                Write-Output " Addition of Client Id Secret environment variable failed " -Verbose
                $FailedOperations.Add("ERROR: Client Secret addition returned an unknown error")
            }
            $AddAppsecretencrypt

        }
        else {
            Write-Output " AZURE_CLIENT_SECRET Secret already exists...environment variable will not up updated " -Verbose
            $FailedOperations.Add("Info: AZURE_CLIENT_SECRET Secret for $Environment already exists")
        }
        #Add Subscription ID
        $CheckSubsIDSecret = Get-EnvSecret -OrgName $OrgName -RepoName $RepoName -Environment $Environment -SecretName "AZURE_SUBSCRIPTION_ID"
        if (!($CheckSubsIDSecret)) {
            Set-AzContext -Subscription $subscriptionName
            $Subsinfo = Get-AzSubscription -SubscriptionName $subscriptionName
            $subsID = $Subsinfo.SubscriptionId
            $TenantID = $Subsinfo.TenantId

            $SubsIDencrypt = ConvertTo-SodiumEncryptedString -Text $subsID -PublicKey $PublicKey
            if ($SubsIDencrypt) {
                Write-Output " Subscription ID Encryption Succeeded " -Verbose
            }
            else {
                Write-Output "  Subscription ID Encryption failed " -Verbose
                $FailedOperations.Add("ERROR: SubsID encryption for $Environment returned an unknown error")
            }
            $SubsIDencrypt
            $AddsubsIDencrypt = Add-EnvSecret -RepoID $RepoID -Environment $Environment -SecretName "AZURE_SUBSCRIPTION_ID" -EncryptedSecret $SubsIDencrypt -KeyID $PublicKeyID
            if ($AddsubsIDencrypt) {
                Write-Output " Subs ID environment variable added successfully " -Verbose
                $SuccessfullOperations.Add("Success: AZURE_SUBSCRIPTION_ID Secret for $Environment Created Successfully")
                
            }
            else {
                Write-Output " Addition of Subs Id environment variable failed " -Verbose
                $FailedOperations.Add("ERROR: AZURE_SUBSCRIPTION_ID Secret for $Environment addition returned an unknown error")
            }
            $AddsubsIDencrypt
        }
        else {
            Write-Output " AZURE_SUBSCRIPTION_ID Secret already exists...environment variable will not up updated " -Verbose
            $FailedOperations.Add("Info: AZURE_SUBSCRIPTION_ID Secret for $Environment already exists")
        }
        #Add Tenant ID
        $CheckTenantIDSecret = Get-EnvSecret -OrgName $OrgName -RepoName $RepoName -Environment $Environment -SecretName "AZURE_TENANT_ID"
        if (!($CheckTenantIDSecret)) {
            $TenantIDencrypt = ConvertTo-SodiumEncryptedString -Text $TenantID -PublicKey $PublicKey
            if ($TenantIDencrypt) {
                Write-Output " Tenant ID Encryption Succeeded " -Verbose
            }
            else {
                Write-Output " Tenant ID Encryption failed " -Verbose
                $FailedOperations.Add("ERROR: TenantID Secret encryption for $Environment returned an unknown error")
            }
            $TenantIDencrypt
            $AddTenantIDencrypt = Add-EnvSecret -RepoID $RepoID -Environment $Environment -SecretName "AZURE_TENANT_ID" -EncryptedSecret $TenantIDencrypt -KeyID $PublicKeyID
            if ($AddAppIDSecret) {
                Write-Output " Tenant ID environment variable added successfully " -Verbose
                $SuccessfullOperations.Add("Success: AZURE_TENANT_ID Secret for $Environment Created Successfully")
                
            }
            else {
                Write-Output " Addition of Tenant Id environment variable failed " -Verbose
                $FailedOperations.Add("ERROR: Tenant ID addition for $Environment returned an unknown error")
            }
            $AddTenantIDencrypt
        }
        else {
            Write-Output " AZURE_TENANT_ID Secret already exists...environment variable will not up updated " -Verbose
            $FailedOperations.Add("Info: AZURE_TENANT_ID Secret for $Environment already exists")
        }
        Write-Output "GitHub Onboarding completed. Sending email"
        $SuccessfullOperations 
        $SuccessfullOperations1 = $SuccessfullOperations  | ForEach { [PSCustomObject]@{'Logs Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Logs Description' | Out-String
        # split the text into an array of lines
        # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
        $SuccessfullOperations2 = $SuccessfullOperations1 -split "(\r*\n){2,}"
        # remove linefeeds for each section and output the contents
        $htmlSDescription = $SuccessfullOperations2 -replace '\r*\n', ''
        $htmlSDescription

        $FailedOperations
        #$htmlFDescription = $FailedOperations | ForEach{[PSCustomObject]@{'Errors Description'=$_}} | ConvertTo-HTML -Fragment -Property 'Errors Description' |Out-String
        $FailedOperations1 = $FailedOperations | ForEach { [PSCustomObject]@{'Logs Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Logs Description' | Out-String
        # split the text into an array of lines
        # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
        $FailedOperations2 = $FailedOperations1 -split "(\r*\n){2,}"
        # remove linefeeds for each section and output the contents
        $htmlFDescription = $FailedOperations2 -replace '\r*\n', ''
        $htmlFDescription

        if (($FailedOperations.count -eq 0) -and ($SuccessfullOperations.count -gt 0)) {
            #Set operation type to succeeded
            $OperationType = 'Completed'
            $htmlFDescription = ""
            $htmlFDescription = "<table><colgroup><col/></colgroup><tr><th>Errors Description</th></tr><tr><td>No Error Logs</td></tr></table>"
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
            Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
            Write-Output "1. Sending email with OPCode $OperationType..." -Verbose 
        }

        if (($SuccessfullOperations.count -eq 0) -and ($FailedOperations.count -gt 0)) {
            #Set operation type to Failed
            $OperationType = 'Failed'
            $htmlSDescription = ""
            $htmlSDescription = "<table><colgroup><col/></colgroup><tr><th>Logs Description</th></tr><tr><td>No Success Logs</td></tr></table>"
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
            Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
            Write-Output "2. Sending email with OPCode $OperationType..." -Verbose 
   
        }

        if (($SuccessfullOperations.count -gt 0) -and ($FailedOperations.count -gt 0) -and ($FailedOperations.Contains('Error'))) {
            #Set operation type to Succeeded with Errors(SWE)
            $OperationType = 'SWE'
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
            Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
            Write-Output "3. Sending email with OPCode $OperationType..." -Verbose 
    
        }

        if (($SuccessfullOperations.count -gt 0) -and ($FailedOperations.count -gt 0) -and (!($FailedOperations |Where-Object { $_.Contains('Error') }))) {
            #Set operation type to Succeeded when there is no Errors
            $OperationType = 'Completed'
            Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
            Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
            Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
            Write-Output "3. Sending email with OPCode $OperationType..." -Verbose 
    
        }


    }
    else {
        Write-Output "Provided Org Name is invalid or does not have access to run the pipeline... " -Verbose
        $FailedOperations.Add("ERROR: $OrgName Organization parsing returned an unknown error")
        $FailedOperations
        $FailedOperations1 = $FailedOperations | ForEach { [PSCustomObject]@{'Error Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Error Description' | Out-String
        # split the text into an array of lines
        # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
        $FailedOperations2 = $FailedOperations1 -split "(\r*\n){2,}"
        # remove linefeeds for each section and output the contents
        $htmlFDescription = $FailedOperations2 -replace '\r*\n', ''
        $htmlFDescription
        $htmlSDescription = "<table><colgroup><col/></colgroup><tr><th>Logs Description</th></tr><tr><td>No Success Logs</td></tr></table>"
        $OperationType = ''
        $OperationType = 'Failed'
        Write-Output "5. Sending email with OPCode $OperationType..." -Verbose 
        #Send-FailureMail -to $requesterEmailAddress -from 'AzureNoReply@nationalgrid.com' -emailSubject "GitHUb Onboarding Failed" -GitHubTeam $TeamName -smtpServer "smtpapp.nationalgrid.com" -portnumber 25 -GitHubRepos $RepoName -GitHubOrgName $OrgName -SubscriptionName $subscriptionName -SDescription $htmlFDescription -FDescription $htmlFDescription
        #Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'htmlFDescription;issecret=false;isOutput=true', "$htmlFDescription")
        #Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'htmlSDescription;issecret=false;isOutput=true', "$htmlSDescription")
        #Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'FailedLogs', $htmlFDescription)
        #Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'FailedLogs;issecret=false;isOutput=true', $htmlFDescription)
        Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
        Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
        Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
    
    }
}
catch {

    $FailedOperations.Add("ERROR: Pipeline failed with an unknown error")
    $FailedOperations
    $FailedOperations1 = $FailedOperations | ForEach { [PSCustomObject]@{'Log Description' = $_ } } | ConvertTo-HTML -Fragment -Property 'Error Description' | Out-String
    # split the text into an array of lines
    # the regex "(\r*\n){2,}" means 'split the whole text into an array where there are two or more linefeeds
    $FailedOperations2 = $FailedOperations1 -split "(\r*\n){2,}"
    # remove linefeeds for each section and output the contents
    $htmlFDescription = $FailedOperations2 -replace '\r*\n', ''
    $htmlSDescription = "<table><colgroup><col/></colgroup><tr><th>Logs Description</th></tr><tr><td>No Success Logs</td></tr></table>"
    $OperationType = 'Failed'
    Write-Host "##vso[task.setvariable variable=htmlFDescription;isoutput=true]$htmlFDescription"
    Write-Host "##vso[task.setvariable variable=htmlSDescription;isoutput=true]$htmlSDescription"
    Write-Host "##vso[task.setvariable variable=OperationType;isoutput=true]$OperationType"
    Write-Output "6. Sending email with OPCode $OperationType..." -Verbose 
    #Send-Mail -to $requesterEmailAddress -from 'AzureNoReply@nationalgrid.com' -emailSubject "GitHUb Onboarding Suceeded" -GitHubTeam $TeamName -smtpServer "smtpapp.nationalgrid.com" -portnumber 25 -GitHubRepos $RepoName -GitHubOrgName $OrgName -SubscriptionName $subscriptionName -Description $FailedOperations

}

