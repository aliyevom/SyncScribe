Function Send-SuccessMail {
    param(
        [string] $to,
        [string] $from,
        [string] $emailSubject,
        [string] $smtpServer,
        [int32]  $portnumber,
        [string] $GitHubTeam,
        [string] $GitHubOrgName,
        [string] $GitHubRepos,
        [string] $SubscriptionName,
        [string] $attachment,
        [string] $SDescription,
        [string] $FDescription,
        [string] $OperationType
    )

    try {
        Write-Verbose "Sending Mail.." -Verbose 
        $emailPattern =   '^[^@\s]+@[^@\s]+\.[^@\s]+$'
        $toEmailAddresses = @()
   
        foreach($emailAddress in $to.Split(',')){
       
           if($emailAddress -match $emailPattern){
               $toEmailAddresses += $emailAddress
           }
        }
<#
        $Description1 =New-Object System.Collections.Generic.List[System.Object]
        $Description1.Add("GitHub Repo created Successfully")
        $Description1.Add("GitHub Teams Created Successfully")
        $Description1.Add("GitHub Environment Created Successfully")
        $Description1.Add("GitHub Environment Secrets created Successfully")

$htmlDescription = $Description1 | ForEach{[PSCustomObject]@{'Operation Description'=$_}} | ConvertTo-HTML -Fragment -Property 'Operation Description' |Out-String
$htmlDescription
#>
        $emailbody1 = @"

        <!DOCTYPE html><html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="x-apple-disable-message-reformatting"><title></title><style>table, td, div, h1, p {font-family: Arial, sans-serif;}</style></head>
<body style="margin:0;padding:0;"><table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;"><tr> </tr><tr><td align="center" style="padding:0 0 5px 0;background:#70bbd9;"><img src="cid:header.jpg" alt="" width="602" style="height:auto;display:block;" /></td></tr><tr><td style="padding:36px 30px 42px 30px;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;"><tr><td style="padding:0 0 36px 0;color:#153643;">
                <h1 style="font-size:24px;margin:0 0 0px 0;font-family:Arial,sans-serif;">
"@

    $emailbody2 = " GitHub Environment Details: "
    $emailbody3 = @"
    </h1><p style="font-size:14px;margin:0 0 20px 0;font-family:Arial,sans-serif;">
                <span style="color:#626cf5" ><b></b></span>
    </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
   
   $emailbody4 ="Your Landing Zone <b> " +$SubscriptionName + " </b> is onboarded to the GitHub Repos "
   $emailbody5="<b>"
   $emailbody6="$GitHubRepos"
   $emailbody7= "</b> in <b> "
   $emailbody8= $GitHubOrgName + " </b> Organization."
   $emailbody9= @" 
                </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody91 = "Success Logs: "
$emailbody92 =@"
</p>
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@
$emailbody93 =$SDescription
$emailbody94= @" 
</p><b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;color:red">
"@
$emailbody10 = "Error/Warning/Info Logs: "
$emailbody11 =@"
</p></b>
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@
$emailbody12 =$FDescription
$emailbody13= @" 
</p><b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;color:red">
"@ 
$emailbody14 = "Please validate GitHub Organization access is completed for the requestor and submitted details are correct. Contact CPET Team if there are Errors logs in the Errors Description Table above."
$emailbody141= @" 
</p></b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
$emailbody142= @" 
</p><b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
$emailbody143 = "Please note, All Environments -Dev, QA, UAT, Prod in GitHub Action, will be created. However, Only this Subscription's secrets will be added. Please send an email to CPET Team in case you want to onboard an existing Subscription to this repo if this is the first onboarding. All New Landing zones will be automatically get onboarded if GitHub onboarding is selected while raising the ServiceNow request."
$emailbody144= @" 
</p></b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
$emailbody145 = "Plase bookmark below URLs for easy access to the GitHub Repository and GitHub Teams "
$emailbody15= @" 
</p></b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@ 
$emailbody151 = "GitHub Repository Link:"

$emailbody152= @" 
</p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody16 ="https://github.com/" + $GitHubOrgName +"/" + $GitHubRepos

   $emailbody17 =@"
   </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody18 =@"
</p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody19 ="You can manage access to the GitHub Repos using GitHub Teams, by adding/removing Users to the Team " + $GitHubTeam + " using below link:"
$emailbody20 =@"
</p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody21 ="https://github.com/orgs/" + $GitHubOrgName +"/teams/" + $GitHubTeam +"/members"
$emailbody22 =@"
</p><b><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
"@
$emailbody23 = "Please ensure new User has requested access to the GitHub Organization before adding him/her to the Teams. Please follow GitHub Onboarding Guide link provided in the email for User onboarding. "

   #$emailbody14 =@"
   #</p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
  # "@
$emailbody24= @"                     
 </b><p></p><table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center" bgcolor="#ffffff" style="background-color: #ffffff;">
                                        <table class="es-content-body" width="600" cellspacing="0" cellpadding="0" align="center">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p40t es-p30r es-p30l" style="background-position: left bottom; background-color: #ffffff;" align="left" bgcolor="#ffffff">
                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="esd-container-frame" width="540" valign="top" align="center">
                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center" class="esd-block-text es-p10b es-m-txt-c">
                                                                                        <h3>IAC Framework - A getting Started Guide</h3>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td align="left" class="esd-block-text es-p5b es-m-txt-c">
                                                                                        <p style="line-height: 150%;">Learn about how to access the IaC Products and Services from the following site: </p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
"@
   $emailbody25=@"
   </p><p style="margin:0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;"><a href="
"@
   $emailbody26 ="https://nationalgridplc.sharepoint.com/sites/COMMS-INT-GLOBAL-PlatformsAndCloud/Wisdom/SitePages/P&S.aspx"
   
   $emailbody27=@"
   " style="color:s#ee4c50;text-decoration:underline;">
"@

   $emailbody28 ="Our Products & Services"

   $emailbody29 =@"
   </a></p>
   </br><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">The CPET Team is available to answer any questions you may have. </p><p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Thank you in advance for your cooperation. </p></td></tr></table></td></tr> <tr><td style="padding:30px;background:#e99415;"><table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;"><tr><td style="padding:0;width:50%;" align="left"><p style="margin:0;font-size:16px;line-height:22px;font-family:Arial,sans-serif;color:#ffffff;"><a href="https://nationalgridplc.sharepoint.com/sites/GRP-COMMS-INT-US-GridStack/Shared%20Documents/Forms/AllItems.aspx?newTargetListUrl=https%3A%2F%2Fnationalgridplc%2Esharepoint%2Ecom%2Fsites%2FGRP%2DCOMMS%2DINT%2DUS%2DGridStack%2FShared%20Documents&id=%2Fsites%2FGRP%2DCOMMS%2DINT%2DUS%2DGridStack%2FShared%20Documents%2FGitHub%20Access&viewid=97c22314%2D4b20%2D4eb5%2D8b88%2Db183dc2639f6&OR=Teams%2DHL&CT=1709105537259&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIxNDE1LzI0MDEwNDE3NTA0IiwiSGFzRmVkZXJhdGVkVXNlciI6ZmFsc2V9" style="color:#ffffff;text-decoration:underline;">GitHub Onboarding Guide</a>
       </p></td><td style="padding:0;width:50%;" align="right"><p style="margin:0;font-size:16px;line-height:22px;font-family:Arial,sans-serif;color:#ffffff;"><a href="mailto:box.cloudcoe@nationalgrid.com?subject=GitHub%20Onboarding%20Query" style="color:#ffffff;text-decoration:underline;">Contact CPET Team</a></p></td></tr></table></td></tr></table></body></html>
"@

$emailbody =$emailbody1 +$emailbody2 +$emailbody3 +$emailbody4 +$emailbody5 +$emailbody6 +$emailbody7 +$emailbody8 +$emailbody9 +$emailbody91 +$emailbody92 +$emailbody93 +$emailbody94 +$emailbody10 +$emailbody11 +$emailbody12 +$emailbody13 +$emailbody14 +$emailbody141 +$emailbody142 +$emailbody143 +$emailbody144 +$emailbody145 +$emailbody15 +$emailbody151 +$emailbody152 +$emailbody16 +$emailbody17 +$emailbody18 +$emailbody19 +$emailbody20 +$emailbody21 +$emailbody22 +$emailbody23 +$emailbody24 +$emailbody25 +$emailbody26 +$emailbody27 +$emailbody28 +$emailbody29



        $mailBody = @{
            To         = $toEmailAddresses
            From       = $from 
            Subject    = $emailSubject
            Body       = $emailbody
            smtpServer = $smtpServer
            Port       = $portnumber
            BodyAsHtml = $true
            Attachment = $attachment
        }
        Send-MailMessage @mailBody -Verbose
        Write-Verbose "Email sent with subject:$emailSubject" -Verbose
    }
    catch {
        Write-Warning -Message "Failed to send Mail`n$_" -Verbose
    }
}

#Send-SuccessMail -to 'arvind.mahto@nationalgrid.com' -from 'AzureNoReply@nationalgrid.com' -emailSubject "Test Email" -smtpServer 'smtpapp.nationalgrid.com' -portnumber 25 -startDate '12/12/2012' -endDate '12/13/2012' -GitHubOrgName 'Nationalgrid-dpit' -Environment 'Prod' -Communication 'initial' -GitHubRepos "US-23456" -SubscriptionName "US-23456-DEV-01" -GitHubTeam "US-23456-Team" -attachment ".\images\header.jpg" -SDescription "Test" -FDescription "Test" -OperationType "Succeeded"