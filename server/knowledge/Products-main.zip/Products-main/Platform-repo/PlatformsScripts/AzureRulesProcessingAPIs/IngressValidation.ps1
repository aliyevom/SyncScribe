Function Invoke-IngressInputValidation {
    param(
        [string]$subscriptionId,
        [string]$sourceIpAddress,
        [string]$destinationAddress,
        [string]$inboundPorts,
        [string]$storageAccountSubscriptionId,
        [string]$storageAccountResourceGroup,
        [string]$storageAccountName,
        [string]$tableName
    )

    try {       

        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        $cloudTable = (Get-AzStorageTable –Name $tableName –Context $ctx).CloudTable

        Install-Module -Name AzTable -RequiredVersion 2.1.0 -Force

        [string]$ingressFilter = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("PartitionKey", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, "ingress")
        [string]$sourceFilter = [Microsoft.Azure.Cosmos.Table.TableQuery]::GenerateFilterCondition("Source", [Microsoft.Azure.Cosmos.Table.QueryComparisons]::Equal, $sourceIpAddress)
        [string]$selectFilter = [Microsoft.Azure.Cosmos.Table.TableQuery]::CombineFilters($ingressFilter, "and", $sourceFilter)

        $selectRow = Get-AzTableRow -table $cloudTable -CustomFilter $selectFilter

        if ($null -eq $selectRow) {
            throw "Error: Invalid rule entry. Check ingressEgressRulesDataStore table for allowed rules"
        }
        else {

            #Get the table port value (in string form and as an array to check both)
            $portsValue = $selectRow[0].port
            $portsArray = $portsValue.Split(",")

            #Get the reverse ports string 
            $inboundPortsArray = $inboundPorts.Split(",")
            $inboundPortsArrayReverse = $inboundPortsArray.Clone()
            [array]::Reverse($inboundPortsArrayReverse)
            $reverseInbound = $inboundPortsArrayReverse -join ","
            
            #Get the table subscription value
            $subscriptionValue = $selectRow[0].subscription
            
            #Get the table destination value
            $destinationValue = $selectRow[0].destination
            $destinationArray = $destinationValue.Split(",")

            if (($destinationAddress -notmatch $destinationArray[0]) -and ($destinationAddress -notmatch $destinationArray[1])) {
                $inputMatch = $false
            }
            elseif (($inboundPorts -ne $portsValue) -and ($reverseInbound -ne $portsValue) -and ($portsArray -notcontains $inboundPorts)) {
                $inputMatch = $false
            }
            elseif (($subscriptionId -ne "*") -and ($subscriptionId -ne "Any") -and ($subscriptionId -ne $subscriptionValue) -and ($subscriptionId -ne "d004487f-755f-432f-981b-63d14a835b16")) {
                $inputMatch = $false
            }
            else {
                $inputMatch = $true
                Write-Output "Valid rule entry"
            }

        }

        if ($inputMatch -eq $false) {
            throw "Error: Invalid rule entry. Check ingressEgressRulesDataStore table for allowed rules"
        }
    }
    catch {
        throw $_
    }
}