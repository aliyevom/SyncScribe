﻿<##

#>
Function Invoke-AzureIngressControllerApi {
  param(
    [string]$location,
    [string]$region,
    [string]$environment,
    [string]$applicationId,
    [string]$subscriptionId,
    [string]$hubSubscriptionId,
    [string]$destinationAddress,
    [string]$publishedWebUrl,
    [string]$certName,
    [string]$healthProbePath,
    [int]$probeInterval,
    [int]$probeTimeout,
    [int]$probeUnhealthyThreshold

  )
  #
  # global configs

  $subMetaData = ((get-azsubscription | Where-Object { $_.SubscriptionId -eq $subscriptionId }).Name -split ('-') )

  $backendPool = [string]::Concat($subMetaData[1], '-', $destinationAddress, '-bp-', $subMetaData[-1])
  $CustomProbe = [string]::Concat($subMetaData[1], '-', $destinationAddress, '-probe-', $subMetaData[-1])
  $hostListener = [string]::Concat($subMetaData[1], '-', $destinationAddress, '-httpsListener-', $subMetaData[-1])
  $routingRule = [string]::Concat($subMetaData[1], '-', $destinationAddress, '-routingRule-', $subMetaData[-1])
  $httpsPoolSettings = [string]::Concat($subMetaData[1], '-', $destinationAddress)
  $appGatewayName = [string]::Concat($applicationId, '-', $environment, '-', $region, '-ingress-agw-', $subMetaData[-1])
  $resourceGroupName = [string]::Concat($applicationId, '-', $environment, '-', $region, '-ingress-agw-rg')

  $ipAddressParameters = @{
    subscriptionId  = $subscriptionId
    sourceIpAddress = $destinationAddress
    region          = $location
  }
  try {
    if ( (Test-ValidIpAddress @ipAddressParameters) ) {
      Set-AzContext $hubSubscriptionId
      $appgw = Get-AzApplicationGateway  -ResourceGroupName $resourceGroupName -Name $appGatewayName

      if ($null -ne $appgw) {

        # get Frontend Configs / extract public Frontend config.
        $appfrontendIPconfig = ($appgw.FrontendIPConfigurations) | ForEach-Object { $_ | Where-Object { $_.publicIpAddress -ne $null } } 
        $frontendPort = Get-AzApplicationGatewayFrontendPort -ApplicationGateway $appgw | Where-Object { $_.Port -eq '443' }

        # Create the backend pool 
        $backendPoolParam = @{
          Name               = $backendPool
          ApplicationGateway = $appgw
          BackendIPAddresses = $destinationAddress
        }
        add-AzApplicationGatewayBackendAddressPool @backendPoolParam
        $bePool = get-AzApplicationGatewayBackendAddressPool -Name $backendPool -ApplicationGateway $appgw

        # Create Probe
        Add-AzApplicationGatewayProbeConfig -Name $CustomProbe -Protocol Http -Path $healthProbePath  `
          -PickHostNameFromBackendHttpSettings `
          -Interval $probeInterval -Timeout $probeTimeout `
          -UnhealthyThreshold $probeUnhealthyThreshold  -ApplicationGateway $appgw
        $probe = Get-AzApplicationGatewayProbeConfig -Name $CustomProbe -ApplicationGateway $appgw

        #Create Https Settings 
        Add-AzApplicationGatewayBackendHttpSetting  -Name $httpsPoolSettings  -Probe $probe `
          -Port 80  -Protocol http -CookieBasedAffinity Enabled `
          -PickHostNameFromBackendAddress -ApplicationGateway $appgw
        $bePoolSettings = Get-AzApplicationGatewayBackendHttpSetting -Name $httpsPoolSettings  -ApplicationGateway $appgw

        #get Authentication Certificate
        $cert = Get-AzApplicationGatewaySslCertificate -ApplicationGateway $appgw -Name $certName

        # Create Multi-host listener 
        add-AzApplicationGatewayHttpListener  -Name $hostListener -HostName $publishedWebUrl `
          -Protocol Https  -FrontendIPConfiguration $appfrontendIPconfig `
          -FrontendPort $frontendPort -SslCertificate $cert -ApplicationGateway $appgw 
        $multHostlistener = get-AzApplicationGatewayHttpListener -Name $hostListener  -ApplicationGateway $appgw

        # Create Rule and tie all together
        add-AzApplicationGatewayRequestRoutingRule  -Name $routingRule -RuleType Basic `
          -HttpListener $multHostlistener -BackendAddressPool $bePool `
          -BackendHttpSettings $bePoolSettings -ApplicationGateway $appgw 
        # Write and update configs
        Set-AzApplicationGateway -ApplicationGateway $appgw 
      }
      else {
     
        throw "Error | Azure Application gateway '$($appGatewayName)' does not exist."
      } 
    }
    else {
      throw "Error | Destination IP '$($destinationAddress)' does not belong to ADT subscription $($subscriptionId)."
    }
  }
  catch {
    throw $_
  }

}