﻿function Remove-NSGRule {
    param(
        [string]$subscriptionId,
        [string]$nsgName,
        [string]$ruleName
    )
    

    if (($ruleName -eq 'Deny_All_Inbound') -or ($ruleName -eq 'Deny_All_Outbound')) {
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | $nsgName failed to remove NSG rule, $ruleName is invalid to remove.")
        throw "Error | $nsgName failed to remove NSG rule, $ruleName is invalid to remove."
    }
    else {
        try {
        
            #Set Subscription Context
            Set-AzContext -SubscriptionId $subscriptionId
   
            # Get the NSG resource
            $nsg = Get-AzNetworkSecurityGroup -Name $nsgName
            if($null -eq $nsg){
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "NSG Name: $nsgName ,  could not be found")
                throw "Error | $nsgName is not a valid Network Security Group Name. `n"

            }
        
            if($nsg.SecurityRules.Where{ $ruleName -eq $_.Name }) {
            # Remove the NSG security rule.

            $vNetLocked = @{
                ResourceName      = $nsgName
                ResourceType      = 'Microsoft.Network/networkSecurityGroups'
                ResourceGroupName = $nsg.resourceGroupName
                LockName          = "networkSecurityGroupDoNotDelete"
            }
            Write-Verbose "Network Security '$($nsgName)' DoNotDeleteLock processing..." -verbose
            $vNetLocked 
            $isLockThere = Get-AzResourceLock @vNetLocked -ErrorAction SilentlyContinue

            if($isLockThere) {
                Write-Verbose "Lock is Valid"
                Remove-Lock -resourceLock $vNetLocked -verbose
                } else {
                Write-Verbose "Lock is not valid"
            }
            

            Remove-AzNetworkSecurityRuleConfig -Name $ruleName -NetworkSecurityGroup $nsg

            $nsg | Set-AzNetworkSecurityGroup

            $vNetLocked = @{
                LockLevel         = "CanNotDelete"                                                                                                                                                                            
                LockName          = "networkSecurityGroupDoNotDelete"               
                ResourceName      = $nsgName
                ResourceType      = 'Microsoft.Network/networkSecurityGroups'
                ResourceGroupName = $nsg.ResourceGroupName
            }
            Write-Verbose "Virtual Network '$($nsgName)'  processing Lock DoNotDeleteLock ..." -verbose            
            Add-Lock -resourceLock $vNetLocked -verbose
            }
            else{
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | $ruleName could not be found. `n")
                throw "Error | $ruleName could not be found. `n"
            }

        }
        catch {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error $_")
            throw "Error | $nsgName failed to remove NSG rule: $ruleName. $_"
        }      
    }
}