function Update-NSGRule {
    param(
        [string]$subscriptionId,
        [string]$nsgName,
        [string]$protocol,
        [string]$sourceAddress,
        [string]$destinationAddresses,
        [string]$destinationPortRanges
    )
    try {

        #Set Subscription Context
        Set-AzContext -SubscriptionId $subscriptionId
        # Single IP address pattern.
        $ipPattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
        # URL Pattern
        $urlPattern = "((^(http[s]?:\/\/)?([w]{3}[.])?(([a-z0-9-\.]+)+(com|net|org|ms|ai)))$)"
        $destinationPortArray = @($destinationPortRanges -split ',')
        $destinationAddressArray = @($destinationAddresses -split ',')
        foreach ($destinationAddress in $destinationAddressArray) {
            # Is Destination a vaild IPV4 address
            if ($destinationAddress -match $ipPattern) {
                $isIP = $true
            }
            elseif ($destinationAddress -match $urlPattern) {
                $isIP = $false
            } 
            else {
                Write-Warning "Not a valid Destination address" -Verbose
            }
        }
        # Get the NSG resource
        $nsg = Get-AzNetworkSecurityGroup -Name $nsgName
        if($null -eq $nsg) {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "NSG: $nsgName , could not be found")
            throw "NSG Name could not be found"
            } else {
            Write-Host "NSG Found"
            }
        $rulesCount = $nsg.SecurityRules.Count

        if ($rulesCount -lt 1000) {
            # Must be changed to get next available priority value
            if ([String]::IsNullOrEmpty($nsg.SecurityRules.Where( { $_.Direction -eq "Outbound" })) ) {
                $lowerBoundPriority = 101
            }
            else {
                $lowerBoundPriority = ($nsg.SecurityRules | Where-Object { $_.Direction -eq "Outbound" } | Sort-Object priority).priority[0]            
            }
            $upperBoundPriority = ($nsg.SecurityRules.Where( { $_.direction -eq 'Outbound' -and $_.name -eq "Deny_All_Outbound" } )).Priority
            if ([String]::IsNullOrEmpty($upperBoundPriority) ) {
                $upperBoundPriority = 4096
            }
            $priorities = @(($nsg.SecurityRules | Where-Object { $_.Direction -eq "Outbound" } | Sort-Object priority).priority)

            Write-Host "Start Priority:$lowerBoundPriority"
            Write-Host "End Priority:$upperBoundPriority"
            Write-Host "Priorites: $priorities"
            $defaultPriorityIncrement = 1
            $priority = $lowerBoundPriority
            foreach ($val in $lowerBoundPriority .. $upperBoundPriority) {           
                if ($val -notin $priorities) {
                    break
                }
                else {
                
                    $priority = $priority + $defaultPriorityIncrement 
                }
            }
            if ($priority -ge $upperBoundPriority) {
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | $($nsg.Name) failed to add rule. Can't compute priority, reached limit $($upperBoundPriority) ")
                return "Error | $($nsg.Name) failed to add rule. Can't compute priority, reached limit $($upperBoundPriority) " 
            }
    
            Write-Host "Calculated Priority: $priority"
            $result = $priority
            $namesplit = $destinationPortRanges.Replace(',', '-')
            $addressSplit = $destinationAddresses.Replace(',', '-')
            $rulename = "out-$addressSplit-$protocol-$namesplit-$priority-allow"
            Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'rulename', $rulename)
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'rulename;issecret=false;isOutput=true', $rulename)
            if ($isIP) {
                # Add the Outbound security rule for Ip address. Skipping Outbound Security rule for FQDN since 443 any-any is already allowed.
                $nsg | Add-AzNetworkSecurityRuleConfig -Name $rulename.ToLower() -Description "Allow app port" -Access Allow `
                    -Protocol $protocol -Direction Outbound -Priority $priority -SourceAddressPrefix $sourceAddress -SourcePortRange * `
                    -DestinationAddressPrefix $destinationAddressArray -DestinationPortRange $destinationPortArray
                # Update the NSG.
                $nsg | Set-AzNetworkSecurityGroup 
            }
            elseif (443 -notin $destinationPortArray) {
            
                $nsg | Add-AzNetworkSecurityRuleConfig -Name $rulename.ToLower() -Description "Allow app port" -Access Allow `
                    -Protocol $protocol -Direction Outbound -Priority $priority -SourceAddressPrefix $sourceAddress -SourcePortRange * `
                    -DestinationAddressPrefix 'Internet' -DestinationPortRange $destinationPortArray
                # Update the NSG.
                $nsg | Set-AzNetworkSecurityGroup 
            } 
            else {
                Write-Warning "Request is to allow traffic to 443. This is already allowed by existing NSG Rule" -Verbose
            }
        }
        else {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Number of NSG Rules exceeded 1000")
            Write-Error -Message "Number of NSG Rules exceeded 1000" -ErrorAction Stop -Verbose
        }
    }
    catch {
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error $_ ")
        throw "Error | $($nsg.Name) failed to add rule.`n$_"
    }      

    Return $result
}

