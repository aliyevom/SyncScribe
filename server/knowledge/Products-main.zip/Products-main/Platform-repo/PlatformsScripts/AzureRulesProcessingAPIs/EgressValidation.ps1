<#
.SYNOPSIS
    Egress Rules Validation

.DESCRIPTION
    The PowerShell script below validates the requested Egress Rules against the Ingress Egress Table in Azure

.PARAMETER subscriptionId
    ADT Subscription ID 

.PARAMETER sourceIpAddress
    Source IP address requesting Egress Access

.PARAMETER destinationAddresses
    Destination list of FQDNs or Network IPs (Comma separated)

.PARAMETER protocol
    Protocol a requirement for outbound Access TCP/UDP

.PARAMETER outboundPorts
   Comma Separated Destination Ports required by Application.

.PARAMETER storageAccountSubscriptionId
   Subscription ID where the Ingress Egress Table Storage exists

.PARAMETER storageAccountResourceGroup
   Resource group where the Ingress Egress Table Storage exists

.PARAMETER storageAccountName
   Storage Account Name where the Ingress Egress Table Storage exists

.PARAMETER tableName
   Table Name (IngressEgressRulesDataStore)

.EXAMPLE

.NOTES
	Version      : 1.1.0
	Last Updated : 5/24/2021
#>
Function Invoke-EgressInputValidation {
    param(
        [string]$subscriptionId,
        [string]$sourceIpAddress,
        [string]$destinationAddresses,
        [string]$protocol,
        [string]$outboundPorts,
        [string]$storageAccountSubscriptionId,
        [string]$storageAccountResourceGroup,
        [string]$storageAccountName,
        [string]$tableName
    )
    try {       

        # URL Pattern
        $urlPattern = "((^(http[s]?:\/\/)?([w]{3}[.])?(([a-z0-9-\.]+)+(com|net|org|ms|ai)))$)"
        # IP Pattern
        $ipPattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
        # Azure Subscription Pattern
        $guidPattern = "(^([0-9A-Fa-f]{8}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{12})$)"
        $i = 0
        $sourceIpAddressSplit = $sourceIpAddress.Split("/")[0]
        $destinationAddressArray = @($destinationAddresses -split ',')
        Write-Verbose "Destination Addresses:$destinationAddressArray"
        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        $cld = Get-AzStorageTable –Name $tableName –Context $ctx
        $cloudTable = $cld.CloudTable
        Install-Module -Name AzTable -RequiredVersion 2.1.0 -Force
        $cloudTableEgress = Get-AzTableRow -Table $cloudTable -PartitionKey "egress"
        foreach ($inputdestinationAddress in $destinationAddressArray) {
            if ($inputdestinationAddress -match $urlPattern -and $sourceIpAddressSplit -match $ipPattern) {
                Write-Verbose "$inputdestinationAddress is a Valid URL and $sourceIpAddress is a valid IP" -Verbose
                Write-Verbose "Proceeding to check if $inputdestinationAddress is a allowed destination in Azure Ingress Egress Table" -Verbose
                while ($null -ne $cloudTableEgress[$i].PartitionKey) { 
                    #Get the table destination value
                    $destinationValue = $cloudTableEgress[$i].destination
                    Write-Verbose "DestinationAddress row from Table: $destinationValue" -Verbose
                    if ($cloudTableEgress[$i].destination -match "^\*\.") {
                        $destinationArray = $destinationValue.Split("*")
                        $destinationSuffix = $destinationArray[1]
                        Write-Verbose "Actual DestinationAddress row from Table for comparison after regex matches: $destinationSuffix" -Verbose
                        # Pattern match for wildcard *. at the beginning
                        $patternCheck = "((^(http[s]?:\/\/)?([w]{3}[.])?|([w]{3}[.][a-z]*)?)$destinationSuffix$)"
                        Write-Verbose "Pattern(1) used to check:$patternCheck" -Verbose
                    }
                    elseif ($cloudTableEgress[$i].destination -match "^\*\-") {
                        $destinationArray = $destinationValue.Split("*")
                        $destinationSuffix = $destinationArray[1]
                        Write-Verbose "Actual DestinationAddress row from Table for comparison after regex matches: $destinationSuffix" -Verbose
                        # Pattern match for wildcard *- at the beginning
                        $patternCheck = "((^(http[s]?:\/\/)?([w]{3}[.])?|([w]{3}[.][a-z]*)?)$destinationSuffix$)"
                        Write-Verbose "Pattern(2) used to check:$patternCheck" -Verbose
                    }
                    else {
                        $destinationSuffix = $destinationValue
                        Write-Verbose "Actual DestinationAddress row from Table for comparison after regex matches: $destinationSuffix" -Verbose
                        # Pattern match for just the exact URL with http/https or www in the beginning
                        $patternCheck = "((^(http[s]?:\/\/)?([w]{3}[.])?)$destinationSuffix$)"
                        Write-Verbose "Pattern(3) used to check:$patternCheck" -Verbose
                    }
                    #Get the table port value (in string form and as an array to check both)
                    $portsValue = $cloudTableEgress[$i].port
                    $portsArray = $portsValue.Split(",")
        
                    #Get the reverse ports string 
                    $outboundPortsArray = $outboundPorts.Split(",")
                    $outboundPortsArrayReverse = $outboundPortsArray.Clone()
                    [array]::Reverse($outboundPortsArrayReverse)
                    $reverseoutbound = $outboundPortsArrayReverse -join ","
        
                    #Get the table sourceIp value
                    $sourceIpValue = $cloudTableEgress[$i].source
                    #Get the table scope value
                    $scopeValue = $cloudTableEgress[$i].scope
                    #Validate input values against table values
                    if ($inputdestinationAddress -notmatch $patternCheck) {
                        Write-Verbose "Input destinationAddress for comparison:$inputdestinationAddress" -Verbose
                        Write-Verbose "Arrived Comparison Pattern:$patternCheck" -Verbose
                        $inputMatch = $false
                        Write-Warning "Failed because destinationAddress is not matching the row in Azure Table.InputMatch(0) is: $inputMatch" -Verbose
                    }
                    elseif (($outboundPorts -ne $portsValue) -and ($reverseoutbound -ne $portsValue) -and ($portsArray -notcontains $outboundPorts)) {
                        Write-Verbose "outboundPorts:$outboundPorts" -Verbose
                        Write-Verbose "portsValue:$portsValue" -Verbose
                        Write-Verbose "reverseoutbound:$reverseoutbound" -Verbose
                        Write-Verbose "portsArray:$portsArray" -Verbose
                        $inputMatch = $false
                        Write-Warning "Failed due to improper Outbound ports.InputMatch(1) is: $inputMatch" -Verbose
                        break
                    }
                    elseif (($sourceIpAddress -ne "*") -and ($sourceIpAddress -ne "Any") -and ($sourceIpAddress -ne $sourceIpValue) -and ($scopeValue -ne "*")) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper SourceIp Address.InputMatch(2) is: $inputMatch" -Verbose
                        break
                    }
                    elseif (($subscriptionId -ne "*") -or ($subscriptionId -ne "Any") -and ($subscriptionId -notmatch $guidPattern)) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper Subscription ID.InputMatch(3) is: $inputMatch" -Verbose
                        break
                    }
                    elseif ($scopeValue -ne "*" -and $subscriptionId -notmatch $guidPattern) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper scope value.InputMatch(4) is: $inputMatch " -Verbose
                        break
                    }
                    else {
                        $inputMatch = $true
                        Write-Verbose "InputMatch(5) is: $inputMatch " -Verbose
                        Write-Output "$inputdestinationAddress is found in Ingress Egress Table and is a Valid rule entry"
                        break
                    }
        
                    $i++ 
                }
                if ($inputMatch -eq $false) {
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error: Invalid rule entry. Try adding port 80 to your run if you were solely using port 443.")
                    throw "Error: Invalid rule entry. Check ingressEgressRulesDataStore table for allowed rules"
                }
            }
            elseif ($inputdestinationAddress.Split("/")[0] -match $ipPattern -and $sourceIpAddressSplit -match $ipPattern) {
                Write-Verbose "$inputdestinationAddress is a Valid IP and $sourceIpAddress is also a valid IP" -Verbose
                Write-Verbose "Proceeding to check if $inputdestinationAddress is a allowed destination in Azure Ingress Egress Table" -Verbose
                while ($null -ne $cloudTableEgress[$i].PartitionKey) { 
                    #Get the table destination value
                    $destinationValue = $cloudTableEgress[$i].destination
                    Write-Verbose "DestinationAddress row from Table: $destinationValue" -Verbose
                    #Get the table port value (in string form and as an array to check both)
                    $portsValue = $cloudTableEgress[$i].port
                    $portsArray = $portsValue.Split(",")
        
                    #Get the reverse ports string 
                    $outboundPortsArray = $outboundPorts.Split(",")
                    $outboundPortsArrayReverse = $outboundPortsArray.Clone()
                    [array]::Reverse($outboundPortsArrayReverse)
                    $reverseoutbound = $outboundPortsArrayReverse -join ","
        
                    #Get the table sourceIp value
                    $sourceIpValue = $cloudTableEgress[$i].source
                    #Get the table scope value
                    $scopeValue = $cloudTableEgress[$i].scope
                    #Validate input values against table values
                    if ($inputdestinationAddress -notlike $destinationValue) {
                        Write-Verbose "Input destinationAddress for comparison:$inputdestinationAddress" -Verbose
                        Write-Verbose "DestinationAddress from Azure Table:$destinationValue" -Verbose
                        $inputMatch = $false
                        Write-Warning "Failed because destinationAddress is not matching the row in Azure Table.InputMatch(0) is: $inputMatch" -Verbose
                    }
                    elseif (($outboundPorts -ne $portsValue) -and ($reverseoutbound -ne $portsValue) -and ($portsArray -notcontains $outboundPorts)) {
                        Write-Verbose "outboundPorts:$outboundPorts" -Verbose
                        Write-Verbose "portsValue:$portsValue" -Verbose
                        Write-Verbose "reverseoutbound:$reverseoutbound" -Verbose
                        Write-Verbose "portsArray:$portsArray" -Verbose
                        $inputMatch = $false
                        Write-Warning "Failed due to improper Outbound ports.InputMatch(1) is: $inputMatch" -Verbose
                        break
                    }
                    elseif (($sourceIpAddress -ne "*") -and ($sourceIpAddress -ne "Any") -and ($sourceIpAddress -ne $sourceIpValue) -and ($scopeValue -ne "*")) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper SourceIp Address.InputMatch(2) is: $inputMatch" -Verbose
                        break
                    }
                    elseif (($subscriptionId -ne "*") -or ($subscriptionId -ne "Any") -and ($subscriptionId -notmatch $guidPattern)) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper Subscription ID.InputMatch(3) is: $inputMatch" -Verbose
                        break
                    }
                    elseif ($scopeValue -ne "*" -and $subscriptionId -notmatch $guidPattern) {
                        $inputMatch = $false
                        Write-Warning "Failed due to improper scope value.InputMatch(4) is: $inputMatch " -Verbose
                        break
                    }
                    else {
                        $inputMatch = $true
                        Write-Verbose "InputMatch(5) is: $inputMatch " -Verbose
                        Write-Output "$inputdestinationAddress is found in Ingress Egress Table and is a Valid rule entry"
                        break
                    }
        
                    $i++ 
                }
                if ($inputMatch -eq $false) {
                    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error: Invalid rule entry. Try adding port 80 to your run if you were solely using port 443.")
                    throw "Error: Invalid rule entry. Check ingressEgressRulesDataStore table for allowed rules"
                }
            }
            else {
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Either $inputdestinationAddress is not a valid Destination address or $sourceIpAddress is not a valid IP Address. If you believe both of these are valid and you're trying to run for port 443, run with ports 443,80")
                Write-Error "Either $inputdestinationAddress is not a valid Destination address or $sourceIpAddress is not a valid IP Address.  If you believe both of these are valid and you're trying to run for port 443, run with ports 443,80" -Verbose
            }
        }
    }
    catch {
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
        throw $_
    }
}