function Update-NSGRule {
    param(
        [string]$subscriptionId,
        [string]$nsgName,
        [string]$protocol,
        [string]$sourceAddress,
        [string]$destinationAddress,
        [string]$destinationPortRanges
    )
    try {
        
        #Set Subscription Context
        Set-AzContext -SubscriptionId $subscriptionId

        $destinationPortArray = @($destinationPortRanges -split ',')

        # Get the NSG resource
        $nsg = Get-AzNetworkSecurityGroup -Name $nsgName
        if($null -eq $nsg) {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "NSG: $nsgName could not be found")
            throw "NSG Name could not be found"
            } else {
           Write-Host "NSG Found"
           }

        # Must be changed to get next available priority value
        if ($null -eq ($nsg.SecurityRules | Where-Object { $_.Direction -eq "Inbound" })) {
            $lowerBoundPriority = 101
        }
        else {
            $lowerBoundPriority = ($nsg.SecurityRules | Where-Object { $_.Direction -eq "Inbound" } | Sort-Object priority).priority[0]            
        }
        $upperBoundPriority = ($nsg.SecurityRules.Where( { $_.direction -eq 'inbound' -and $_.name -eq "Deny_All_Inbound" } )).Priority
        $priorities = ($nsg.SecurityRules | Where-Object { $_.Direction -eq "Inbound" } | Sort-Object priority).priority

        Write-Host "Start Priority:$lowerBoundPriority"
        Write-Host "End Priority:$upperBoundPriority"
        Write-Host "Priorites: $priorities"

        $defaultPriorityIncrement = 1
        $priority = $lowerBoundPriority
        if ($upperBoundPriority -gt $lowerBoundPriority) {
            $priority = $lowerBoundPriority + $defaultPriorityIncrement
        }

        $lowerBoundPriority = $lowerBoundPriority + 1
            foreach ($val in $lowerBoundPriority .. $upperBoundPriority) {           
                if ($val -notin $priorities) {
                    break
                }
                else {
                    Write-Host "Incrementing Value $val by 1"
                    $priority = $priority + 1
                }
            }
    
            if ($priority -eq $upperBoundPriority) {
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | $($nsg.Name) failed to add rule. Can't compute priority, reached limit $($upperBoundPriority) ")
                return "Error | $($nsg.Name) failed to add rule. Can't compute priority, reached limit $($upperBoundPriority) " 

            }
        
            Write-Host "Calculated Priority: $priority"

            $result = $priority

            $namesplit = $destinationPortRanges.Replace(',', '-')
            $rulename = "inb-$sourceAddress-$protocol-$namesplit-$priority-allow"         
            
            Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'rulename', $rulename)
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'rulename;issecret=false;isOutput=true', $rulename)

            # Add the inbound security rule.
            $nsg | Add-AzNetworkSecurityRuleConfig -Name $rulename -Description "Allow app port" -Access Allow `
                -Protocol $protocol -Direction Inbound -Priority $priority -SourceAddressPrefix $sourceAddress -SourcePortRange * `
                -DestinationAddressPrefix $destinationAddress -DestinationPortRange $destinationPortArray
            # Update the NSG.
            $nsg | Set-AzNetworkSecurityGroup
        }
        catch {
            $result = "Error | $($nsg.Name) failed to add rule.`n$_"
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error: $_")
            throw $_
        }      
    
        Return $result
}

