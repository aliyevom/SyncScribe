<#
.SYNOPSIS
    NSG Port Validation

.DESCRIPTION
    The PowerShell script below validates the requested NSG Port against the NSG Approved ports Table in Azure

.PARAMETER subscriptionId
    ADT Subscription ID 

.PARAMETER destinationPortRanges
   Comma Separated Destination Ports required by Application.

.PARAMETER storageAccountSubscriptionId
   Subscription ID where the Ingress Egress Table Storage exists

.PARAMETER storageAccountResourceGroup
   Resource group where the Ingress Egress Table Storage exists

.PARAMETER storageAccountName
   Storage Account Name where the approved port Table Storage exists

.PARAMETER tableName
   Table Name (portDataStore)

.EXAMPLE

.NOTES
	Version      : 1.1.0
	Last Updated : 10/12/2021
#>
Function Invoke-NSGPortsInputValidation {
    param(
        [string]$subscriptionId,
        [string]$destinationPortRanges,
        [string]$storageAccountSubscriptionId,
        [string]$storageAccountResourceGroup,
        [string]$storageAccountName,
        [string]$tableName
    )
    try {       
        Set-AzContext -SubscriptionId  $storageAccountSubscriptionId | Out-Null
        $sta = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $storageAccountResourceGroup
        $ctx = $sta.Context
        $cld = Get-AzStorageTable –Name $tableName –Context $ctx
        $cloudTable = $cld.CloudTable
        
        Install-Module -Name AzTable -RequiredVersion 2.1.0 -Force

        $cloudTableNSGRule = Get-AzTableRow -Table $cloudTable -PartitionKey "Prod"
        $ApprovedPorts=@()
        $ApsString=$cloudTableNSGRule.PORT
        $ApprovedPorts= $ApsString.split(",")
        
        Write-Verbose "List of Approved ports $ApprovedPorts" -Verbose
        $destinitionports=$destinationPortRanges.split(",")
        #$a= $destinitionports -join ","
        #$a
        #$ApprovedPorts=@("10","11","12-50","70-90","100")
        $dpportarray=@()
        $apportarray=@()
        foreach ($dps in $destinitionports)
        {
        $eachvalue=0
        if([int]::TryParse( $dps, [ref]$eachvalue) )
        {
        $dpportarray += $dps
        $dps=0
        }
        else
        {
        $dpsrangearray= $dps.Split("-")
        $dpslowercounter=0
        $dpshighercounter=0
        $dpslowercounter =[int]$dpsrangearray[0]
        $dpshighercounter =[int]$dpsrangearray[1]
        for($dpslowercounter; $dpslowercounter -le $dpshighercounter; $dpslowercounter++)
        {
        #Write-Host $dpslowercounter
        $dpportarray += $dpslowercounter
        }
        }

        }
        #Write-Verbose "List of required ports $dpportarray" -Verbose
        foreach ($aps in $ApprovedPorts)
        {
        #$aps
        #Write-Verbose "List of processing ports $aps" -Verbose
        $eachvalue2=0
        if([int]::TryParse( $aps, [ref]$eachvalue2) )
        {
        $apportarray += $aps
        $aps=0
        }
        else
        {
        $apsrangearray= $aps.Split("-")
        $apslowercounter=0
        $apshighercounter=0
        $apslowercounter =[int]$apsrangearray[0]
        $apshighercounter =[int]$apsrangearray[1]
        for($apslowercounter; $apslowercounter -le $apshighercounter; $apslowercounter++)
        {

        $apportarray += $apslowercounter
        }
        }

        }


        #$dpportarray
        #$apportarray


        $inapport=@()
        $notinapport=@()
        foreach($dport in $dpportarray)
        {
        if ($dport -in $apportarray)
        {
        $inapport += $dport
        }
        else
        {
        $notinapport += $dport
        }

        }
        if ($notinapport.Length -ne 0)
        {
        throw "Error | All required ports are not approved. Please work with Security Team to get these ports approved : $notinapport"

        }



    }
    catch {
        throw $_
    }
}