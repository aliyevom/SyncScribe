
Function Invoke-AzureEgressControllerApi {
    param(
        [string]$location,
        [string]$subscriptionId,
        [string]$hubSubscriptionId,
        [string]$sourceIpAddress,
        [string]$destinationAddresses,
        [string]$protocol,
        [string]$outboundPorts,
        [string[]]$appServicePorts,
        [string]$defaultBasePriority,
        [string]$defaultPriorityIncrement
    )
    #
    # API contants values needed for propoer execurions.
    #

    $newRuleCollection = "Rule Collection with name {RULECOLLECTIONNAME} does not exist."
    $https = '443'
    $http = '80'

    $destinationPorts = @($outboundPorts -split ',')
    $destinationPorts =$destinationPorts.Trim()
    $destinationAddress = @($destinationAddresses -split ',')
    $subMetaData = ((get-azsubscription | Where-Object { $_.SubscriptionId -eq $subscriptionId }).Name -split ('-') )
    
    
    $ruleCollectionName = [string]::Concat($subMetaData[1], '-', $subMetaData[2], '-collection-firewall-rule-', $subMetaData[-1]).ToLower()
    $ruleName = [string]::Concat($subMetaData[1], '-', $subMetaData[2], '-', $sourceIpAddress, '-', $protocol, '-', ($destinationPorts -join ('-')), '-rule').ToLower()
    $ipAddressParameters = @{
        subscriptionId  = $subscriptionId
        sourceIpAddress = $sourceIpAddress
        region          = $location
    }
    $destinationPortsParameters = @{
        destinationPorts = $destinationPorts
        appServicePorts  = $appServicePorts
    }
    #
    # Collection Type for Oubound either Network or Application
    # 443/80 as the request outbound ports, Application rule will be assumed.
    #
    try {       
        $app = $false
        $ruleCollectionType = "NetworkRuleCollections"
        $protocol = $protocol.ToUpper()
        if (Test-destinationPorts @destinationPortsParameters) {
            $ruleCollectionType = "ApplicationRuleCollections"
            $app = $true
        }
       
    
        $firewallRule = @{
            Name             = $ruleName 
            SourceAddress    = $sourceIpAddress
            Protocol         = if ($app){ ($destinationPorts ='https:443')}else{$protocol}
            DestinationPort  = $destinationPorts
            DestinationFqdns = $destinationAddress
            TargetFqdn       = $destinationAddress
                
        }
        #  TODO : status check prior updating new rule.
        #ProvisioningState   = Updating
        # 
        Write-Host ' Adding Firewall Rule'
        $firewallRule
        if ( (Test-ValidIpAddress @ipAddressParameters) ) {
            Set-AzContext $hubSubscriptionId 
            $azFireWall = (Get-AzFirewall)| Where-Object { $_.Location -eq ($location -replace (' ', '')) }
            Write-Host ' Firewall Current Config'
            $azFireWall
            if ($null -ne $azFireWall) {
                
                $collectionParameters = @{
                    azFireWall         = $azFireWall 
                    ruleCollectionType = $ruleCollectionType 
                    ruleCollectionName = $ruleCollectionName 
                }
    
                $ruleCollectionObject = Get-AzureFirewallRuleCollection @collectionParameters
                #
                #  The rule collection does not exist, Create new Application/Network Collection and add Rule
                #
                $newRruleSetParam = @{
                    azFireWall         = $azFireWall 
                    ruleCollectionName = $ruleCollectionName
                    ruleCollectionType = $ruleCollectionType 
                    firewallRule       = $firewallRule 
                }
                $addRuleSetParam = @{
                    azFireWall           = $azFireWall 
                    ruleCollectionObject = $ruleCollectionObject
                    ruleCollectionType   = $ruleCollectionType 
                    firewallRule         = $firewallRule 
                }
                if ($ruleCollectionObject -match $newRuleCollection.Replace('{RULECOLLECTIONNAME}', $ruleCollectionName)) {
                    
                    
                    $result = New-FirewallRuleSet @newRruleSetParam
                }
                #
                #  The rule collection exist, Update Application/Network Collection and add Rule
                #
                else {
                  
                    $result = Add-FirewallRuleSet @addRuleSetParam

                    if($result -like "Error*") {
                        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$result")
                        throw $result
                    }
                }
            }
            else {
                Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | Azure Firewall '$($azfirewallName)' does not exist.")
                throw "Error | Azure Firewall '$($azfirewallName)' does not exist."
            } 
        }
        else {
            Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "Error | Source IP '$($sourceIpAddress)' does not belong to ADT subscription $($subscriptionId).")
            throw "Error | Source IP '$($sourceIpAddress)' does not belong to ADT subscription $($subscriptionId)."
        }
        
    }
    catch {
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
        throw $_
    }
    $result   
}