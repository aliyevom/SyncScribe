<#
.DESCRIPTION
Automate Adding A records to Azure External DNS Zone with PowerShell.
#>

Function Invoke-externalDNSzones {
     param(
       [Parameter(Mandatory = $true)] [string] $dnsZoneName,
       [Parameter(Mandatory = $true)] [string] $dnsRecordAction,
       [Parameter(Mandatory = $true)] [string] $dnsRecordSetType,
       [Parameter(Mandatory = $true)] [string] $resourceName,
       [Parameter(Mandatory = $true)] [string] $recordValue
     ) 
   
     Install-Module -Name Az.Dns -force
     Import-Module Az.Dns
   
     $subscriptionId = "US-HUB-PROD-01"
     $resourceGroupName = "ng-prd-eus2-externaldns-rg"
   
     Set-AzContext -SubscriptionId $subscriptionId
     Write-Verbose "$subscriptionId" -Verbose      
   
     #to remove the dns zone name from the resource name
     if ($resourceName.Contains($dnsZoneName)) {
          $resourceName = $resourceName.Replace($dnsZoneName, "").TrimEnd('.')
          Write-Verbose  "Updated resource name: $resourceName" -Verbose
     } 

     try {
       if (($dnsRecordSetType -eq 'A') -and ($dnsRecordAction -eq 'create')) {
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -IPv4Address $recordValue)
       }
       if (($dnsRecordSetType -eq 'TXT') -and ($dnsRecordAction -eq 'create')) {
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -Value $recordValue)
       }
       if (($dnsRecordSetType -eq 'CNAME') -and ($dnsRecordAction -eq 'create')) {
   
             #Check of there is an existing name with the same name as the new cname
             $existingTxtRecord = Get-AzDnsRecordSet -Name $resourceName -RecordType 'TXT' -ResourceGroupName $resourceGroupName -ZoneName $dnsZoneName -ErrorAction SilentlyContinue
             if ($existingTxtRecord) {
               # If a TXT record exists, delete it
               Remove-AzDnsRecordSet -RecordSet $existingTxtRecord
             }
   
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -Cname $recordValue) -Confirm:$False -Overwrite
       }
       if (($dnsRecordSetType -eq 'A') -and ($dnsRecordAction -eq 'modify')) {
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -IPv4Address $recordValue) -Confirm:$False -Overwrite
       }
       if (($dnsRecordSetType -eq 'TXT') -and ($dnsRecordAction -eq 'modify')) {
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -Value $recordValue) -Confirm:$False -Overwrite
       }
       if (($dnsRecordSetType -eq 'CNAME') -and ($dnsRecordAction -eq 'modify')) {
   
             #Check of there is an existing name with the same name as the new cname
             $existingTxtRecord = Get-AzDnsRecordSet -Name $resourceName -RecordType 'TXT' -ResourceGroupName $resourceGroupName -ZoneName $dnsZoneName -ErrorAction SilentlyContinue
             if ($existingTxtRecord) {
               # If a TXT record exists, delete it
               Remove-AzDnsRecordSet -RecordSet $existingTxtRecord
             }
   
            $RecordSet = New-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -TTL 3600 -ZoneName $dnsZoneName -DnsRecords (New-AzDnsRecordConfig -Cname $recordValue) -Confirm:$False -Overwrite
        }
       if ($dnsRecordAction -eq 'delete') {
            $RecordSet = Get-AzDnsRecordSet -Name $resourceName -RecordType $dnsRecordSetType -ResourceGroupName $resourceGroupName -ZoneName $dnsZoneName
            Remove-AzDnsRecordSet -RecordSet $RecordSet
       }
   
     }
     catch {
       Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'errorThrow;issecret=false;isOutput=true', "$_")
       throw $_
     }
   }
   