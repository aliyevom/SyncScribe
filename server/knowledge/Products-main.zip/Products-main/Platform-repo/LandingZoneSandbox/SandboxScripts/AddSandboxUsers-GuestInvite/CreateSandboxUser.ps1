<#
.SYNOPSIS
Create Sandbox User through Invite rather than creating them

.DESCRIPTION
Create Sandbox User through Invite rather than creating them

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role


.EXAMPLE
 CreateSandboxUser.ps1' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ownerEmailAddress
)


$ErrorActionPreference = 'Stop'

try {

    $context = Get-AzContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureGraphToken = ConvertTo-SecureString $graphToken -AsPlainText -Force
    
 
    # Now connect to Microsoft Graph PowerShell by passing that token
    Connect-MgGraph -AccessToken $secureGraphToken
    
 
    Write-Verbose "Azure Graph connection successful" -Verbose

    
    
    $displayNamePeriod = $ownerEmailAddress.split("@")  

    $displayName = $displayNamePeriod[0].Replace(".", " ")
    $UPN = $displayNamePeriod[0] + "@ngridsandbox.onmicrosoft.com"
    $userAlreadyExists = $false
    if (!(Get-MgUser -Filter "userprincipalname eq '$UPN'")) {
        Write-Verbose "User could not be found. Sending invitation..." -Verbose

        $invitation = New-MgInvitation -InvitedUserEmailAddress $ownerEmailAddress `
            -SendInvitationMessage:$true `
            -InviteRedirectUrl "https://portal.azure.com/92aa0710-e517-4b0a-b087-51ce543f674c" `
            -InvitedUserDisplayName $displayName


        
     #   New-AzureADUser -DisplayName $displayName -PasswordProfile $PasswordProfile -UserPrincipalName $UPN -AccountEnabled $true -MailNickName $displayNamePeriod[0]
        Write-Verbose "Invitation sent to $ownerEmailAddress. Guest UPN: $($invitation.InvitedUserUserPrincipalName)" -Verbose
    }
    else {
        $RandomString = 'Guest user already exists'
        Write-Verbose "User was found. Not inviting user $displayName" -Verbose

        $userAlreadyExists = $true
        
    }

    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'userAlreadyExists', $userAlreadyExists)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'userAlreadyExists;issecret=false;isOutput=true', $userAlreadyExists)

    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'doesUserExist', $RandomString)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'doesUserExist;issecret=false;isOutput=true', $RandomString)
    


}
catch {
    throw  $_
}