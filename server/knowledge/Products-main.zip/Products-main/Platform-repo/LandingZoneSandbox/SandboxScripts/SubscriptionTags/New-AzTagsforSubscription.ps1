param
(
    [parameter(Mandatory = $true)]
    [String] 
    $invp,
    [parameter(Mandatory = $true)]
    [String]
    $owner,
    [parameter(Mandatory = $true)]
    [String]
    $bu,
    [parameter(Mandatory = $true)]
    [String]
    $bu1,
    [parameter(Mandatory = $true)]
    [String] 
    $costCenter,
    [parameter(Mandatory = $true)]
    [String] 
    $projectName,
    [parameter(Mandatory = $true)]
    [String] 
    $region,
    [parameter(Mandatory = $true)]
    [String]
    $environment,
    [parameter(Mandatory = $true)]
    [String]
    $applicationID,
    [parameter(Mandatory = $true)]
    [String]
    $companyCode,
    [parameter(Mandatory = $true)]
    [String]
    $financialOwner,
    [parameter(Mandatory = $true)]
    [String]
    $financialRTB,
    [parameter(Mandatory = $true)]
    [String]
    $workOrder,
    [parameter(Mandatory = $true)]
    [String]
    $opsCode,
    [parameter(Mandatory = $true)]
    [String]
    $wbsCode,
    [string]$scopeId ,
    [switch]$ScopeSubscription
)

$ErrorActionPreference = 'Stop'
try {
    if ($ScopeSubscription) {
        $ScopeSubscriptionId = (get-azsubscription -SubscriptionName $scopeId).SubscriptionId
        $scope = "/subscriptions/$ScopeSubscriptionId"
        
    }
    else {
        $scope = "/providers/Microsoft.Management/managementGroups/$scopeId"
    }
    if ($invp -like "INVP*") {
        Write-Verbose "TRUE, leaving invp alone" -Verbose
    }
    else {
        Write-Verbose "FALSE, doesn't contain INVP" -Verbose
        $invp = "BUSI"
    }
    if ($opsCode.equals('0000')) {
        Write-Verbose "Operations Code is empty" -Verbose
        $opsCode = " "
    }
    else {
        Write-Verbose "Operations Code is NOT empty, Resume" -Verbose
    }
    if ($applicationID.equals('99999')) {
        Write-Verbose "ApplicationID Code is empty" -Verbose
        $applicationID = " "
    }
    else {
        Write-Verbose "ApplicationID is NOT empty, Resume" -Verbose
    }
    if ($region -eq 'UK') {
        $tags = @{"Application ID" = $applicationID ; "Business Unit" = $bu ;"Business Unit 1" = "" ; "Company Code" = $companyCode ; "Cost Center" = $costCenter; "Environment" = "Non-Prod"; "Financial Owner" = $financialOwner ; "Financial RTB" = $financialRTB ; "WBS Code" = $wbsCode ; "Project Code" = $invp ; "Project Manager" = $owner ; "Project Name" = $projectName; "RTB Support" = $financialRTB ; "Service Owner" = $owner ; }
    }
    else {
        $tags = @{"Application ID" = $applicationID ; "Business Unit" = $bu ;"Business Unit 1" = "" ; "Company Code" = $companyCode ; "Cost Center" = $costCenter; "Environment" = "Non-Prod"; "Financial Owner" = $financialOwner ; "Financial RTB" = $financialRTB ; "Internal or Work Order" = $workOrder ; "Operations Code (WO)" = $opsCode ; "Project Code" = $invp ; "Project Manager" = $owner ; "Project Name" = $projectName; "RTB Support" = $financialRTB ; "Service Owner" = $owner ; }
    }

    New-AzTag -ResourceId $scope -Tag $tags

     

}
catch {
    throw $_
}
