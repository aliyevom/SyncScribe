<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ownerEmailAddress
)


$ErrorActionPreference = 'Stop'

try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose

    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable

    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString
    Enable-EntraAzureADAlias #enable aliasing

    $characters = (48..57) + (65..90) + (97..122)  
    $password_length = 10  
    $random = New-Object System.Random  
    $password = [char]$characters[$random.Next(0, $password_length)]

    # Use a foreach loop to add characters to the password
    try {

        1..($password_length - 1) | ForEach-Object {
            $char = $characters[$random.Next(0, $characters.Count)]  
            $password += [char]$char  
        }
        $RandomString = ($password.ToCharArray() | Sort-Object { Get-Random }) -join ''
        # Output the password that is generated
        Write-Output "Generated Password: $RandomString"
    }

    catch {
        throw  $_
    }
    
    $displayNamePeriod = $ownerEmailAddress.split("@")  

    $displayName = $displayNamePeriod[0].Replace(".", " ")
    $UPN = $displayNamePeriod[0] + "@ngridsandbox.onmicrosoft.com"

    if (!(Get-MgUser -Filter "userprincipalname eq '$UPN'")) {
        Write-Verbose "User could not be found. Creating user..." -Verbose

        $PasswordProfile = New-Object -TypeName Microsoft.Open.AzureAD.Model.PasswordProfile
        $PasswordProfile.Password = $RandomString
        Write-Verbose "Print Password $RandomString" -Verbose

        
        New-MgUser -DisplayName $displayName -PasswordProfile $PasswordProfile -UserPrincipalName $UPN -AccountEnabled $true -MailNickName $displayNamePeriod[0]
    }
    else {
        $RandomString = 'N/A-User already exists'
        Write-Verbose "User was found. Not creating a new user."
    }

    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'rbacAssignUser', $UPN)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'rbacAssignUser;issecret=false;isOutput=true', $UPN)

    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'userPassword', $RandomString)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'userPassword;issecret=false;isOutput=true', $RandomString)
    


}
catch {
    throw  $_
}