<#
.SYNOPSIS
Assign designated RBAC role to assigned subscription owner.

.DESCRIPTION
Assign designated RBAC role to assigned subscription owner.
The subscription owner would be assigned a designated Role at the subscription scope. The owner’s email address expected to be user’s sign in user principal.


.PARAMETER subscriptionName
Mandatory. Developers provisioned subscription to be assigned role.

.PARAMETER ownerEmailAddress
Mandatory. Developers email address to be granted designated role

.PARAMETER roleDefinitionName
Mandatory. The role assignment.

.EXAMPLE
 RoleAssignments.ps1' -subscriptionName 'US-Test-dev-01' -ownerEmailAddress 'me@srakabahotmail.onmicrosoft.com' -roleDefinitionName 'Reader'
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$subscriptionName,
    [string]$ownerEmailAddress,
    [string]$roleDefinitionName,
    [string]$region
)


$ErrorActionPreference = 'Stop'

$UpperSubscriptionName = $subscriptionName.ToUpper()

try {
    Write-Verbose "Checking for Azure Entra module..." -Verbose

    $AzModule = Get-Module -Name "Microsoft.Entra" -ListAvailable
    
    if ($AzModule -eq $null) {
        Write-Verbose "Azure Entra PowerShell module not found" -Verbose
        #Logging into Azure Entra
        Install-Module -Name "Microsoft.Entra" -Force
        Import-Module -Name "Microsoft.Entra" -Force
    }
    else {
        Import-Module -Name "Microsoft.Entra" -Force
    }
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $secureString = ConvertTo-SecureString -String $graphToken -AsPlainText -Force
    Connect-Entra -AccessToken $secureString
    Enable-EntraAzureADAlias #enable aliasing

    Get-EntraUser -Filter "mail eq '$ownerEmailAddress'"
    $adUser = Get-EntraUser -Filter "mail eq '$ownerEmailAddress'"
    $SPNAppId = $adUser.ObjectId
    Write-Verbose "ownerEmailAddress is $ownerEmailAddress" -Verbose
  }
catch {
    throw  $_
}

try {    
    
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'newOwnerEmailAddress', $userPrincipal)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'newOwnerEmailAddress;issecret=false;isOutput=true', $userPrincipal)

    Set-AzContext -SubscriptionName $subscriptionName -Verbose

    $ScopeSubscriptionId = (get-azsubscription -SubscriptionName $UpperSubscriptionName).SubscriptionId
    $scope = "/subscriptions/$ScopeSubscriptionId"

    New-AzRoleAssignment -ObjectId $SPNAppId -RoleDefinitionName $roleDefinitionName -Scope $scope
    Write-verbose  "Role assignment <$roleDefinitionName> for <$SPNAppId> created at scope $scope" -Verbose

}
catch {
    if ( $_.exception | Select-String "Operation returned an invalid status code 'Conflict'") {
        Write-Warning  "Duplicate role assignment detected. <$userPrincipal> is already a <$roleDefinitionName> at scope $scope"
    }
    else {
        throw  $_
    } 
}
