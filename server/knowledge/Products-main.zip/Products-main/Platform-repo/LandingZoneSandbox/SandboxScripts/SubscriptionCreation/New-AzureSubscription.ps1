param
(
    [parameter(Mandatory = $true)]
    [String] 
    $EnrollmentAccountObjectId,
    [parameter(Mandatory = $true)]
    [String]
    $OfferType,
    [parameter(Mandatory = $true)]
    [String]
    $SubscriptionName,
    [parameter(Mandatory = $true)]
    [String]
    $ManagementGroupId
)
# Capitalize Subscription Name
$UpperSubscriptionName = $SubscriptionName.ToUpper()


Install-Module -Name Az.Subscription -Scope CurrentUser -Force -RequiredVersion 0.9.0
# Import-Module -Name Az -Force
#Install-Module Az.Subscription -Scope CurrentUser -AllowPrerelease -Force -RequiredVersion 0.7.3

$subscription = Get-AzSubscription -SubscriptionName $UpperSubscriptionName -ErrorAction SilentlyContinue

try {
    if (-not $subscription) {
        if ($UpperSubscriptionName -like "*-UK-*") {
            $ManagementGroupId = $ManagementGroupId.Replace("US", "UK")
        } 

        $BillingScope = '/providers/Microsoft.Billing/billingAccounts/87159241/enrollmentAccounts/124938'

        Write-Verbose "STARTING SUBSCRIPTION PROCESS" -Verbose
        $subscription = New-AzSubscriptionAlias -AliasName $UpperSubscriptionName -SubscriptionName $UpperSubscriptionName -BillingScope $BillingScope -Workload DevTest

        # PRINT SUBSCRIPTION
        Write-Verbose "PRINT THE SUBSCRIPTION $subscription" -Verbose
        #Delay for Bug #43295 in ADO
        Start-Sleep -Seconds 30
        Write-Verbose "AFTER SLEEP" -Verbose
        $subscriptionName = (Get-AzSubscription -SubscriptionName $UpperSubscriptionName).Id

        Write-Verbose "Subscription post: $subscriptionName" -Verbose
        # move subscription under a management group
        New-AzManagementGroupSubscription -GroupId $ManagementGroupId -SubscriptionId $subscriptionName
        Write-Verbose "AFTER MOVE" -Verbose
    }
    else {
        Write-Warning "Subscription $subscription is already deployed" -Verbose
        $subscriptionDeployed = $true
        Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'subscriptionDeployed', $subscriptionDeployed)
        Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'subscriptionDeployed;issecret=false;isOutput=true', $subscriptionDeployed)
    }

    $subscriptionId = (Get-AzSubscription -SubscriptionName $UpperSubscriptionName -ErrorAction SilentlyContinue).Id
    Write-Host ("Publishing variable [{0}] with value [{1}] to pipeline environment" -f 'newSubscriptionID', $subscriptionId)
    Write-Host ("##vso[task.setvariable variable={0}]{1}" -f 'newSubscriptionID;issecret=false;isOutput=true', $subscriptionId)
}
catch {
    throw $_
}


return $subscription