# PaloAltoNetworks

This ARM template deploys a VM-Series next generation firewall VM in an Azure resource group.

## Resource types

|Resource Type|ApiVersion|
|:--|:--|
