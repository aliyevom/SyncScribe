# Budget

 "itemDisplayName": "Create a Budget",
  "description": "This template shows how to create a budget under a subscription.",
  "summary": "This template creates a budget to track cost or usage and get notified whenever a specified threshold is met. There are multiple notification thresholds that are available to configure.",

## Resource types

|Resource Type|Api Version|
|:--|:--|
|`Microsoft.Consumption/budgets` | 2019-10-01 |
|`Microsoft.Resources/deployments`| 2019-10-01 |

## Parameters

| Parameter Name | Type | Default Value | Possible values | Description |
|---|---|---|---|---|

Important note about parameters

Budget Name: Name of the budget. It should be unique within the resource group.
Amount: The total amount of cost or usage to track with the budget. Any decimal value is allowed.
Time Grain: The time covered by a budget. Tracking of the amount will be reset based on the time grain. Allowed values are: Monthly, Quarterly, Annually.
Start Date: The start date must be first of the month in YYYY-MM-DD format and should be less than the end date. Budget start date must be on or after June 1, 2017. Future start date shouldn't be more than three months. Past start date should be selected within the Time Grain period.
End Date: Any date after the start date in in YYYY-MM-DD format.
First Threshold: It's the first threshold value associated with a notification. Notification is sent when the cost exceeded the threshold. It's always percent and has to be between 0 and 1000.
Second Threshold: It's the second threshold value associated with a notification. Notification is sent when the cost exceeded the threshold. It's always percent and has to be between 0 and 1000.
Contact Emails: The list of email addresses to send the budget notification to when the threshold is exceeded. It accepts array of strings.
Owner's Email: Owner's email address to send the budget notification to when the threshold is exceeded. It accepts array of strings.
Contact Groups: The list of action groups to send the budget notification to when the threshold is exceeded. It accepts array of strings.
Resource Groups Filter: The list of filters on resource groups. It accepts array of strings.
Meter Categories Filter: The list of filters on meters. It accepts array of strings.
<https://github.com/Azure/azure-quickstart-templates/tree/master/quickstarts/microsoft.consumption/create-budget>
