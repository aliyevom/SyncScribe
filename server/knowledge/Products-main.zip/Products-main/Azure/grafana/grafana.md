# 13. Azure Managed Grafana dashboard


* <span style="color:yellow"><i>Creates Azure managed grafana.</i></span>
 
<br>

*******************************

*******************************

## GitHub Workflow Fields/Parameters

|	Field Name	|	Parameter Name	|	Type	|	Default Value	|	Values Supported	|	Required	|	Rules/Conditions	|
|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|
|	Request Type	|	RequestType	|	Dropdown	|	Create (With new RG)	|	Create (With new RG), Create (with existing RG)  	|	$${\color{Red}Yes}$$ 	|		|
|	Location	|	Location	|	Dropdown	|	eastus2	|	eastus2, centralus,uksouth,ukwest	|	$${\color{Red}Yes}$$ 	|	Choose the right location for the AI services you are deploying. Not all services are available in all regions	|
|	environment	|	environment	|	Dropdown	|	dev	|	dev,qa,uat,prod	|	$${\color{Red}Yes}$$ 	|		|
|	purpose	|	purpose	|	text	|	empty	|	purpose for your app (3-4) chars	|	$${\color{Red}Yes}$$ 	|		|
|	Existing RG name	|	Rgname	|	text	|	empty	|	Any existing RG name	|	$${\color{yellow}optional}$$ 	|	This is optional if you are selected create with new RG option	|
|	Subnet Name for PE	|	subtnet_name	|	text	|	empty	|	subnet name in the respective region/location	|	$${\color{Red}Yes}$$ 	|		|
|	Grafana Admin user email	|	username	|	text	|	empty	|	Specify NG email id of the user who needs to be setup as grafana admin.	|	$${\color{yellow}No}$$ 	|	If you are already a grafana admin, you can leave this field blank.	|



# known issues

* <span style="color:yellow"><i>If you specify user email that already have grafana admin access, pipeline will fail during role assignment. Grafana instance will be created.</i></span>