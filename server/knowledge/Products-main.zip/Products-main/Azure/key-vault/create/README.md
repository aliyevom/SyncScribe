# Key Vault

    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.

Understanding GitHub Workflow Variables for Key Vault:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Create (with New RG) to create new Key Vault with new Resource Group. Create (with Existing RG) to create new Key Vault with an existing Resource Group.   |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Resource Name     | Specify the purpose to use for Function App Name and Storage Account Name. Max 3-5 Char. Ex- abc, abc01.. (the format purpose.sequence is not permitted for this resource).                                                                                                                                    |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc, abc01, abc.01..                                                                                                                                                                                       |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Key Vault Name  | Specify the purpose to use for Key Vault Name. Max 1-3 Char. Ex- abc, abc01                                                                                                                                                                   |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            SKU for Key Vault            | Select the SKU for Key Vault.                                                                                                                                                                                                       | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Subnet Name for Service Endpoint            | Specify Subnet Name to enable Service Endpoint.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           List of IPV4 Addresses to allow through Networking.            | List of IPV4 IP Addresses comma separated.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |

## Key Vault Access Policies

Please refer to the Readme.md within the [key-vault/update/access-policy module](/Azure/key-vault/update/access-policy/README.md) for documentation on Key Vault Access Policy.

## Key Vault Certificates

Please refer to the Readme.md within the [key-vault/create/certificates module](/Azure/key-vault/create/certificates/README.md) for documentation on Key Vault Certificates.

## Key Vault Keys

Please refer to the Readme.md within the [key-vault/create/keys module](/Azure/key-vault/create/keys/README.md) for documentation on Key Vault Keys.