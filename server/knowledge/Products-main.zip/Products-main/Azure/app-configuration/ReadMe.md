# Application Configuration Documentation

## Table of Contents

- [Requesting an Application Configuration Resource](#requesting-an-application-configuration-resource)
- [Application Configuration - Quickstart](#application-configuration---quick-start)
- [GA UI Arguments](#ga-ui-arguments)
- [CSV File Arguments](#csv-file-arguments)

## Requesting an Application Configuration Resource

![Request App Config Resource](<../../images/Application Configuration/App Configuration - GA UI.png>)

## [Application Configuration - Quick Start](https://nationalgridplc.sharepoint.com/:b:/r/sites/COMMS-INT-GLOBAL-PlatformsAndCloud/Wisdom/Shared%20Documents/Technical%20Documentation/Terraform/Application%20Configuration/Application%20Configuration%20-%20Quick%20Start.pdf?csf=1&web=1&e=Wzobn6)

## GA UI Arguments

| Display Name                        | Discussion                                                                                                        | CSV File Column              | Default Value                    | Required |
|-------------------------------------|-------------------------------------------------------------------------------------------------------------------|------------------------------|---------------------------------------|---------------------|
| Request Type - Create (New RG)      |  The resource group will be created using the purpose indicated below.                                            |  GA UI Only                  | None                                  | Yes                 |
| Request Type - Create (Existing RG) | When specifying a Resource Name, instead of purpose, the existing Resource Group must use the Resource’s purpose. |  GA UI Only                  | None                                  | Yes                 |
| Environment                         | Options: Dev, FOF, QA, UAT, Prod                                                                                  |  GA UI Only                  | None                                  | Yes                 |
| Deployment Location                 | Options: eastus2, uksouth, centralus, ukwest                                                                      | location                     | None                                  | Yes                 |
| Resource Name                       | Use hyphen notation to provide your own name.                                                                     | purpose                      | None                                  | Yes                 |
| Subset name for private endpoint    |                                                                                                                   | subnet_name_private_endpoint | None                                  | Yes                 |
| Feature Names                       |                                                                                                                   | app_config_feature_names     | None                                  | No                  |
| Key Data                            |                                                                                                                   | app_config_key_data          | None                                  | No                  |
| Has a Key Vault been Associated     |                                                                                                                   | key_vault_provisioning       | Previously Associated or Not Required | Yes                 |
| Key Vault Name                      | Indicate the Key Vault used.                                                                                      | key_vault_name               | None                                  | No                  |
| Key Vault Resource Group            | Indicate the Resource Group for the Key Vault                                                                     | key_vault_rg                 | None                                  | No                  |

## CSV File Arguments

| Display Name               | Discussion                                                                                                         | CSV File Column            | Default Value (ACF) | Required <br/>(ACF)                                              |
|----------------------------|--------------------------------------------------------------------------------------------------------------------|----------------------------|---------------------|------------------------------------------------------------------|
| app_config_rsa_key_size    | Specifies the Size of the RSA key to create in bytes. For example.                                                 | app_config_rsa_key_size    | 2048                |  This field is required if key_vault_key_type is RSA or RSA-HSM. |
| feature_description        | The description of the App Configuration Feature.                                                                  | feature_description        | ""                  | .                                                                |
| feature_enabled            | The status of the App Configuration Feature.                                                                       | feature_enabled            | true                | .                                                                |
| feature_key                | The key of the App Configuration Feature. The value for name will be used if this is unspecified.                  | feature_key                | ""                  | .                                                                |
| feature_label              | The label of the App Configuration Feature.                                                                        | feature_label              | """"                | .                                                                |
| feature_locked             | Should this App Configuration Feature be Locked to prevent changes?                                                | feature_locked             | false               | .                                                                |
| key_expiration_date        | Expiration UTC datetime (YYYYY-MM-DDTHH:MM:SSZ) format with time zone offset instead of Z.                         | key_expiration_date        | ""                  | .                                                                |
| key_label                  | The label of the App Configuration Key.                                                                            | key_label                  | ""                  | .                                                                |
| key_not_before_date        | Key not usable before the provided UTC datetime (YYYYY-MM-DDTHH:MM:SSZ) format with time zone offset instead of Z. | key_not_before_date        | ""                  | .                                                                |
| key_vault_key_type         | The Key Type to use for this Key Vault Key. Possible values are EC (Elliptic Curve), EC-HSM, RSA and RSA-HSM.      | key_vault_key_type         | RSA                 | .                                                                |
| local_auth_enabled         | Whether local authentication methods is enabled. Once enabled cannot be disabled.                                  | local_auth_enabled         | true                | .                                                                |
| lock_keys                  | Should this App Configuration Key be Locked to prevent changes?                                                    | lock_keys                  | false               | .                                                                |
| purge_protection_enabled   | Whether Purge Protection is enabled.                                                                               | purge_protection_enabled   | false               | .                                                                |
| soft_delete_retention_days | Number between 1 and 7, if invalid entry default is used.                                                          | soft_delete_retention_days | 7                   | ,                                                                |
