# Databricks Workspace Workflow

 
Understanding GitHub Workflow Variables for Databricks Workspace:

|Field Name|Parameter Name|Type|Default Value|Values Supported|Required|Rules/Conditions|
| :------------------------------: | :------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |
|           Request Type            | N/A|Dropdown| N/A | Create (with New RG). Create (with Existing RG)  |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
|             Location             | location | Dropdown | N/A | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{red}yes}$$ | $${\color{red}supported values - eastus2, centralus, uksouth, ukwest}$$ |
Environment |           environment            | Dropdown| N/A |Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Purpose for Resource Group Name [3-5 char]|    purpose_rg     | Input | N/A |Purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc, abc01                                                                                                                                    |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Purpose for Databricks Name [3-5 char ONLY] | purpose | Input | N/A| Specify the purpose to use for Resource Name. Max 3-5 Char. Ex- abc, abc01                                                                                                                                                                               |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Name for Cluster, leave blank if not needed|            cluster_name            | Input | N/A | Specify name to use for cluster                                                                                                                                                                                                           | $${\color{green}no}$$ | $${\color{grey}N/A}$$ |
Subnet Name for Private IP |          private_subnet_name          | Input | N/A | Specify name of un-delegated and free subnet. The subnet must not be used by any other resource.                                       |   $${\color{red}yes}$$    | $${\color{red}Undelegated   -and -free-subnet-only }$$ |
Subnet Name for Public IP |          public_subnet_name          | Input | N/A | Specify name of un-delegated and free subnet. The subnet must not be used by any other resource.                                       |   $${\color{red}yes}$$    | $${\color{red}Undelegated   -and -free-subnet-only }$$ |
|           Subnet Name for Private Endpoint            | subnet_name_private_endpoint|Dropdown| N/A | Specify name of un-delegated subnet  |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |

## Databricks Workspace

Please refer to the Readme.md within the [databricks workspace module](/Azure/databricks/workspace/README.md) for documentation on Databricks Workspace.
