# Databricks Cluster Workflow

 
Understanding GitHub Workflow Variables for Databricks Cluster:

|Field Name|Parameter Name|Type|Default Value|Values Supported|Required|Rules/Conditions|
| :------------------------------: | :------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |
|             Location             | location | Dropdown | N/A | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{red}yes}$$ | $${\color{red}supported values - eastus2, centralus, uksouth, ukwest}$$ |
Environment |           environment            | Dropdown| N/A |Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Purpose for Resource Group Name [3-5 char]|    purpose_rg     | Input | N/A |Purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc, abc01                                                                                                                                    |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Purpose for Databricks Name [3-5 char ONLY] | purpose | Input | N/A| Specify the purpose used for Resource Name. Must be existing resource. Max 3-5 Char. Ex- abc, abc01                                                                                                                                                                               |  $${\color{red}yes}$$   | $${\color{grey}N/A}$$ |
Name for Cluster|            cluster_name            | Input | N/A | Specify name to use for cluster                                                                                                                                                                                                           | $${\color{red}yes}$$ | $${\color{grey}N/A}$$ |
