# Logic App

    Pre-Requisites:  
     1. Log Analytics Workspace must exist prior to deploying Standard Logic App.
    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
     3. Log Analytics Workspace must exist prior to deploying Standard Logic App.

Understanding GitHub Workflow Variables for Logic App:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Create (with New RG and Storage Account) to create new Logic App with new Resource Group and Storage Account. Create (with Existing RG and Storage Account) to create new Logic App with an existing Resource Group and Storage Account. Create (with Existing RG and New Storage Account) to create new Logic App with an existing Resource Group and new Storage Account. Select Update to modify or change existing Logic App. Select Remove to delete Logic App. Update and Remove requestTypes are not yet available.  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc                                                                                                                                             |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Logic App Name  | Specify the Name abiding by naming convention or purpose.sequence to use for Logic App Name. Max 3-5 Char. Ex- abc.01                                                                                                                                                |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Storage Account Name  | Specify the Name abiding by naming convention or purpose.sequence format to use for Storage Account Name. Max 3-5 Char. Ex- abc.01. Value greater than 9 will be considered a full name.                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            Log Analytics Workspace            | Name of Log Analytics Workspace and Name of RG that stores the workspace (colon separated) to integrate with App Insights Resource.                                                                                                                                                                                                           | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|            SKU for App Service Plan            | Select the SKU for App Service Plan.                                                                                                                                                                                                       | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Subnet Name for VNET Integration            | Specify Subnet Name to enable VNET Integration.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
## Standard Logic App

Please refer to the Readme.md within the [logic-app standard module](/Azure/logic-app/standard/README.md) for documentation on Standard Logic App.

## Consumption Logic App
Please refer to the Readme.md within the [logic-app consumption module](/Azure/logic-app/consumption/README.md) for documentation on Consumption Logic App.

## Migrate Consumption Logic App Workflow
Please refer to the Readme.md within the [logic-app migrate workflow module](/Azure/logic-app/migrate-workflow/README.md) for documentation on Migrating Consumption Logic App Workflows.