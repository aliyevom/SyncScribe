# Migrate Consumption Logic App Workflows

    This workflow is specifically designed to migrate Consumption Logic App Workflows.
     
    Please keep in mind, certain connectors like Email and Sharepoint will require re-authentication and setup within the New Workflow once migrated. 
    This is because the workflow definition does not store login credentials.

    Throughout this workflow 'Source' is designated as the Logic App to Migrate the Workflow FROM. 
    
    Whereas, 'Destination' is designated as the Logic App to Migrate the Workflow TO. 

Understanding GitHub Workflow Variables for Migrating Workflow:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           Environment of Source Logic App            | Select the environment of the Logic App to Migrate Workflows From.  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             Name of Source Logic App             | Specify Name of Logic App to Migrate Workflows From.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           Resource Group Name of Source Logic App            | Specify Resource Group Name of Logic App to Migrate Workflows From.                                                                                                                                                                                                                                      |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Environment of Destination Logic App            | Select the environment of the Logic App to Migrate Workflows TO.  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             Name of Destination Logic App             | Specify Name of Logic App to Migrate Workflows TO.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           Resource Group Name of Destination Logic App            | Specify Resource Group Name of Logic App to Migrate Workflows TO.                                                                                                                                                                                                                                      |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |

# Known Limitations
