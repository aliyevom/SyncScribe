# Logic App - Consumption

    The following are all the supported parameters for Logic App - Consumption Product.

    When using a CSV file for parameter specification:
    1. The value in the CSV file takes precedence over GitHub UI
    2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.

For details on supported values for the parameters please visit -
[Logic App - Consumption Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/logic_app_workflow)

|        Parameter name        | Description                                                                                                                                                                                                                                  |                  Default Value                   |  Required             |                Naming Standard                 |
| :--------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------: | :-------------------: | :--------------------------------------------: |
|          allowed_caller_ip_address           | List of comma delimited IP addresses to allow                                                                                                                                                                                                      |             $${\color{grey}N/A}$$             | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|       enabled       | Set to disable workflow.                                                                                                                                                                                                           |              $${\color{green}true}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|   integration_account_id   | The ID of the integration account linked by this Logic App Workflow.                                                                                                                         |              $${\color{grey}N/A}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|   integration_svc_env_id   | The ID of the Integration Service Environment to which this Logic App Workflow belongs. Changing this forces a new Logic App Workflow to be created.                                                                                                        | $${\color{grey}N/A}$$ | $${\color{green}No}$$ | $${\color{grey}N/A}$$ |
|     open_auth_claim_name     | The name of the OAuth policy claim for the Logic App Workflow.                                                                                                                                      |              $${\color{grey}N/A}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|     open_auth_claim_value     | The value of the OAuth policy claim for the Logic App Workflow.                                                                                                                                            |              $${\color{grey}N/A}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|     open_auth_policy_name     | The OAuth policy name for the Logic App Workflow.                                                                                                                                       |              $${\color{grey}N/A}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |
|        workflow_schema        | Specifies the Schema to use for this Logic App Workflow. Defaults to https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#. Changing this forces a new resource to be created.                                 |             $${\color{grey}N/A}$$              | $${\color{green}No}$$ |  $${\color{grey}N/A}$$                         |
|     workflow_version     | Specifies the version of the Schema used for this Logic App Workflow. Defaults to 1.0.0.0. Changing this forces a new resource to be created.                                                                                                                                           |              $${\color{grey}N/A}$$               | $${\color{green}No}$$ |             $${\color{grey}N/A}$$              |

# Known Limitations

