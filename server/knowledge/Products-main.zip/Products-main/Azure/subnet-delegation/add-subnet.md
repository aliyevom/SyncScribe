# Deploy Subnet

     
Understanding GitHub Workflow Variables for Deploy-Subnet:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|             location             | Select location of resource deployment.| $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.|   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Subnet Name     | Specify the purpose to use for Subnet Name. Max 3-5 Char. Ex- abc |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            subnetSize            | Select Size for new Subnet. Small = 11 IP addresses. Medium = 27 IP addresses. Large  = 59 IP addresses.| $${\color{grey}small}$$ | $${\color{red}yes}$$ |
|          adtEmailAddress          | Specify ADT Email Address. Specify email as 'first.last@nationalgrid.com'. NO '@uk.' or '@us.' in Domain |   $${\color{grey}N/A}$$    | $${\color{red}yes}$$ |