# Web PubSub Service

<p> Manage WebSocket connections </p>
<br>
Note: By default public access is disabled. If Free_F1 tier is utilized then enable public access through azure portal
<br>
## GitHub Workflow Fields/Parameters
<br>
|:-------------------------------------------------------------------------------------------------------------------------------------------------------|
|Field Name 	      |Parameter Name  |Type 	 |Default Value    |Values Supported   |Required   |Rules/Conditions       |Comment                      |
|:--------------------|:---------------|:--------|:----------------|:------------------|:----------|:----------------------|:----------------------------| 
|Subscription Name    |subscription    |Text     |                 |                   |true       |                       |                             |      
|Request Type         |RequestType     |DropDown |create           |create             |true       |                       |                             |
|                     |                |         |                 |update             |           |                       |                             |
|                     |                |         |                 |Delete             |           |                       |                             |
|Location             |location        |DropDown |eastus2          |eastus2            |true       |                       |                             |
|                     |                |         |                 |centralus          |           |                       |                             |
|Environment          |environment     |DropDown |dev              |dev                |true       |                       |                             |
|                     |                |         |                 |qa                 |           |                       |                             | 
|                     |                |         |                 |uat                |           |                       |                             |
|                     |                |         |                 |prod               |           |                       |                             |
|Purpose              |purpose         |Text     |                 |3-5 charcters      |true       |                       |                             |  
|Sku Tier             |sku_tier        |DropDown |Free_F1          |Free_F1            |true       |                       |                             |
|                     |                |         |                 |Standard_S1        |           |                       |                             |
|                     |                |         |                 |Premium_P1         |           |                       |                             |
|Sku Capacity         |sku_capacity    |Number   |                 |1-1000 connections |true       |                       |                             |
|Subnet Name          |subnetname      |Text     |                 |                   |false      |If Sku Tier is not     |Private End Point is         |
|                     |                |         |                 |                   |           |Free_F1 then specify   |created if and only if       |
|                     |                |         |                 |                   |           |subnetname for private |Sku tier is not Free_F1      |
|                     |                |         |                 |                   |           |end point              |and subnet name is specified |
|Create Resource Group|ResourceGroup   |DropDown |Yes              |Yes                |true       |                       |                             |
|                     |                |         |                 |No                 |           |                       |                             |
|Resource Group Name  |RGname          |Text     |                 |                   |false      |If Create RG is set    |                             |
|                     |                |         |                 |                   |           |to 'No', specify name. |                             |
|:-------------------------------------------------------------------------------------------------------------------------------------------------------|
<br>
Look up the following URL for open source examples on how to utilize Web PubSub services
https://github.com/Azure/azure-webpubsub?tab=readme-ov-file