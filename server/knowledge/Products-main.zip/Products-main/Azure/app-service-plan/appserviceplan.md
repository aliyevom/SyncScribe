# 7. App Service Plan in V3

<P> This pipeline helps to create/manage app service plan within 3rd Generation (v3) App Service Environment and chooses the same Resource Group as asev3</p>
<br>

* <span style="color:yellow"><i>It requires existing ASEv3 within the subscription</i></span>

<br>

## GitHub Workflow Fields/Parameters

|	 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Request Type	|	RequestType	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Purpose	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Specify the Name of the Existing ASE V3	|	app_service_environment_v3		Text	|	Empty	|	names of asev3	|	$${\color{Red}Yes}$$ 	|	Default is "YES". Please change value to "No" if RG creation is not needed.	|
|	Specify the RG name of existing ASE V3 	|	asev3_Rgname	|	Text	|	Empty	|	Enter the RG name of existing asev3	|	$${\color{Red}Yes}$$ 	|		|
|	Specify existing RG name if Plan should exist in different RG than v3	|	Rgname	|	text	|	Empty	|	RG name	|	$${\color{Orange}Optional}$$ 	|		|
|	Choose O/S type for the App Services to be hosted	|	os_type	|	Dropdown	|	Windows	|	Windows,Linux,WindowsContainer	|	$${\color{Red}Yes}$$ 	|		|
|	Choose O/S type for the App Services to be Select Sku_name for app service plan	|	sku_name	|	Dropdown	|	I1v2	|	I1v2,I2v2,I3v2	|	$${\color{Red}Yes}$$ 	|		|