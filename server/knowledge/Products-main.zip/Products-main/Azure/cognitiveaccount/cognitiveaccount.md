#  Azure cognitive account deployment

<i>This Code deploys the Cognitive services supported by Microsoft Azure. Following services are supported currently </i>
    <br> 
 *   <span style="color:#ffa500"><b> TextTranslation.</b>   </span>
 *   <span style="color:#ffa500"><b> SpeechServices</b>   </span>
 *   <span style="color:#ffa500"><b> TextAnalytics</b>   </span>
 *   <span style="color:#ffa500"><b> Azure Search</b>   </span> 
 <br>
<span style="color:red"><b>Note:</b> <p> Currently Text analytics can be deployed <b style="color:green"> <i> Only by Integrating with Azure Search.</i> </b> Please make sure you have Azure search deployed as a pre-requisite for deplyoing language service/TextAnalytics.  </span>


Please refer to Microsoft documentation [HERE](https://azure.microsoft.com/en-us/explore/global-infrastructure/products-by-region/?products=cognitive-services) to understand what services are supported in what regions
<br>

*******************************

## GitHub Workflow Fields/Parameters
|	Field Name	|	Parameter Name	|	Type	|	Default Value	|	Values Supported	|	Required	|	Rules/Conditions	|
|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|
|	Request Type	|	RequestType	|	Dropdown	|	Create (With new RG)	|	Create (With new RG), Create (with existing RG)  	|	$${\color{Red}Yes}$$ 	|		|
|	Location	|	Location	|	Dropdown	|	eastus2	|	eastus2, centralus,uksouth,ukwest	|	$${\color{Red}Yes}$$ 	|	Choose the right location for the AI services you are deploying. Not all services are available in all regions	|
|	environment	|	environment	|	Dropdown	|	dev	|	dev,qa,uat,prod	|	$${\color{Red}Yes}$$ 	|		|
|	purpose	|	purpose	|	text	|	empty	|	purpose for your app (3-4) chars	|	$${\color{Red}Yes}$$ 	|		|
|	Existing RG name	|	Rgname	|	text	|	empty	|	Any existing RG name	|	$${\color{yellow}optional}$$ 	|	This is optional if you are selected create with new RG option	|
|	Type of Cognitive Service	|	kind	|	Dropdown	|	TextTranslation	|	TextTranslation,SpeechServices,Search,TextAnalytics	|	$${\color{Red}Yes}$$ 	|	Note: If TextAnalytics is selected, it is required to integrate with Azure Search. Please make sure Azure Search is created before deploying  textAnalytics	|
|	SKU name selection	|	sku_name	|	Dropdown	|	F0	|	"F0,F1,S0,S,S1,S2,S3,S4,S5,S6,P0,P1,P2,E0,DC0,standard, basic,free,standard,basic,free,standard2,standard3,storage_optimized_l,storage_optimized_l2	|	$${\color{Red}Yes}$$ 	|	Note: Not every Cognitive service supports all the sku's. Please select SKU name based on the service you are choosing. Refer to MS documentation for supported sku's for different AI services.	|
|	Subnet Name for PE	|	subtnet_name	|	text	|	empty	|	subnet name in the respective region/location	|	$${\color{Red}Yes}$$ 	|		|
|	Specify azure search service name and RG in (searchName:RGname) format(Only if type is TextAnalytics)	|	azure_search	|	text	|	empty	|	text field	|	$${\color{yellow}optional}$$ 	|	If you are deplying TextAnalytics/Language service, please make sure Azure search is created as a pre-requisite.	|
|	Specify the github secret that stores Search api key(Only if type is TextAnalytics)	|	Azure_search_key	|	text	|	AZURE_SEARCH_KEY	|	AZURE_SEARCH_KEY	|	$${\color{yellow}optional}$$ 	|	Please create a github secret AZURE_SEARCH_KEY as name and specify azure search key. This secret should be created per environment under the github environments section. This only applies to TextAnalytics service.	|
|		|		|		|		|		|		|		|