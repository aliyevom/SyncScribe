# Event Hub Module

## Overview

*This module enables the consistent and secure deployment of Azure Event Hub and all necessary supporting resources. It enforces organizational standards for naming, security, and networking, ensuring that every Event Hub environment is robust, compliant, and ready for enterprise workloads.* [Compare Azure Event Hubs tiers][1]

[1]: https://learn.microsoft.com/en-us/azure/event-hubs/compare-tiers


## Naming Convention Pattern Used

### Naming Format

```
<region><bu>-<environment>-<location_abbreviation>-<purpose>-ehns-ns
<region><bu>-<environment>-<location_abbreviation>-<purpose>-evh-<nn>
```

### Parameters

* `local.naming.region` – e.g., `us`
* `local.naming.bu` – e.g., `5874`
* `local.naming.environment` – e.g., `dev`
* `local.naming_map.location_abbreviation[unique_id].location_abbreviation` – e.g., `eus2`
* `local.naming_map.purpose[unique_id].purpose` – e.g., `test01`
* Suffixes:

  * `-ehns-ns` for namespace
  * `-evh-<nn>` for event hub instance

### Example Output

* Namespace: `us5874-dev-eus2-test01-ehns-ns`
* Event Hub: `us5874-dev-eus2-test01-evh-1`

---

# UI Workflow Guidelines
## Name of Primary Event Hub or Specify Purpose (5–6 Character Format)

### Allowed Characters

* Only letters (a-z, A-Z) and numbers (0-9)

### Not Allowed

* Spaces, dots (`.`), commas (`,`), apostrophes (`'`), dashes (`-`), or other special characters

**Examples:**

* Valid: `test01`
* Invalid: `test.01`, `test-01`

> Note: An Azure Policy enforces strict naming rules for Event Hub namespaces.
 
 
## Available SKUs for Azure Event Hub

| SKU      | Description                                       | Features                                                           |
| -------- | ------------------------------------------------- | ------------------------------------------------------------------ |
| Standard | Common for production workloads                   | 7-day message retention, throughput units, auto-inflate, capture.   |
| Premium  | For high-throughput or mission-critical workloads | 90-day retention, dedicated resources, advanced networking. |

> The **Basic** SKU is not available due to limited capabilities.

 
## Subnet Name Field

* **Private Endpoint Subnet:**
  Subnet where a private IP is created for secure access within your VNet.

> Only the Private Endpoint subnet is required. Service Endpoint subnet is no longer needed or collected by the workflow.


## Select Additional Services to Deploy

### Options

* **EventHub**
  Deploys the Event Hub resource, including namespace, event hub, and related networking.

* **None**
  Skips creation of Event Hub resources. Used when only updating network configurations or infrastructure.


## Service Deployment Summary

| Option   | Description                                                       |
| -------- | ----------------------------------------------------------------- |
| EventHub | Deploys or updates the Event Hub and associated infrastructure    |
| None     | Only updates networking and infrastructure, no Event Hub deployed |


## Select Capacity

Sets the number of **Throughput Units (Standard)** or **Capacity Units (Premium)**.

### Examples

* `1` – Default for dev/test or low volume
* `2, 4, 8, 16` – Higher throughput for production workloads


 