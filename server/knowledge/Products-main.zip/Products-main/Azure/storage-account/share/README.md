# Storage Share

    The following are the supported parameters for Storage Share Module.

    Supports GitHub UI only.

For details on supported values for the parameters please visit -
[Storage Share Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share)

|   Parameter name   | Description                                                                                                                                                  | Default Value |  Required             |                                     Naming standard                                     |
| :----------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------- | :-----------: | :-------------------: | :-------------------------------------------------------------------------------------: |
| storageAccountName | Storage Account Name                                                                                                                                         |               | $${\color{red}Yes}$$  | $${\color{red}buevregionpurposest }$$ or $${\color{red}buevregionpurpose.sequencest }$$ |
|   containerName    | Container Name                                                                                                                                               |               | $${\color{green}No}$$ |                                  $${\color{grey}NA }$$                                  |
|      blobName      | Blob Name                                                                                                                                                    |               | $${\color{green}No}$$ |                                  $${\color{grey}NA }$$                                  |
|  blobUploadSource  | Add your source file within the staging folder in Products Repo. Specify "../staging/filename" in the csv file, replace filename with the name of your file. |               | $${\color{green}No}$$ |                                  $${\color{grey}NA }$$                                  |
|     queueName      | Queue Name                                                                                                                                                   |               | $${\color{green}No}$$ |                                  $${\color{grey}NA }$$                                  |
|   fileshareName    | Fileshare Name                                                                                                                                               |               | $${\color{red}Yes}$$  |                                  $${\color{grey}NA }$$                                  |

# Known Limitations

July 2023

1. When Networking is set to "Selected Networks", use NG Hosted Agent when adding a blob, container, queue, table or fileshare to an existing Storage Account in GitHub. Currently, the Cloud Platform Engineering Team do not have NG Hosted Agents within GitHub. Application Delivery Teams are encouraged to create/use their own NG Hosted agents.

2. The GitHub UI currently supports specification of only one queue_name, fileshare_name, table_name, container_name, and blob_name at a time. Run subsequent deployments for additional subresources.

3. Use NG Hosted Agent to upload file to blob when Networking is set to "Selected Networks". Without the use of NG Hosted Agent, results in 403 unauthorized error.
