# Storage Account

    The following are the supported parameters for Storage Account Product.

    When using a CSV file for parameter specification:
    1. The value in the CSV file takes precedence over GitHub UI
    2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.

For details on supported values for the parameters please visit -
[Storage Account Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account)

|          Parameter name           | Description                                                                                                                                                  | Default Value |  Required             |                                     Naming standard                                     |
| :-------------------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------- | :-----------: | :-------------------: | :-------------------------------------------------------------------------------------: |
|           account_tier            | Storage account tier                                                                                                                                         |   Standard    | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|            access_tier            | Storage account access tier                                                                                                                                  |      Hot      | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|   blob_delete_retention_policy    | Blob delete retention policy                                                                                                                                 |       7       | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|             blob_name             | Name of blob                                                                                                                                                 |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|             blob_size             | Size of the blob                                                                                                                                             |      512      | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|        blob_upload_source         | Add your source file within the staging folder in Products Repo. Specify "../staging/filename" in the csv file, replace filename with the name of your file. |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
| container_delete_retention_policy | Container delete retention policy                                                                                                                            |       7       | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|          container_name           | Name of container                                                                                                                                            |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|          fileshare_name           | Name of fileshare                                                                                                                                            |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|          fileshare_quota          | Quota of fileshare                                                                                                                                           |       1       | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|     infrastructure_encryption     | Encrypt storage account.                                                                                                                                     |     false     | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|              ipRules              | Allow IPs for network acls configuration                                                                                                                     |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|           location                | location                                                                                                                                                     |               | $${\color{red}Yes}$$  |                       $${\color{red}eastus2,cus,uksouth,ukwest}$$                       |
|              purpose              | Specify Name for storage account or the purpose.sequence format. A value > 9 will be considered a full name.  Ex- abc.01                                                                                                        |               | $${\color{red}Yes}$$  |                         $${\color{red}buevregionpurposestnn}$$                          |
|            purpose_rg             | Specify the purpose to use for Resource Group                                                                                                                |               | $${\color{red}Yes}$$  | $${\color{red}bu-env-region-purpose-rg }$$ or $${\color{red}purpose }$$ |
|            queue_name             | Name of queue                                                                                                                                                |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|         replication_type          | Storage account replication type                                                                                                                             |      GRS      | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |
|   subnet_name_private_endpoint    | Subnet name for blob, queue, table and fileshare private endpoints                                                                                           |               | $${\color{red}Yes}$$  |                    $${\color{red}lzapp-env-region-purpose-snet-nn}$$                    |
|     subnet_name_svc_endpoint      | Subnet names for network acls configuration.  GitHub UI only supports 1 value. To provide multiple subnet names, use csv file and separate name by comma.                                                            |               | $${\color{red}Yes}$$ |                   $${\color{grey}lzapp-env-region-purpose-snet-nn}$$                    |
|            table_name             | Name of table                                                                                                                                                |               | $${\color{green}No}$$ |                                  $${\color{grey}N/A}$$                                  |

## Blob

Please refer to the Readme.md within the [storage-account blob module](/Azure/storage-account/blob/README.md) for documentation on deploying a blob to a Storage Account.

## Container

Please refer to the Readme.md within the [storage-account container module](/Azure/storage-account/container/README.md) for documentation on deploying a container to a Storage Account.

## Queue

Please refer to the Readme.md within the [storage-account queue module](/Azure/storage-account/queue/README.md) for documentation on deploying a queue to a Storage Account.

## Share

Please refer to the Readme.md within the [storage-account share module](/Azure/storage-account/share/README.md) for documentation on deploying a share to a Storage Account.

## Table

Please refer to the Readme.md within the [storage-account table module](/Azure/storage-account/table/README.md) for documentation on deploying a table to a Storage Account.
# Known Limitations

July 2023

1. The Product deploys with Networking Setting as "Selected Networks" and 4 Private Endpoints (table, queue, fileshare and blob) as per NG Security requirements. Networking Setting as "Private Access" results in 403 unauthorized error during pipeline deployment when creating blob, queue, container, or fileshare using GitHub Actions.

2. When Networking is set to "Selected Networks", use NG Hosted Agent when adding blob, container, queue, table or fileshare to an existing Storage Account in GitHub. Currently, the Cloud Platform Engineering Team do not have NG Hosted Agents within GitHub. Application Delivery Teams are encouraged to create/use their own NG Hosted agents.

3. The Product currently supports specification of only one queue_name, fileshare_name, table_name, container_name, and blob_name at a time. For any additional deployments, please use the respective product container, blob, queue, share, and table modules.
