# Private Endpoint

    The following are the supported parameters for Private Endpoint Module.

    Supports GitHub UI only.

|    Parameter name     | Description                                                                                                                                                                                   | Default Value | Required             |                    Naming standard                     |
| :-------------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-----------: | :------------------: | :----------------------------------------------------: |
|      location      | Select location deploy resource.                                                                                                                                                        |               | $${\color{red}Yes}$$ |                 $${\color{grey}NA }$$                  |
|      environment      | Select environment to deploy resource.                                                                                                                                                        |               | $${\color{red}Yes}$$ |                 $${\color{grey}NA }$$                  |
|   purposeRG   | Purpose of Resource Group Name that contains the resource for Private Endpoint creation. Name                                                                                                  |               | $${\color{red}Yes}$$ |   $${\color{red}N/A }$$    |
|        resourceName         | Name of Resource to create Private Endpoint                                                                                                                     |               | $${\color{red}Yes}$$ | $${\color{red}N/A }$$ |
|      subnetName       | Name of Subnet used for Private Endpoint                                                                                                                                                      |               | $${\color{red}Yes}$$ |   $${\color{red}lzapp-env-region-purpose-snet-nn }$$   |
|      subresource      | SubResource for Private Endpoint. Please see (https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-overview#dns-configuration) for a list of subresources per resource type. |               | $${\color{red}Yes}$$ |                 $${\color{grey}NA }$$                  |

# Known Limitations

July 2023

None
