# Data Factory Workflow 

    The following are the supported parameters for Data Factory.

For details on supported values for the parameters please visit -
[Data Factory Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_factory)

|   Parameter name   | Description                                                                                                                                                  | Default Value |  Required             |                                     Naming standard                                     |
| :----------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------- | :-----------: | :-------------------: | :-------------------------------------------------------------------------------------: |
|           requestType            | Select 'Create (with New RG)' for new resource and Resource Group deployment. Select 'Create (with Existing RG)' for new resource deployment in an existing Resource Group. Upcoming functionality - Select 'Update' to modify existing resource. Select 'Delete' to delete resource from Resource Group. |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Resource Name     | Specify the name abiding by naming convention or purpose.sequence format to use for Web App Name. Max 3-5 Char. Ex- abc.01                                                                                                        |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc                                                                                                                                |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Runtime Name | Runtime Name for Azure integration runtime to create Managed Virtual Network integration                                                                                                                                 |               | $${\color{red}Yes}$$  | $${\color{grey}NA }$$ or $${\color{grey}NA }$$ |
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |

## Blob Storage Linked Service

Please refer to the Readme.md within the [Blob Storage Linked Service module](/Azure/data-factory/linked-services/blob-storage/README.md) for documentation on Blob Storage Linked Services.

## Key Vault Linked Service

Please refer to the Readme.md within the [Key Vault Linked Service module](/Azure/data-factory/linked-services/key-vault/README.md) for documentation on Key Vault Linked Services.


## SQL Database Linked Service

Please refer to the Readme.md within the [SQL Database Linked Service module](/Azure/data-factory/linked-services/sql-database/README.md) for documentation on SQL Database Linked Services.


# Known Limitations

November 2024

1. Linked Service is created using System Assigned Managed Identity Authentication Type, as per Solution Architecture requirements. This requires you submit the RBAC Access ServiceNow form upon creation of the linked service in order to establish connectivity between the Linked Service and managed identity of the Data Factory. 

2. As per Solution Architecture analysis, currently we only support Key Vault Linked Service, Blob Storage Linked Service and SQL Database Linked Service. 

