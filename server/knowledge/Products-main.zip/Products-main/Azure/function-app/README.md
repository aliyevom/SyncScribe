# Function App

    Pre-Requisites: 
     1. Log Analytics Workspace must exist prior to deploying Function App. 
    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
     
     
Understanding GitHub Workflow Variables for Function App:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Create (with New RG and Storage Account) to create new Function app with new Resource Group and Storage Account. Create (with Existing RG and Storage Account) to create new Function App with an existing Resource Group and Storage Account. Create (with Existing RG and New Storage Account) to create new Function App with an existing Resource Group and new Storage Account. Select Update to modify or change existing Function App. Select Remove to delete Function App. Update and Remove requestTypes are not yet available.  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Name of Function App and Storage Account     | Specify the purpose.sequence to use for Function App Name and Storage Account Name (Value greater than 9 will be considered a full name for SA). Max 3-5 Char. Ex- abc.01.                                                                                                           |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc.                                                                                                                                                                                       |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            Log Analytics Workspace            | Name of Log Analytics Workspace and Name of RG that stores the workspace (colon separated) to integrate with App Insights Resource.                                                                                                                                                                                                             | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|          servicePlanSKU          | Specify sku's with either Basic, Standard or Premium SKU. for App Service Plan. Please see [documentation](https://learn.microsoft.com/en-us/azure/app-service/overview-hosting-plans) for list of all possible SKU's.                                                                                    |   $${\color{grey}N/A}$$    | $${\color{red}yes}$$ |
|           stackSetting           | Specify the stack setting for Function App. Linux Function App supports node, java, python, dotnet, and powershell stack languages. Windows Function App supports, node, java, powershell and dotnet stack languages.                                  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ | 
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Subnet Name for VNET Integration            | Specify Subnet Name to enable VNET Integration.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
## Function App Linux

Please refer to the Readme.md within the [function-app linux module](/Azure/function-app/linux/README.md) for documentation on Function App Linux.

## Function App Windows

Please refer to the Readme.md within the [function-app windows module](/Azure/function-app/windows/README.md) for documentation on Function App Windows.
