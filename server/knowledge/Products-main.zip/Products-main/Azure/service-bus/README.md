# Service Bus

    The following are all the supported parameters for Service Bus.

    When using a CSV file for parameter specification:
    1. The value in the CSV file takes precedence over GitHub UI
    2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
 
The column Field Name will be 'N/A' and Type will be CSV Input for parameters that are not available through the GitHub Workflow UI. To modify the parameter value, specify the Parameter Name in the csv file and provide respective value. Please ensure the value provided is supported by Azure and Terraform. For details on supported values for the parameters please visit -
[Service Bus Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/servicebus_namespace)   

|Field Name|Parameter Name|Type|Default Value|Values Supported|Required|Rules/Conditions|
| :------------------------------: | :------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |
|           N/A            | enable_partitioning | CSV Input  | N/A  |  Enable Partitioning   | $${\color{green}No}$$ |$${\color{grey}N/A}$$|
|           N/A            | ip_rules | CSV Input  | N/A | Specify IP rules to allow through Networking  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |           
|           N/A            | max_delivery_count | CSV Input  |  | Max Delivery Count  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | namespace_name | CSV Input | N/A | Provide a name based on naming convention.  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | queue_name | CSV Input | N/A | Provide a name based on naming convention. For multi queue deployments, specify list of queue names with comma separated values. (no spaces) Ex- "us5874-dev-eus-testq-sbq-01,us5874-dev-eus-testq-sbq-02,us5874-dev-eus-testq-sbq-03" |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | sku | CSV Input | false | SKU for Service Bus.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | topic_name | CSV Input | N/A | Provide a name based on naming convention. For multi topic deployments, specify list of topic names with comma separated values. (no spaces) Ex- us5874-dev-eus-testtop-sbt-01,us5874-dev-eus-testtop-sbt-02  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | topic_subscription_name | CSV Input | N/A | Provide a name based on naming convention. For multi subscription topic deployments, specify list of subscription topic names with comma separated values. (no spaces) Ex- us5874-dev-eus-testsub-sbts-01,us5874-dev-eus-testsub-sbts-02 |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | zone_redundant | CSV Input  | false | Enable Zone redundancy |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
