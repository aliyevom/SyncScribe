# Service Bus Failover

    The following are all the supported parameters for Service Bus Failover.

    When using a CSV file for parameter specification:
    1. The value in the CSV file takes precedence over GitHub UI
    2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
 
The column Field Name will be 'N/A' and Type will be CSV Input for parameters that are not available through the GitHub Workflow UI. To modify the parameter value, specify the Parameter Name in the csv file and provide respective value. Please ensure the value provided is supported by Azure and Terraform. For details on supported values for the parameters please visit -
[Service Bus Terraform](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/servicebus_namespace)   

|Field Name|Parameter Name|Type|Default Value|Values Supported|Required|Rules/Conditions|
| :------------------------------: | :------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |:------------------------------: |         
|           N/A            | capacity_secondary | CSV Input | N/A | Name of Secondary Service Bus Capacity.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | location_secondary | CSV Input | N/A | Name of Secondary Service Bus Location.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | namespace_name | CSV Input | N/A | Name of Primary Service Bus. Provide a name based on naming convention.  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | namespace_name_secondary | CSV Input | N/A | Name of Secondary Service Bus. Provide a name based on naming convention.  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | rg_name | CSV Input | N/A | Name of Resource Group of Primary  Service Bus. Provide a name based on naming convention.  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | rg_name_secondary | CSV Input | N/A | Name of Resource Group of Secondary  Service Bus. Provide a name based on naming convention.  |  $${\color{green}No}$$   | $${\color{red}naming convention}$$ |
|           N/A            | subnet_name_pe_secondary | CSV Input | N/A | Name of Subnet for Secondary Private Endpoint.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | vnet_name_secondary | CSV Input | N/A | Name of VNET for Secondary Private Endpoint.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |
|           N/A            | vnet_rg_secondary | CSV Input | N/A | Name of VNET Resource Group for Secondary Private Endpoint.  |  $${\color{green}No}$$   | $${\color{grey}N/A}$$ |