# IOT Hub
## Manage internet of things devices

### Prerequisites 
1.  Subnet needs to be setup with default network security group and default user defined routes
2.  Key Vault needs to be setup   
3.  Private DNS Zones should be in place
4.  Optionally obtain certificate authority issued certificate and load it into Key Vault
use ADF as reference 
 - storage
 - service bus 
 -
 - adx 
separate pipeline for integration 

## GitHub Workflow Fields/Parameters

|	Field Name	|	Parameter Name	|	Type	|	Default Value	|	Values Supported	|	Required	|	Rules/Conditions	|
|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|	:-------------------------------	|
|	Location	|	location	|	Dropdown	|	eastus2	|	eastus2, centralus,uksouth,ukwest	|	$${\color{Red}Yes}$$ 	|	Choose the right location for the IOT Hub services you are deploying. Not all services are available in all regions	|
|	Environment	|	environment	|	Dropdown	|	dev	|	dev,qa,uat,prod	|	$${\color{Red}Yes}$$ 	|	Make sure envionrment and related subscription information is set in Git Hub	|
|	Purpose	|	purpose	|	text	|	empty	|	purpose for your app (3-4) chars	|	$${\color{Red}Yes}$$ 	|		|
|	Billing info	|	sku_tier	|	Dropdown	|	S2	|	S2, S1, S3, Free, B1, B2, B3	|	$${\color{Red}Yes}$$ 	|		|
|	Number of Instances	|	sku_capacity	|	Dropdown	|	2	|	2, 1, 4, 6, 8, 10	|	$${\color{Red}Yes}$$ 	|		|
|	Subnet name for IOT Hub	|	subtnetname	|	text	|	empty	|	subnet name in the respective region/location	|	$${\color{Red}Yes}$$ 	|		|
|	Key vault name 	|	kv_name	|	text	|	empty	|	key vault name associated with the environment subscription 	|	$${\color{Red}Yes}$$ 	|		|
|	Key valut resource group name	|	kv_resource_group_name	|	text	|	empty	|	key vault resource group name associated with the environment subscription 	|	$${\color{Red}Yes}$$ 	|		|
|	Existience Resource Group	|	Rgname	|	text	|	empty	|	any existing RG name	|	$${\color{yellow}No}$$ 	|	This is optional. If empty then it creats new Resource Group	|


Note1: Paramters in the file over write paramters entered through github action workflow dispatch UI
<br>
Note2: use deploy subnet for getting subnet setup with prior approval from SA
