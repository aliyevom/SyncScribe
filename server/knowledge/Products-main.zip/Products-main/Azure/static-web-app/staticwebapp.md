# 2. Static Web site Creation

<P> A static website can be provisioned uisng this workflow</p><span style="color:white"><i>This pipeline deploys a static web site. </i></span>
<span style="color:white"><i>This pipeline deploys a  </i></span>
<span style="color:white"><li>Static web site to a new/existing Resource group </li></span>
<span style="color:white"><li> Creates custom domain based on the dnszone and hostname  </li></span>
<span style="color:white"><li> Adds custom domain to static app with azure validation  </li></span>

<span style="color:green"><i>To configure static website with custom domain, run the pipeline with <b style="color:yellow">Update</b> as option and specify valid <b style="color:yellow">Hostname</b>.</i></span>
<span style="color:red"><i>(Valid DNS is required) </i></span>
<!-- ## GitHub Workflow Design 

<img src="./images/Initial_setup_config.png" alt="user_flow" title="User Work Flow" align="center" height="100%" width="100%"> -->

## GitHub Workflow Fields/Parameters
 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
Request Type	|	RequestType	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
Purpose	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
Create Resource Group?	|	ResourceGroup	|	Dropdown	|	Yes	|	Yes, No	|	$${\color{Red}Yes}$$ 	|	Default is "YES". Please change value to "No" if RG creation is not needed.	|
RG Name	|	Rgname	|	Text	|	empty/blank	|	Existing RG name	|	$${\color{orange}Optional}$$ 	|	Default is "Empty". Please enter existing RG name where you intend to deploy static site. This is required If you are deplying to existing RG.	|
Specify Subnet Name to create Private End Point	|	SubnetID	|	Text	|	empty/blank	|	Subent Name	|	$${\color{Red}Yes}$$ 	|	Default is "NO". Please change value to "Yes" if  storage account  is needed.	|
Specify the hostname to use custom domain (eg-webapp)	|	hostname	|	Text	|	empty	|	name for the custom domain	|	$${\color{Red}Yes}$$ 	|	please specify the name for the custom domain. For example, webapp	|
dnszone	|	dnszone	|	Dropdown	|	empty	|	dpit.nationalgrid.com,digitalplatforms.nationalgrid.com,groupfunctions.nationalgrid.com,nget.nationalgrid.com,ngv.nationalgrid.com,oceanbrain.nationalgrid.com,security.nationalgrid.com,uket.nationalgrid.com,us-electric.nationalgrid.com,uscustomer.nationalgrid.com,uset.nationalgrid.com,usgas.nationalgrid.com,ed.nationalgrid.com	|	$${\color{Red}Optional}$$ 	|	Default is "empty". Please change value to required domain as needed.	|