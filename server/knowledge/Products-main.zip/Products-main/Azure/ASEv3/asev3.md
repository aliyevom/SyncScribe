# 6. App Service Environment V3

<P> Manages a 3rd Generation (v3) App Service Environment.</p>
<br>

* <span style="color:yellow"><i>ASEv3 requires a delegated Subnet. Please make sure you have a subnet with enough IP ranges available</i></span>

<br>

## GitHub Workflow Fields/Parameters


|	 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Subscription Name	|	Subscription	|	Text 	|	Empty	|	Subscription Name	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Request Type	|	RequestType	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Purpose	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Create Reource Group?	|	ResourceGroup		Dropdown	|	Yes	|	Yes, No	|	$${\color{Red}Yes}$$ 	|	Default is "YES". Please change value to "No" if RG creation is not needed.	|
|	Enter the subnet name for delegation	|	subnetname	|	Text	|	Empty	|	subnet names that are not delegated	|	$${\color{Red}Yes}$$ 	|	  <span style="color:Red"><i>Enter subnet names which is not delegated any other resource</i></span>	|
|	Zone redundancy	|	zoneredundancy	|	Dropdown	|	FALSE	|	TRUE,FALSE	|	$${\color{Orange}Optional}$$ 	|	Default is "false". 	|