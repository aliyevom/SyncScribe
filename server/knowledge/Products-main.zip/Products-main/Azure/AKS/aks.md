# 3. Azure Kubernetes Services Creation

<P> AKS cluster with user node pool (Linux) is created using this workflow</p>
<br>

Private Cluster Documentation can be found [HERE](../../Azure/AKS-private/aks-private.md)

* <span style="color:yellow"><i>Currently Windows user node pools are not supported using this pipeline.</i></span>

<br>

* <span style="color:blue"><b>UPDATE </b> </span> - To add new user node pool, please choose "Update" as request type and specify information in github UI flow.   .</i></span>
*******************************

Please refer to Microsoft documentation [HERE](https://learn.microsoft.com/en-us/azure/aks/configure-azure-cni) for planning IP addressing for cluster

*******************************

## GitHub Workflow Fields/Parameters
|	 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Subscription Name	|	Subscription	|	Text 	|	Empty	|	Subscription Name	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Request Type	|	RequestType	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Purpose	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Enter the subnet name for cluster	|	subnetname	|	Text	|	Empty	|	subnet names that are not delegated	|	$${\color{Red}Yes}$$ 	|	  <span style="color:Red"><i>Enter subnet names which is not delegated any other resource</i></span>	|
|	Specify the vm size (eg: Standard_DS2_v2)'	|	systemnodes	|	Text	|	Standard_DS2_v2	|	Sku's supported by Azure and that are available in the region	|	$${\color{orange}Optional}$$ 	|	Default is "Standard_DS2_v2". Please specify if a different config is desired.	|
|	'Specify the vm size for user node pool (eg: Standard_DS2_v2)'	|	usernodes	|	Text	|	Standard_DS2_v2	|	Sku's supported by Azure and that are available in the region	|	$${\color{orange}Optional}$$ 	|	Default is "Standard_DS2_v2". Please specify if a different config is desired.	|
|	Enter the total number of user nodes to be provisioned.	|	noofusernodes	|	Text 	|	1	|	numbers	|	$${\color{Orange}Optional}$$ 	|	Default is "1". Please enter desired number of nodes based on the IP ranges allocated to the subnet	|
|		|		|		|		|		|		|		|


