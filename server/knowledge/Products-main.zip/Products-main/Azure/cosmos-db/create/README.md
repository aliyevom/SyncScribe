# CosmosDB

    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
     
Understanding GitHub Workflow Variables for CosmosDB:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Create (with New RG) to create new CosmosDB with new Resource Group. Create (with Existing RG) to create new CosmosDB with an existing Resource Group. Select Update to modify or change existing CosmosDB. Select Remove to delete CosmosDB. Update and Remove requestTypes are not yet available.  |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Resource Name     | Specify the purpose to use for CosmosDB Name. Max 3-5 Char. Ex- abc, abc01.. (the format purpose.sequence is not permitted for this resource).                                                                                                                                    |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc, abc01, abc.01..                                                                                                                                                                                       |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            capacityMode            | Select capacityMode for CosmosDB Account.                                                                                                                                                                                                         | $${\color{grey}Provisioned Throughput}$$ | $${\color{red}yes}$$ |
|          api_type          | Select API Type for CosmosDB Account.                                                                                    |   $${\color{grey}MongoDB}$$    | $${\color{red}yes}$$ |
|           consistency_level           | Select Consistency Level for CosmosDB Account.                                 |  $${\color{grey}BoundedStaleness}$$   | $${\color{red}yes}$$ |
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |

## CosmosDB (with Provisioned Throughput)

Please refer to the Readme.md within the [throughput module](/Azure/cosmos-db/create/throughput/README.md) for documentation on CosmosDB with Provisioned Throughput.

## CosmosDB (with Serverless)

Please refer to the Readme.md within the [serverless module](/Azure/cosmos-db/create/serverless/README.md) for documentation on CosmosDB with Serverless.