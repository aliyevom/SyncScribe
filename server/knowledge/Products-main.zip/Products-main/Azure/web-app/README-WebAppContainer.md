# Web App Container
        
    Pre-Requisites:  
      1. Log Analytics Workspace must exist prior to deploying Web App.
      
    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
    

Understanding GitHub Workflow Variables for Web App:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Select 'Create (with New RG)' for new resource and Resource Group deployment. Select 'Create (with Existing RG)' for new resource deployment in an existing Resource Group. Upcoming functionality - Select 'Update' to modify existing resource. Select 'Delete' to delete resource from Resource Group. |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Resource Name     | Specify the name abiding by naming convention or purpose.sequence format to use for Web App Name. Max 3-5 Char. Ex- abc.01                                                                                                        |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc                                                                                                                                |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            Log Analytics Workspace            | Name of Log Analytics Workspace and Name of RG that stores the workspace (colon separated) to integrate with App Insights Resource.                                                                                                                                                                                                              | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|            Application Insights            | Name of Application Insights and Name of RG that stores the resource (colon separated) to use to integrate with existent App Insights Resource.                                                                                                                                                                                                              | $${\color{grey}N/A}$$ | $${\color{green}no}$$ |
|          servicePlanSKU          | Specify either Basic, Standard or Premium SKU for App Service Plan. Please see [documentation](https://learn.microsoft.com/en-us/azure/app-service/overview-hosting-plans) for list of SKU's.                                                                                    |   $${\color{grey}N/A}$$    | $${\color{red}yes}$$ |
|           stackSetting           | Specify the stack setting for Web App. Linux Web App supports node, java, php, python, dotnet, and ruby stack languages. Windows Web App supports, dotnetcore, dotnet, java, php, python and node.                                                        |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ | 
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Subnet Name for VNET Integration            | Specify Subnet Name to enable VNET Integration.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}Yes}$$ |
## Web App Linux

Please refer to the Readme.md within the [web-app linux module](/Azure/web-app/linux/README.md) for documentation on Web App Linux.

## Deploy Application using App Services Container

By design we are deploying a default nginx image, if you want to deploy the web app container using your private image please follow the steps below:

1. Configure the secrets in your CCOE forked repo:
- **DOCKER_REGISTRY_URL**:  registry_url  e.g. https://jfrog.devops.nationalgrid.com/
- **DOCKER_REGISTRY_USERNAME**: your_username
- **DOCKER_REGISTRY_PASSWORD**: your_password
- **DOCKER_IMAGE**: your_image  e.g. gtis2test/snapshot/frontend:235-d3c383b0d2e0b1af86i4o3j634534

2. Run your pipeline to create a resource

## Deploying only the application from your project workflow
1. Create a Workflow following the example below
```
name: App Service Deployment - Container

on:
  workflow_dispatch:

env:
  SUBSCRIPTION_ID: ${{ secrets.SUBSCRIPTION_ID }}
  AZURE_WEBAPP_NAME: APP_NAME
  WEB_APP_RG: APP_RG

jobs:
  push_to_webapp:
    environment: dev
    runs-on:
      group: <RUNNER_GROUP>
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Login to Azure
        uses: azure/login@v2
        with:
          creds: ${{ secrets.AZURE_CREDENTIALS }}

      - name: Configure Registry Credentials - Jfrog
        run: |
          az webapp config container set \
            --docker-registry-server-password ${{ secrets.ARTIFACTORY_PASSWORD}} \
            --docker-registry-server-url https://jfrog.devops.nationalgrid.com/ \
            --docker-registry-server-user ${{ secrets.ARTIFACTORY_USERNAME }} \
            --name ${{ env.AZURE_WEBAPP_NAME }} \
            --resource-group ${{ env.WEB_APP_RG }}

      - name: Deploy to Azure Web App
        id: deploy-to-webapp
        uses: azure/webapps-deploy@v2
        with:
          app-name: ${{ env.AZURE_WEBAPP_NAME }}
          publish-profile: ${{ secrets.AZURE_FRONTEND_WEBAPP_PUBLISH_PROFILE }}
          images: jfrog.devops.nationalgrid.com/<IMAGE_NAME>:<IMAGE_TAG>
```

2. Create the required secrets:
- ARTIFACTORY_PASSWORD
- ARTIFACTORY_USERNAME
- SUBSCRIPTION_ID
- AZURE_CREDENTIALS 
```
{
    "clientSecret":  "******",
    "subscriptionId":  "******",
    "tenantId":  "******",
    "clientId":  "******"
}
```
- AZURE_FRONTEND_WEBAPP_PUBLISH_PROFILE  (you can get this information from App Service resource on Azure Portal https://learn.microsoft.com/en-us/visualstudio/azure/how-to-get-publish-profile-from-azure-app-service?view=vs-2022)

3. On the workflow update the environment variables below:
-  AZURE_WEBAPP_NAME  (your web app name)
-  WEB_APP_RG         (your web app resource group)

4. Update the GitHub Runner Group
- <RUNNER_GROUP>  (your project runners)

5. Update the image and tag informations
You need to change the ImageName and ImageTag with the correct informations from the image that you have on the Jfrog Registry
- images: jfrog.devops.nationalgrid.com/**<IMAGE_NAME>**:**<IMAGE_TAG>**

6. Save the file and run the workflow to push your image to your Web App Service