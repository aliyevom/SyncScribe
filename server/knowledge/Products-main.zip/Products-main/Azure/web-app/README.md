# Web App
        
    Pre-Requisites:  
      1. Log Analytics Workspace must exist prior to deploying Web App.
      
    When using a CSV file for parameter specification:
     1. The value in the CSV file takes precedence over GitHub UI
     2. Specify a column named 'unique_id' with the value as any distinct number to correspond to the resource in the CSV file and code.
    

Understanding GitHub Workflow Variables for Web App:

|          Workflow Input          | Description                                                                                                                                                                                                                                                                      |      Default Value       | Required             |
| :------------------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------: | :------------------: |
|           requestType            | Select 'Create (with New RG)' for new resource and Resource Group deployment. Select 'Create (with Existing RG)' for new resource deployment in an existing Resource Group. Upcoming functionality - Select 'Update' to modify existing resource. Select 'Delete' to delete resource from Resource Group. |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|             location             | Select location of resource deployment.                                                                                                                                                                                                                                          | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|           environment            | Select environment of resource deployment.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    Purpose for Resource Name     | Specify the name abiding by naming convention or purpose.sequence format to use for Web App Name. Max 3-5 Char. Ex- abc.01                                                                                                        |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| Purpose for Resource Group Name  | Specify the purpose to use for Resource Group Name. Max 3-5 Char. Ex- abc                                                                                                                                |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|            Log Analytics Workspace            | Name of Log Analytics Workspace and Name of RG that stores the workspace (colon separated) to integrate with App Insights Resource.                                                                                                                                                                                                              | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|          servicePlanSKU          | Specify either Basic, Standard or Premium SKU for App Service Plan. Please see [documentation](https://learn.microsoft.com/en-us/azure/app-service/overview-hosting-plans) for list of SKU's.                                                                                    |   $${\color{grey}N/A}$$    | $${\color{red}yes}$$ |
|           stackSetting           | Specify the stack setting for Web App. Linux Web App supports node, java, php, python, dotnet, and ruby stack languages. Windows Web App supports, dotnetcore, dotnet, java, php, python and node.                                                        |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ | 
| Subnet Name for Private Endpoint | Specify Subnet Name to create Private Endpoint. The Subnet must be un-delegated.                                                                                                                                                                                                 |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|           Subnet Name for VNET Integration            | Specify Subnet Name to enable VNET Integration.                                                                                                                                                                                                                                       |   $${\color{grey}N/A}$$   | $${\color{red}Yes}$$ |
## Web App Linux

Please refer to the Readme.md within the [web-app linux module](/Azure/web-app/linux/README.md) for documentation on Web App Linux.

## Web App Windows

Please refer to the Readme.md within the [web-app windows module](/Azure/web-app/windows/README.md)  for documentation on Web App Windows.


## Deploy Application onto Web App

1. Deploy a Web App using Deploy-Web-App.yml Workflow

2. Go into the repository which contains your application. For a sample application, we cloned this repository https://github.com/nationalgrid-cloud-team/WebAppDemo-Sample-Python-App. 

3. Within GitHub secrets add the client ID, client secret, subscription Id and tenant Id for your Subscription. Store the credentials as AZURE_SPN_CLIENTID, AZURE_SPN_SECRET, AZURE_SUBSCRIPTIONID and AZURE_TENANTID so you don't have to modify the workflow.  

4. Go into the main branch and locate the Deploy_Application_WebApp.yml within .github/workflows directory. Change the value for 'app-name' on line 72 into the name of your Web App. 

5. Save the file and run the workflow.

Please ensure the workflow uses the NG hosted agent. This is required if the Web App is enabled with Private Endpoints and VNET integration. 
runs-on: 
        group: aks-runners

## Deploy Web App Container
[web-app-container](/Azure/web-app/README-WebAppContainer.md)
