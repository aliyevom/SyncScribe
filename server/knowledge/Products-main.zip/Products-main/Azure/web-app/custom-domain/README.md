# Web App Custom Domain

Understanding GitHub Workflow Variables for Web App:

|  Workflow Input   | Description                                                                                                                                       |      Default Value       | Required             |
| :---------------: | :------------------------------------------------------------------------------------------------------------------------------------------------ | :----------------------: | :------------------: |
|     location      | Select location of resource deployment.                                                                                                           | $${\color{grey}N/A}$$ | $${\color{red}yes}$$ |
|    environment    | Select environment of resource deployment.                                                                                                        |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
| resourceGroupName | Specify Resource Group Name.                                                                                                                      |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    webAppName     | Specify Web App Name.                                                                                                                             |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    webAppOS     | Specify Web App OS. Options are Linux or Windows.                                                                                                                            |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|     hostName      | Specify the hostname for Custom Domain.                                                                                                           |  $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |
|    DnsZone     | Select NG DNS Zone for custom domain. Options are ed.nationalgrid.com, dpit.nationalgrid.com,digitalplatforms.nationalgrid.com,groupfunctions.nationalgrid.com,nget.nationalgrid.com,ngv.nationalgrid.com,oceanbrain.nationalgrid.com,security.nationalgrid.com,uket.nationalgrid.com,us-electric.nationalgrid.com,uscustomer.nationalgrid.com,uset.nationalgrid.com,usgas.nationalgrid.com                                                                                                        |   $${\color{grey}N/A}$$   | $${\color{red}yes}$$ |


## Web App Linux

Please refer to the Readme.md within the web-app-linux module for documentation on Web App Linux.

## Web App Windows

Please refer to the Readme.md within the web-app-windows module for documentation on Web App Windows.