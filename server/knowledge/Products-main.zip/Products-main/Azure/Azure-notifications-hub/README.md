# Notification Hub Module
---
## Overview

This module enables Azure Notification Hubs and all necessary supporting resources. It enforces organizational standards for: For more details, compare Azure Notification Hubs tiers [here](https://learn.microsoft.com/en-us/azure/notification-hubs/notification-hubs-push-notification-faq).


## Naming Convention Pattern Used

### Naming Format
```
<region><bu>-<purpose>-<env>-<location_abbreviation>-hub-ns
<region><bu>-<purpose>-<env>-hub
```
**Namespace Name:** `<region><bu>-<purpose>-<env>-<location_abbreviation>-hub-ns` (must start with a letter)

**Hub Name:** `<region><bu>-<purpose>-<env>-hub`

### Parameters

- **region** – Geographical prefix (e.g. "us" for United States) ensuring name starts with a letter.
- **bu** – Business unit identifier (e.g. "5874") to distinguish between teams/subscriptions.
- **purpose** – Project or application code (3–6 characters) identifying the workload (e.g. "webpush" for web notifications).
- **env** – Environment name (e.g. dev, qa, uat, prod).
- **location_abbreviation** – Azure region abbreviation (e.g. "eus2" for East US 2).
- **Suffixes:** `-hub-ns` for the namespace, and `-hub` for the hub resource (appended as fixed suffixes).

### Example Output

- **Namespace:** `us5874-webpush-uat-eus2-hub-ns`
- **Hub:** `us5874-webpush-uat-hub`

> Note: The region and business unit (bu) prefix combination helps distinguish between teams and geographical deployments when multiple subscriptions exist.

## UI Workflow Guidelines

### Name of Primary Notification Hub or Specify Purpose (5–6 Character Format)

#### Allowed Characters

- Only letters (a-z, A-Z) and numbers (0-9)

#### Not Allowed

- Spaces, dots (`.`), commas (`,`), apostrophes (`'`), dashes (`-`), or other special characters

**Examples:**

- Valid: `test01`
- Invalid: `test.01`, `test-01`

> Note: An Azure Policy enforces strict naming rules for Notification Hub namespaces.

### Available SKUs for Azure Notification Hub

| SKU      | Description                                       | Features                                                           |
| -------- | ------------------------------------------------- | ------------------------------------------------------------------ |
| Standard | Common for production workloads                   | High availability, geo-disaster recovery, advanced telemetry.      |
| Basic    | For basic workloads                               | Basic telemetry, limited throughput.                               |

### Select Additional Services to Deploy

#### Options

- **NotificationHub**
  Deploys the Notification Hub resource, including namespace, notification hub, and related networking.

- **NamespaceOnly**
  Skips creation of Notification Hub resources. Used when only updating network configurations or infrastructure.

### Service Deployment Summary

| Option          | Description                                                       |
| --------------- | ----------------------------------------------------------------- |
| NotificationHub | Deploys or updates the Notification Hub and associated infrastructure |
| NamespaceOnly   | Only updates networking and infrastructure, no Notification Hub deployed |
