# Azure Notification Hub Naming Convention

## Overview
This document outlines the standardized naming convention for Azure Notification Hub resources.

## Namespace Naming
Format: `[purpose]-[env]-[region]-hub-ns`

Example: `mobile-uat-eus2-hub-ns`

Components:
- `purpose`: Project or application identifier (3-6 chars)
- `env`: Environment (dev, qa, uat, prod)
- `region`: Azure region abbreviation (e.g., eus2)
- `hub-ns`: Fixed suffix for namespace

## Hub Naming
Format: `[purpose]-[env]-hub`

Example: `mobile-uat-hub`

Components:
- `purpose`: Project or application identifier (3-6 chars)
- `env`: Environment (dev, qa, uat, prod)
- `hub`: Fixed suffix for hub

## Validation Rules
1. Namespace name must be globally unique
2. No special characters allowed
3. Use only lowercase letters, numbers, and hyphens
4. Maximum length considerations:
   - Namespace: Keep under 50 characters
   - Hub: Keep under 50 characters

## Examples
Development Environment:
```
Namespace: mobile-dev-eus2-hub-ns
Hub: mobile-dev-hub
```

Production Environment:
```
Namespace: mobile-prod-eus2-hub-ns
Hub: mobile-prod-hub
```

## Notes
- This naming convention has been validated and tested in Azure deployments
- Ensures consistency across all notification hub resources
- Aligns with platform standards and best practices
- Successfully deploys through Terraform automation