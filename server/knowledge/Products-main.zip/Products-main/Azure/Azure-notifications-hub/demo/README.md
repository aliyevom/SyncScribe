## National Grid Web Push Demo (Azure Notification Hubs)

### Prerequisites

- Azure Notification Hub deployed and configured for Web Push (VAPID Subject, Public & Private keys)
- Node.js 18+
- Values for environment variables:
  - `NH_CONN` – Notification Hub connection string (DefaultFullSharedAccessSignature)
  - `NH_HUB` – Notification Hub name

### Setup

```bash
cd Azure/Azure-notifications-hub/demo
npm install
```

Create `.env` (or export env vars):

```bash
NH_CONN="Endpoint=sb://<ns>.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=<key>"
NH_HUB="<your-hub-name>"
```

Update `public/index.html` with your VAPID public key.

### Run

```bash
npm run start
# Open http://localhost:3000
```

### Test Scenarios

Use the UI to register with tags: region, role, optional asset.

Send examples (via HTTP client or curl):

Crew Dispatch (NE field techs):

```bash
curl -X POST http://localhost:3000/api/send \
  -H 'Content-Type: application/json' \
  -d '{"title":"Crew Dispatch Required","body":"NE grid event near Substation 101. Dispatch immediately.","tagExpression":"(region:ne AND role:field-tech)"}'
```

Customer Advisory (NE customers):

```bash
curl -X POST http://localhost:3000/api/send \
  -H 'Content-Type: application/json' \
  -d '{"title":"Service Advisory","body":"Storm-related outage in your area. Crews en route.","tagExpression":"(region:ne AND role:customer)"}'
```

Asset-specific escalation:

```bash
curl -X POST http://localhost:3000/api/send \
  -H 'Content-Type: application/json' \
  -d '{"title":"Critical Transformer Alert","body":"Substation 101 transformer overheating.","tagExpression":"(region:ne AND role:field-tech AND asset:substation-101)"}'
```


