# 11. Linux Virtual Machine (RHEL)

<P> Manages Creation of RedHat Linux Virtual Machine.</p>
<br>

<span style="color:grey"><b>This Pipeline provisions: </b></span>
* <span style="color:yellow"><ul><i>RHEL VM 8.2 version with one Managed disk of choosen size</i> </ul></span>
* <span style="color:yellow"><ul><i>Domain Joined with Global AD</i> </ul></span>
* <span style="color:yellow"><ul><i>latest Versions of Tanium, FireEye along with splunk forwarder will be configured</i> </ul></span>


## GitHub Workflow Fields/Parameters

|	 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Select Type of request	|	RequestType	|	Dropdown 	|	Create (With new RG)	|	Create (With new RG), Create (With existing RG)	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Choose the Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Choose the Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Enter the Purpose for the VM (3-5 char)	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Provide Existing RG if 'Create (With Existing RG)' is selected	|	RGname	|	Text	|	Empty	|	names of RG	|	$${\color{Yellow}Yes}$$ 	|	Default is "YES". Please change value to "No" if RG creation is not needed.	|
|	Please provide OU from Gload AD	|	projectou	|	Text	|	Empty	|	Project OU	|	$${\color{Red}Yes}$$ 	|		|
|	Specify the Subnet name where VM has to be provisioned	|	subnetname	|	text	|	Empty	|	subentname	|	$${\color{Red}Optional}$$ 	|		|
|	Specify the size of the VM (Standard_D2s_v3)	|	vmsize	|	Text	|	Standard_D2s_v3	|	all the supported VM sku's	|	$${\color{Red}Yes}$$ 	|		|
|	storageaccounttype	|	        storageaccounttype:	|	Dropdown	|	Standard_LRS	|	Standard_LRS, StandardSSD_ZRS, StandardSSD_LRS, Premium_LRS, Premium_ZRS, UltraSSD_LRS	|	$${\color{Red}Yes}$$ 	|		|
|	Specify the disk size in GB	|	disksize	|	text	|	128	|		|	$${\color{Red}Yes}$$ 	|		|