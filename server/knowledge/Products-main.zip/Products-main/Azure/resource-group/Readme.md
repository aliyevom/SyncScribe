# 1. Resource Group Creation

<P> Resource group creation is handled during the process of initial setup configuration (01.initial_setup.yml)</p>

## GitHub Workflow Design 

<img src="/images/Initial_setup_config.png" alt="user_flow" title="User Work Flow" align="center" height="100%" width="100%">

## GitHub Workflow Fields/Parameters

|	 Field Name 	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Subscription Name	|	Text 	|	Empty	|	Subscription Name	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Request Type	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Do you need RG created ?	|	Dropdown	|	Yes	|	Yes, No	|	$${\color{Red}Yes}$$ 	|	Default is "YES". Please change value to "No" if RG creation is not needed.	|
|	Do you Need Key vault created?	|	Dropdown	|	No	|	Yes, No	|	$${\color{orange}Optional}$$ 	|	Default is "NO". Please change value to "Yes" if  Key Vault  is needed.	|
|	Do you Need Storage Account created?	|	Dropdown	|	No	|	Yes, No	|	$${\color{orange}Optional}$$ 	|	Default is "NO". Please change value to "Yes" if  storage account  is needed.	|

