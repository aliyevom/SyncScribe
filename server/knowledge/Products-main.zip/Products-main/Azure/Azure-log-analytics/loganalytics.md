# 4. Azure log analytics work space

<P> Azure log analytics work space will be created in its own resource group and is available to use</p>

<br>

## GitHub Workflow Fields/Parameters

|	 Field Name 	|	 Parameter Name	|	 Type 	|	Default Value 	|	 Values Supported 	|	Required	|	Rules/Conditions	|
|	:-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	 :-------------------------------   	|	:-------------------------------   	|	:-------------------------------   	|
|	Subscription Name	|	Subscription	|	Text 	|	Empty	|	Subscription Name	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Request Type	|	RequestType	|	Dropdown 	|	Create	|	Create,update,delete	|	$${\color{Red}Yes}$$ 	|	N/A	|
|	Location	|	location	|	Dropdown	|	eastus2	|	Eastus2,centralus,ukwest,uksouth	|	$${\color{Red}Yes}$$ 	|		|
|	Environment	|	environment	|	Dropdown	|	Dev	|	Dev,qa,UAT,Prod	|	$${\color{Red}Yes}$$ 	|	Create Environment names in github with same values as mentioned in "Values supported column	|
|	Purpose	|	purpose	|	Text	|	Empty	|	3-5 chars of purpose	|	$${\color{Red}Yes}$$ 	|	<span style="color:blue"><i>Specify purpose in 3-5 characters</i></span>	|
|	Select the SKU	|	sku_tier	|	Dropdown	|	PerGB2018	|	PerGB2018, Standard,Premium	|	$${\color{orange}Yes}$$ 	|	  <span style="color:Red"><i>Select the Sku type</i></span>	|


