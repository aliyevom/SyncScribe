<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.1.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | 1.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azapi"></a> [azapi](#provider\_azapi) | 1.7.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| azapi_resource.nsg_update_agw_gateway | resource |
| azapi_resource.nsg_update_agw_loadbalancer | resource |
| azapi_update_resource.delegateSubnet | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_nsg_update_data"></a> [nsg\_update\_data](#input\_nsg\_update\_data) | Network Security Group update data. | <pre>list(object(<br>    {<br>      nsg_id        = optional(string)<br>      nsg_priority  = optional(string)<br>    }))</pre> | <pre>[<br>  {}<br>]</pre> | no |
| <a name="input_request_type"></a> [request\_type](#input\_request\_type) | n/a | `string` | n/a | yes |
| <a name="input_subnet_delegation_data"></a> [subnet\_delegation\_data](#input\_subnet\_delegation\_data) | subnet\_delegation\_data | <pre>list(object({<br>    delegation_type     = optional(string)<br>    delegation_action   = optional(string)<br>    subnet_id           = optional(string)<br>  }))</pre> | <pre>[<br>  {}<br>]</pre> | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->